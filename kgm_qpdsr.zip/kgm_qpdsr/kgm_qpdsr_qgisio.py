# -*- coding: utf-8 -*-
"""
############################################################
KgmQpQgisIo

QGISプラグイン版『聞き書きマップ』のQGIS-IO処理
方針：データアクセス系・（Qtなどによる）ビュー系と切り分ける

as of 2024/03/22
############################################################
"""

import os

##### 2024/02/21: 【重要】今後os.pathからpathlibへ順次移行
from pathlib import Path, PurePath


##### ifaceを使うために必要
#     --> see: PyQGIS Developer Cookbook, 1.1
#     (2021/03/19)
from qgis.core import *
import qgis.utils
from qgis.utils import iface


#####【2024/05/22】こんな見たことのないやつが紛れ込んでエラーになった模様・・・
# from decorator import __init__

#####【2024/03/24】いつの間にかこんなのが入っていたので消す。
# from builtins import classmethod, object, None

##### 2021/12/16: 改行入り文字列リテラル使用のために必要
# https://qiita.com/tag1216/items/3447def88ed6b1d51d60
import textwrap

##### 【要検討】↓このインポートは必要？
##### 【NG】2021/12/13: QgsMapCanvasを試す
##### 【備考】QgsMapCanvasとiface.mapCanvas()との違い：
#     https://gis.stackexchange.com/questions/363363/difference-
#       between-iface-mapcanvas-and-qgsmapcanvas
from qgis.gui import (
    QgsMapCanvas,
    QgsVertexMarker,
    QgsMapCanvasItem,
    QgsRubberBand,
    )
from scipy.ndimage.interpolation import zoom


##### point shapeファイル作成に使用
#     --> see: PyQGIS_shapefileレイヤ作成テスト_20210315_
#              直接地物から_take2.txt
from qgis.PyQt.QtCore import QVariant


# 2021/11/06: KgmQpDataクラスおよびその派生クラスをインポート
# 2021/11/11: これを一旦ヤメにしていたが、復活
#             ∵KgmQpQgisIoの側がKgmQpDataを知り、その求めに
#               応えるのが筋
# from .kgm_qpd_core import *
# 2023/02/21: kgm_qpdsr_coreに変更
from .kgm_qpdsr_core import *

##### 2023/08/25: またpandas云々が出るのでコメントアウト。
# from pandas.core.tools.datetimes import _attempt_YYYYMMDD
import datetime

##### 2022/06/30: またいつの間にか「pandas」云々が入っている？
#                 当面コメントアウトしておく。
# from pandas._config.config import pp_options_list


##### 2024/03/24: メッセージボックスを使うために追加
# https://webbibouroku.com/Blog/Article/qgis3-python-messagebox
from PyQt5.QtWidgets import QMessageBox


##### from owslib.swe.common import Item


class KgmQpQgisIo:
    """
    KGMのデータとQGISのshapefile・レイヤなどとを紐付ける
    【2024/02/26】KgmDataDictManager内の処理をカプセル化
    """
    ##### 2021/11/05: KGMで扱う写真画像・メモ文字列などを
    # 標準の（KgmQpDataの）インスタンス属性として扱えるように。


    def __init__(self, kgm_qp_dt_inst: object):
        """
        コンストラクタ：
        kgm_qp_dt_inst：KgmQpDataのインスタンス
        """
        self._kgm_qp_data_instance = kgm_qp_dt_inst
        
        ##### 2026/02/26: KgmDataDictManagerにKgmQpQgisIo自身の
        #                 インスタンスへの参照を渡すために設定
        self.__my_instance = self               # 自分自身のインスタンス

        ##### 2021/12/05:
        #     KgmQpQgisioではQgisのレイヤ（=object）自体を管理
        #     それらへのアクセスは、アクセッサ経由に限定
        #     それらの名称（レイヤ名）は、KgmQpData側で管理
        ##### 2024/02/26:
        #     【改訂】'tracklog'と'trackpoints'を明示的に分離のため、
        #      従来のself.kgmtlg_layerをself.kgm_trackpoints_layerに名称変更
        self.__kgm_trackpoints_layer = object
        self.__kgmpic_layer = object

        ##### 2022/02/15: QGIS上での操作によるイベント駆動
        # self.__pp_selected_fid = False
        # ↑これはそもそもリストとして定義する要あり
        self.__pp_selected_fids = []


        ##### 2023/03/01: GPXのtracksのレイヤ名を表示用に使用
        #     2024/02/20：これで確定、アクセッサとして定義
        ##### 2024/02/26:
        #     【改訂】'tracklog'と'trackpoints'を明示的に分離のため、
        #      従来のself.tracks_layerをself.kgm_tracklog_layerに名称変更
        self.__kgm_tracklog_layer = object
        
        
        ##### 2024/02/25: KgmDataDictManagerのインスタンスへの参照用に使用
        self.__kgmdd_mgr = object
        
        
        ##### 2024/03/23: iface.mapCanvasをインスタンス変数に保存
        self.main_qgis_map_canvas = iface.mapCanvas()


    @property
    def kgm_trackpoints_layer(self) -> object:
        """ KGMのトラックログレイヤのgetter """
        return self.__kgm_trackpoints_layer

    @kgm_trackpoints_layer.setter
    def kgm_trackpoints_layer(self, layer: object) -> None:
        """
        【2024/02/26】改訂：
        KGMのtrackpoints_layerのsetter
        【kgm_trackpoints_layerセットの時点で起動】
        レイヤ表示名の変更によるイベント駆動
        """
        self.__kgm_trackpoints_layer = layer
        
        self.__kgm_trackpoints_layer.nameChanged.connect(
            self.tplayer_nameChangedSlot)

    @property
    def kgmpic_layer(self) -> object:
        """ KGMのphotopointレイヤのgetter """
        return self.__kgmpic_layer

    @kgmpic_layer.setter
    def kgmpic_layer(self, layer: object) -> None:
        """
        KGMのphotopointレイヤのsetter
        【kgmpic_layerセットの時点で起動】
        QGIS上での操作によるイベント駆動
        """
        self.__kgmpic_layer = layer
        
        '''
        【暫定：2024/03/08】
        どうもイベント駆動で妙なことが起こるようなので一旦コメントアウト
        self.__kgmpic_layer.selectionChanged.connect(
            self.pplayer_selectionChangedSlot)
        
        self.__kgmpic_layer.nameChanged.connect(
            self.pplayer_nameChangedSlot)
        '''
    
    ##### 2024/02/20: kgm_tracklog_layerのアクセッサ
    ##### 2024/02/26: 名称変更によるイベント駆動を追加
    @property
    def kgm_tracklog_layer(self) -> object:
        """ 【文言再考】GPXのtracksのレイヤ名を表示用に使用（getter） """
        return self.__kgm_tracklog_layer
    
    @kgm_tracklog_layer.setter
    def kgm_tracklog_layer(self, layer: object) -> None:
        """
        【文言再考】GPXのtracksのレイヤ名のsetter
        名称変更によるイベント駆動を追加
        """
        self.__kgm_tracklog_layer = layer
    
        self.__kgm_tracklog_layer.nameChanged.connect(
            self.tlglayer_nameChangedSlot)
    
    
    @property
    def kgmdd_mgr(self) -> object:
        """ KgmDataDictManagerのインスタンスへの参照のgetter """
        return self.__kgmdd_mgr
    
    @kgmdd_mgr.setter
    def kgmdd_mgr(self, inst_kgmdd_mgr: object):
        """ KgmDataDictManagerのインスタンスへの参照のsetter """
        self.__kgmdd_mgr = inst_kgmdd_mgr
    
    
    def amiok(self):
        print('【KgmQpQgisIo】KgmQpDataのインスタンスへの参照は、'\
          '{} です。'.format(self._kgm_qp_data_instance))
        
        
        '''
        【改訂：2024/03/20】これは廃止、KGMデータセット辞書から取得に統一
        print('【KgmQpQgisIo】KGMデータのあるフォルダへのパスは、'\
          '{} です。'.format(self._kgm_qp_data_instance.kgmqp_folderpath))
        '''
        
        
        
        ##### 2024/03/23: プロジェクトのCRSを指定
        #     最初にこれをやっておかないとiface.mapCanvas().setExtent(ext)が効かない。
        #【備考】2024/03/23はこれの原因解明・対処で半日以上を費やした（泣）
        #【出典】https://gis.stackexchange.com/questions/32139/
        #           is-it-possible-to-set-the-project-crs-via-a-python-command
        #####【備考】↓これはQGISの古いバージョン専用？
        ### if iface.mapCanvas().mapRenderer().hasCrsTransformEnabled():
        ###    my_crs = core.QgsCoordinateReferenceSystem(4326,core.QgsCoordinateReferenceSystem.EpsgCrsId)
        ### iface.mapCanvas().mapRenderer().setDestinationCrs(my_crs)
        
        #####【2024/03/23】QGIS 3.16では、↓これで動いた。
        #     ただし、"EPSG:4326"（=WGS84）だと、やはりsetExtentが効かない。
        # my_crs=QgsCoordinateReferenceSystem("EPSG:4326")
        ### "ESRI:102618"（JGD_2011_Japan_Zone 9）にしたら、setExtentできた。
        #    ただし、設定時にCRS変更の確認ウィンドウが出て煩わしい。今後要対策。
        #   【備考】かつ、今後国際版を作る際には、これでは当然NGのはず。
        #    Maybe言語選択に連動して切り替わるようにする？　今後要検討。
        
        #####【2024/03/24】CRS変更の確認ウィンドウ表示を一時的に止める。
        #    【訂正：2024/03/24】ここでは不要らしい。
        # iface.mainWindow().blockSignals(True)
        
        #####【2024/03/24】"ESRI:102618"は認識されない模様。
        # my_crs=QgsCoordinateReferenceSystem("ESRI:102618")
        #####【2024/03/24】↓「JGD2011 / Japan Plane Rectangular CS IX」
        # my_crs = QgsCoordinateReferenceSystem("EPSG:6677")
        #####【2024/03/24】むしろここでWGS84に明示的に設定？
        my_crs=QgsCoordinateReferenceSystem("EPSG:4326")
        
        print('【KgmQpQgisIo: amioke】my_crsの値は：{}、成否は：{}'.format(my_crs, my_crs.isValid()))
        
        QgsProject.instance().setCrs(my_crs)
        iface.mapCanvas().refresh()
        
        #####【2024/03/24】この時点でのプロジェクトのCRSを確認。
        project_crs = QgsProject.instance().crs()
        
        print('【KgmQpQgisIo: amioke】project_crsの値は：{}'.format(project_crs))
        
        
        #####【2024/03/24】CRS変更の確認ウィンドウ表示を再開。
        #    【訂正：2024/03/24】ここでは不要らしい。
        # iface.mainWindow().blockSignals(False)
        
    
    
    def create_instances(self):
        """
        2024/02/26:
        KgmDataDictManagerをKgmQpDataなどから隠すため
        KgmQpQgisIoにカプセル化する。
        そのため、KgmDataDictManagerのインスタンス化も
        KgmQpQgisIoの中で実施
        """
        
        
        ##### KgmDataDictManagerのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        self.kgmdd_mgr = KgmDataDictManager(self._kgm_qp_data_instance, self.__my_instance)

        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【KgmQpQgisIo_create_instances】KgmDataDictManagerのインスタンスへの参照は、'\
                  '{} です。'.format(self.kgmdd_mgr))
        
        self.kgmdd_mgr.amiok()
        
        
    
    
    
    def prepare_kgm_datasets(self):
        """
        2024/02/26:
        KgmDataDictManagerクラスを外部から隠すため
        KgmQpQgisIo内にそれを呼ぶ関数を置く
        """
        
        datasets_count = self.kgmdd_mgr.initialize_kgm_datasets()
        
        return datasets_count
    
    
    
    def get_default_tptlg_layer_display_name(self) -> str:
        """
        2024/03/07:
        既存のKGMデータセット辞書から、最初のデータセットを
        参照し、デフォルトのtracklogレイヤ表示名を返す。
        """
        ##### 2024/03/07: インスタンス変数の参照を関数冒頭で明示
        dct_kgmdss = self.kgmdd_mgr.kgm_datasets
        
        if dct_kgmdss:
            """
            念のためKGMデータセットの既存を確認し、
            既存のうち最初のデータセットを選択して、
            そのdict_items型ビューを取得。
            """
            
            layer_info_key = 'tracklog'
            layer_attribute_key = 'layer_display_name'
            
            kgm_dataset_dict_items = list(dct_kgmdss.items())[0]
            
            tptlg_lyr_dsp_name = self.kgmdd_mgr.get_layer_attribute_value_from_kgm_dataset(\
                                            kgm_dataset_dict_items, \
                                            layer_info_key, \
                                            layer_attribute_key \
                                            )
        else:
            tptlg_lyr_dsp_name = None   # 空文字列でなくNoneを返す
            print('【KgmQpQgisIo: get_default_tptlg_layer_display_name】【要調査！】dct_kgmdssの値が、'\
                  '{} です。'.format(dct_kgmdss))
        
        return tptlg_lyr_dsp_name
    
    
    
    def get_default_pp_layer_source_name(self) -> str:
        """
        2024/03/07:
        既存のKGMデータセット辞書から、最初のデータセットを
        参照し、デフォルトのphotopointのソースのファイル名を返す。
        【要検討】KGMデータフォルダにshpファイルはある場合？
        """
        ##### 2024/03/07: インスタンス変数の参照を関数冒頭で明示
        dct_kgmdss = self.kgmdd_mgr.kgm_datasets
        
        if dct_kgmdss:
            """
            KGMデータセットの既存を確認し、
            既存のうち最初のデータセットを選択して、
            そのdict_items型ビューを取得。
            """
            
            layer_info_key = 'photopoints'
            layer_attribute_key = 'layer_source'
            
            kgm_dataset_dict_items = list(dct_kgmdss.items())[0]
            
            pp_lyr_source_path = self.kgmdd_mgr.get_layer_attribute_value_from_kgm_dataset(\
                                            kgm_dataset_dict_items, \
                                            layer_info_key, \
                                            layer_attribute_key \
                                            )
            pp_lyr_source_name = Path(pp_lyr_source_path).name
            
        else:
            """
            既存のKGMデータセットなし
             → 空文字列でなくNoneを返す
            """
            pp_lyr_source_name = None   # 空文字列でなくNoneを返す
            print('【KgmQpQgisIo: get_default_pp_layer_display_name】既存のdct_kgmdssはありません。')
        
        return pp_lyr_source_name
    
    
    
    def get_layernames_list_in_kgmdss_using_kgmdd_mgr(self):
        """
        2024/02/26:
        KgmDataDictManagerのインスタンス変数により
        現在のKGMデータセットを参照し、
        その中に含まれる'tracklog'レイヤの
        レイヤ名一覧のリストを返す。
        （１つもなければ空リストを返す。）
        処理の実態はKgmDataDictManager内で実施
        """
        
        list_tlglyrs = self.kgmdd_mgr.get_layernames_list_in_kgmdss()
    
        return list_tlglyrs
    
    
    def prepare_default_kgmqp_data_path(self) -> object:
        """
        2024/03/07:
        KgmDataDictManagerにより、KGMデータのあるフォルダへの
        デフォルトのパスをpathlibオブジェクトとして返す。
        """
        
        default_kgmqp_data_path =  self.kgmdd_mgr.get_default_kgmqp_data_path()
        
        return default_kgmqp_data_path
    
    
    
    
    def get_existing_layers_as_dict(self) -> dict:
        """
        2024/02/22:
        現在のMapLayersに登録された全レイヤとそのソースとを走査し、
        辞書として返す。
        今後はMaplayersの登録内容の参照・更新は、すべてこの関数に
        より行う。
        【改訂：2024/02/26】
        辞書にレイヤオブジェクトそれ自体への参照も含める
        （↑キー名'layer_obj'で）
        【改訂：2024/03/05】
        「dct_layer_name」を「dct_layer_display_name」に改称
        「layer_name」を「layer_display_name」に改称
        （KGMDSSとの対応関係を明示のため）
        ☆戻り値の辞書はインスタンス変数などに保存せず、都度参照する
        """
        dct_layers = dict()
        
        for ix, lyr in enumerate(QgsProject.instance().mapLayers().values()):
            try:
                dpr = lyr.dataProvider()
            except:
                print('【get_existing_layers_as_dict】dataProviderのないレイヤ：'\
                      '{}'.format(lyr.name()))
                pass
            else:
                try:
                    """
                    【改訂：2024/04/19】
                    dataProviderはあるがdataSourceUriがない場合への対処
                    （例）OSMの属性情報（layername=other_relations）レイヤ
                    とりあえずこの種のレイヤは無視しレイヤ辞書から除外
                    """
                    src = dpr.dataSourceUri()
                except:
                    print('【get_existing_layers_as_dict】dataSourceUriのないレイヤ：'\
                          '{}'.format(lyr.name()))
                    pass
                else:
                    
                    ##### src = dpr.dataSourceUri()        # レイヤのソースURI
    
                    print('【get_existing_layers_as_dict】dataSourceUriの値は：'\
                          '{}です。'.format(src))
    
                    src_parsed = self.parse_data_source_uri(src)
    
                    dct_layer_display_name = lyr.name()
                    dct_layer_source_filepath = src_parsed[0]     # [0]がソースファイルのフルパス
                    dct_layer_source_suffix = src_parsed[1]       # [1]が（tlgレイヤの）追加名
                    
                    layer_dict = {
                        ix: {
                            'layer_obj': lyr, \
                            'layer_display_name': dct_layer_display_name, \
                            'layer_source_path': dct_layer_source_filepath, \
                            'layer_source_suffix': dct_layer_source_suffix \
                            }
                        }
                    
                    print('【get_existing_layers_as_dict】現時点のlayer_dictの値は：'\
                                      '{}です。'.format(layer_dict))                
                    
                    dct_layers.update(layer_dict)
        
        print('【get_existing_layers_as_dict】戻る直前のdct_layersの値は：'\
                          '{}です。'.format(dct_layers))
        
        return dct_layers
    
    
    def find_layer_in_dict_layers_by_layer_display_name( \
                                            self, \
                                            lyr_dsp_name: str \
                                            ) -> object:
        """
        【2024/03/24】
        引数で渡したレイヤ表示名と一致するレイヤをdct_layersから取得し、
        そのレイヤオブジェクトを返す。
        """
        
        key_lyr_dsp_name = 'layer_display_name'
        key_lyr_object = 'layer_obj'
        
        dct_layers = self.get_existing_layers_as_dict()
        
        for item in dct_layers.items():
            """
            dct_layers内のレイヤを走査
            """
            item_name, item_value = item   # ビューをアンパック
            item_layer_dsp_name = item_value.get(key_lyr_dsp_name)
            
            if (item_layer_dsp_name == lyr_dsp_name):
                """
                レイヤ表示名が一致
                """
                found_layer_object = item_value.get(key_lyr_object)
            else:
                found_layer_object = None
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【find_layer_in_dict_layers_by_layer_display_name】found_layer_objectの値は、'\
                  '{} です。'.format(found_layer_object))
        
        return found_layer_object
    
    
    
    def set_tptlg_layer(self, lyr_dsp_name: str) -> str:
        """
        QGIS上のトラックポイントレイヤを選択／作成してレイヤ名を返す
        【2024/02/26】KgmDataDictManager内の処理をカプセル化
        　かつ、'tracklog'と'trackpoints'とを明示的に分離しつつ
        　一括して処理
        　（趣旨：'tracklog'と'trackpoints'がQGIS上では別レイヤであることを
        　　KgmQpDataから隠す）
        以下の４つの場合それぞれの処理を明示的に記述
        (1)KGMデータセット辞書に当該'tracklog'レイヤが存在
        (2)KGMデータセット辞書には存在しないが、QGIS上には存在
        　（KGMデータセットを新規作成・追加の処理の途上）
        【変更】(3)KGMデータセット辞書・QGIS上には存在しないが、
        　　　　過去に作成したppのshpファイルが存在
        　　　　↑この場合の処理はppレイヤ関数に一任
        (3)上記(1)～(2)のいずれも存在しない
        【今後要検討？】レイヤ自体への参照はself.kgm_trackpoints_layerで実施
        【改訂：2024/03/05】
        引数を「lyr_name」から「lyr_id_name_commonpart」に変更
        QGISのMapCanvas上の表示名ではなく、ソース名に基づいて
        KGMDSSに記録された、一意なレイヤ識別名を使うことを明示
        【再改訂：2024/03/05】
        この関数はKgmQpDataから呼ばれるので、引数は「lyr_dsp_name」になる。
        これをこの関数内でKGMデータセット辞書により「lyr_id_name_commonpart」
        に変換して処理する。
        【再々改訂：2024/03/06】
        「lyr_id_name_commonpart」は放棄（処理が無駄に複雑化する）
        代わりに、lyr_dsp_nameに対応するKGMデータセットを特定し、
        そのビュー情報により処理する。
        【追加改訂：2024/03/08】
        レイヤ表示名指定なしの指標を空文字列からNoneに変更
        """
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【set_tptlg_layer】lyr_dsp_nameの値は、'\
                  '{} です。'.format(lyr_dsp_name))
        
        if lyr_dsp_name:
            """
            lyr_dsp_nameの指定あり
            """
            
            '''
            lyr_id_name_commonpart = self.kgmdd_mgr.find_idname_commonpart_by_lyr_dsp_name(lyr_dsp_name)
            tlg_lyr = self.select_tlg_layer(lyr_id_name_commonpart)
            '''
            
            # レイヤ表示名から、それを含むKGMデータセットを検索
            kgmds_view = self.kgmdd_mgr.find_kgm_detaset_by_layer_display_name(lyr_dsp_name)
            
            if kgmds_view:
                """
                (1)KGMデータセット辞書に当該'tracklog'レイヤの
                　レイヤ表示名が存在
                """
                tlg_lyr = self.select_tlg_layer_in_kgmds(kgmds_view)
                tptlg_layer_common_name = tlg_lyr.name()
            else:
                """
                KGMデータセット辞書には存在しない
                 → MapLayersを探す
                """
                
                ##### 【要検討：2024/03/06】QGISのMapLayersに同じ表示名のレイヤは存在可能
                tlg_lyr = self.kgmdd_mgr.select_layer_in_qgis_mapcanvas_by_layer_display_name(\
                                                        layer_display_name \
                                                        )
                if tlg_lyr:
                    """
                    QGIS MapCanvasにレイヤが存在
                    """
                    tptlg_layer_common_name = tlg_lyr.name()
                else:
                    """
                    QGIS MapCanvasにも存在しない
                    レイヤ名を指定しているのに該当レイヤがどこにもない
                    → これは本来ないはず。ワーニングのみ出す。
                    """
                    print('【警告！】指定されたレイヤ名{}のものが見つかりません。'.format(lyr_dsp_name))
                
        else:
            """
            lyr_dsp_nameが空文字列なら、レイヤを新規作成
            【改訂：2024/03/08】
            レイヤ表示名指定なしの指標を空文字列からNoneに変更
            """
            tptlg_layer_common_name = self.create_tlg_layer()  # 新規作成
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【set_tptlg_layer】tptlg_layer_common_nameの値は、'\
                  '{}です。'.format(tptlg_layer_common_name))
        
        return tptlg_layer_common_name
        
        
    def absorb_tracks_track_points_differences(self, tlg_layers: list) -> object:
        """
        'tracks'・'track_points'双方対応のための修正
        """
        
        for tlg_layer in tlg_layers:
            ### 2023/09/30: 処理対象レイヤ名を確認
            print('【absorb_tracks_track_points_differences】処理対象レイヤ名は、'\
                  '{}です。'.format(tlg_layer.name()))
            
            if tlg_layer.name().find('track_points') > 0:
                ### 2023/09/30: tradk_pointsレイヤあり→それを持って帰る
                print('【absorb_tracks_track_points_differences】tradk_pointsレイヤ名は、'\
                  '{}です。'.format(tlg_layer.name()))
            else:
                ##### 2023/09/30:【暫定】track_pointsでないほうをtracksとみなす
                #     ただしこれではQGZに複数トラックある場合がNGのはず・・・
                
                print('【警告】track_pointsレイヤがありません！')
        
        return tlg_layer
    
    
    
    def create_tptlg_layers_from_gpx_file_path(self, \
                                gpx_file_path: object \
                                ) -> list:
        """
        【2024/03/19】
        pathlib型のフルパスで指定されたgpxファイルにより、
        QGISにtrackpointsとtracklogのレイヤを作り、
        両レイヤのオブジェクト参照の配列を返す。
        GPXレイヤの作成はJean-Francois-Bourdonの方法による。
        【備考】以前のcreate_tlg_layerとcreate_trackpoint_layer_from_gpxを再編。
        """
        
        gpx_filename = gpx_file_path.name
        gpx_filebase = gpx_file_path.stem
        gpx_fileext = gpx_file_path.suffix
        str_gpx_file_path = str(gpx_file_path)
        
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【create_trackpoint_layer_from_gpx】gpx_filebaseの値は、'\
                  '{}です。'.format(gpx_filebase))
            print('【create_trackpoint_layer_from_gpx】gpx_fileextの値は、'\
                  '{}です。'.format(gpx_fileext))

        names = ["tracks","track_points"]
        
        for name in names:
            
            
            
            #####【2024/03/24】CRS変更の確認ウィンドウ表示を一時的に止める。
            # iface.mainWindow().blockSignals(True)
            
            layer = iface.addVectorLayer(str_gpx_file_path + "|layername=" + name, gpx_filebase, "ogr")
            
            #####【2024/03/24】CRS変更の確認ウィンドウ表示を再開。
            # iface.mainWindow().blockSignals(False)
            
            #####【2024/03/24】ここでlayerのCRSを明示的に設定。
            my_crs=QgsCoordinateReferenceSystem("EPSG:4326")
            print('【KgmQpQgisIo: create_tptlg_layers_from_gpx_file_path】my_crsの値は：{}、成否は：{}'.format(my_crs, my_crs.isValid()))
            
            layer.setCrs(my_crs)
            print('【KgmQpQgisIo: create_tptlg_layers_from_gpx_file_path】layerのCRSの値は：{}'.format(layer.crs()))
            
            
            
            ##### 2023/02/23: QGIS3.16と3.22との挙動の違いに対処
            #                 qgis_gpx_layername = gpx_filebase + " " + name
            gpx_layername_temp = layer.name()

            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【create_trackpoint_layer_from_gpx】読み込み時のlayer.name()の値は、'\
                      '{}です。'.format(gpx_layername_temp))

            if gpx_layername_temp.find(name) < 0:
                gpx_layername_temp = gpx_layername_temp + ' ' + name
                layer.setName(gpx_layername_temp)

            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【create_trackpoint_layer_from_gpx】調整後のlayer.name()の値は、'\
                      '{}です。'.format(layer.name()))
            
            
            if (name == 'track_points'):
                """
                track_pointsの場合
                """
                
                self.set_symbology_of_tpt_layer(layer)
                
                ##### 2024/03/08: 【暫定】「のtrack_points」をインスタンス変数から取得
                tp_dsp_name_suffix  = self.kgmdd_mgr.tp_displayname_suffix
                ##### 2024/03/19: インスタンス変数を排除
                # self.kgm_trackpoints_layer.setName(self.kgm_tracklog_layer.name() + tp_dsp_name_suffix)
                
                kgm_trackpoints_layer = layer
                kgm_trackpoints_layer_name = kgm_trackpoints_layer.name() + tp_dsp_name_suffix
                
            elif (name == 'tracks'):
                """
                tracksの場合
                """
                qgis_gpx_layername = gpx_layername_temp
                if self._kgm_qp_data_instance._debug_mode == 'Y':
                    print('【create_trackpoint_layer_from_gpx】qgis_gpx_layernameの値は、'\
                          '{} です。'.format(qgis_gpx_layername))
                    print ('【create_trackpoint_layer_from_gpx】layer.getFeature(0).attribute("name")の値は、'\
                           '{} です。'.format(layer.getFeature(0).attribute('name')))
                layer.setName(layer.getFeature(0).attribute('name'))
                
                # self.kgm_tracklog_layer = layer
                
                self.set_symbology_of_tlg_layer(layer)
                
                kgm_tracklog_layer = layer
                
                #####【2024/04/27】その前にtracklogレイヤ名の調整を実施。
                # kgm_tracklogt_layer_name = kgm_tracklog_layer.name()
                
                
                #####【2024/04/27】作成中のレイヤ名を含む既存レイヤがある場合に対処。
                
                layername_adjusted = self.add_suffix_to_tlg_layername(kgm_tracklog_layer)
                kgm_tracklog_layer.setName(layername_adjusted)
                
                kgm_tracklogt_layer_name = kgm_tracklog_layer.name()
                
                
        kgm_tptlg_layers = [kgm_trackpoints_layer, kgm_tracklog_layer]
        
        
        return kgm_tptlg_layers



    def add_suffix_to_tlg_layername(self, tlg_layer: object) -> str:
        """
        【2024/04/27】
        新規作成中のtptlgレイヤ名文字列を含むものが既存のKGMデータ辞書にないか調べ
        該当のレイヤがあれば、新規作成中のレイヤ名に連番を付加。
        備考：同一日に別個の端末で記録した複数データを読み込む場合に対処。
        【修正：2024/04/28】
        新規作成中の「tlg」レイヤに対する処理であることを明記。
        レイヤ名に付加する連番の指定方法を抜本改訂。
        """
        
        tlg_layer_name_original = tlg_layer.name()
        
        
        try:
            """
            KGMデータセット辞書の存否を確認。
            """
            tlg_layernames_in_kgmdss = self.kgmdd_mgr.get_layernames_list_in_kgmdss()
        except:
            """
            KGMデータセット辞書がなければレイヤ名を変更せず戻る。
            """
            return tlg_layer_name_original
        else:
            """
            KGMデータセット辞書内の既存レイヤ名と被らぬよう調整。
            """
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【add_suffix_to_tlg_layername】既存のtlgレイヤ名一覧：'\
                      '{}'.format(tlg_layernames_in_kgmdss))
            
            
            #####【2024/04/28】KGMデータセット辞書内の既存tlgレイヤ名を昇順にソート
            #     これによりsuffixのインクリメントを１ずつに統一できるはず
            tlg_layernames_in_kgmdss_sorted = sorted(tlg_layernames_in_kgmdss)
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【add_suffix_to_tlg_layername】ソート後の既存のtlgレイヤ名一覧：'\
                      '{}'.format(tlg_layernames_in_kgmdss_sorted))
            
            tlg_layer_name_temp = tlg_layer_name_original    # ここで初期値を設定
            int_suffix = 0  # suffixを整数として明示的に定義、これをインクリメントさせる。
            
            for name in tlg_layernames_in_kgmdss_sorted:
                """
                【改訂：2024/04/28】
                KGMデータセット辞書中の既存tlgレイヤ名一覧を昇順にソートし、
                新規作成中のtptlgレイヤ名（temp名）と同一のものがないかを
                forループで順番に検査し、
                (1)なければ、その時点のtemp名をそのまま保持。
                (2)完全一致のものがあれば、suffixをインクリメントし、
                　これを付加したものを新たなtemp名とする
                このループが終了した時点で、temp名をrevised名に代入し、
                そのrevised名を持ってreturnする。
                """
                
                ### ix = name.rfind(tlg_layer_name_original)
                ix = name.rfind(tlg_layer_name_temp)
                
                ### tlg_layer_name_revised = tlg_layer_name_original    # これを初期値にしておく
                
                if self._kgm_qp_data_instance._debug_mode == 'Y':
                    print('【add_suffix_to_tlg_layername】現在のnameとixの値：'\
                          'name = {}; ix = {}'.format(name, ix))
                
                if (ix < 0):
                    """
                    (1)作成中のレイヤ名が含まれない
                     → tlg_layer_name_tempをそのまま保持
                    """
                    
                    ### tlg_layer_name_revised = tlg_layer_name_original
                    
                    pass
                    
                elif (ix == 0):
                    """
                    (2)レイヤ名が完全一致
                     → int_suffixをインクリメントし、
                     　それをtlg_layer_name_originalに付加したものを、
                     　新たなtlg_layer_name_tempとする。
                    """
                    
                    int_suffix += 1     # Pythonではインクリメントをこう書く
                    
                    tlg_layer_name_temp = tlg_layer_name_original + '-' + f'{int_suffix:0>2}'
                    
                    print('【add_suffix_to_tlg_layername】現在のtlg_layer_name_tempとint_suffixの値：'\
                          'tlg_layer_name_temp = {}; int_suffix = {}'.format(tlg_layer_name_temp, int_suffix))
                    
                else:
                    """
                    作成中のレイヤ名を含むが、完全一致ではない
                    tlg_layernames_in_kgmdss_sortedは昇順ソートずみだから
                    現在のtlg_layer_name_tempと完全一致しないのは
                    nameの末尾がsuffixでない場合のみのはず。
                     → tlg_layer_name_tempをそのまま保持
                    """
                    
                    pass
                
            #####【2024/04/28】forループが終了した時点でtempをrevisedに代入
            tlg_layer_name_revised = tlg_layer_name_temp
        
        return tlg_layer_name_revised


    def set_symbology_of_tpt_layer(self, layer: object) -> None:
        """
        【2024/03/19】
        トラックポイントレイヤのシンボルを設定。
        当面はハードコードで実施。
        【暫定】デフォルトのシンボルへのパスはインスタンス変数から取得。
        　（当面、このパスは文字列型で定義されているのを継承）
        """
        style_file_path = os.path.join(
            self._kgm_qp_data_instance.kgmqp_root_path,
            'KgmQpdSR_trackpoint_black05mm.qml')
        layer.loadNamedStyle(style_file_path)

        ##### 2023/03/02: 縮尺依存表示を設定
        # ☆シンボルファイル読込みより後でないと上書きされる
        layer.setScaleBasedVisibility(True)
        layer.setMinimumScale(500.0)
        layer.setMaximumScale(0.0)
    
    
    def set_symbology_of_tlg_layer(self, layer: object) -> None:
        """
        【2024/03/19】
        トラックポイントレイヤのシンボルを設定。
        当面はハードコードで実施。
        【暫定】デフォルトのシンボルへのパスはインスタンス変数から取得。
        　（当面、このパスは文字列型で定義されているのを継承）
        """
        
        ##### 2023/03/02: tracksのシンボルをred1mmに
        style_file_path = os.path.join(
            self._kgm_qp_data_instance.kgmqp_root_path,
            'KgmQpdSR_trackline_red1mm.qml')
        layer.loadNamedStyle(style_file_path)
    
    
    def find_existing_kgmdss(self, kgmdss: dict) -> dict:
        """
        2024/02/21:
        現在のKGM datasetsの値（辞書型）を引数として受け取り、
        既存のトラックログレイヤを探し、
        そのレイヤ名をもとにKGMデータ（track, trackPoints, 撮影地点）を特定し、
        それぞれのレイヤ名とソースを調べて、
        必要に応じ（レイヤ名が同一になる場合など）レイヤ名を変更して、
        更新したKGM datasetsの値を辞書型データとして返す
        """
        
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                dpr = lyr.dataProvider()
            except:
                print('【set_tracklog_layer】dataProviderのないレイヤ：'\
                      '{}'.format(lyr.name()))
                pass
            else:
                src = dpr.dataSourceUri()        # レイヤのソースURI

                print('【set_tracklog_layer】dataSourceUriの値は：'\
                      '{}です。'.format(src))

                src_parsed = self.parse_data_source_uri(src)

                src_filepath = src_parsed[0]     # [0]がソースファイルのフルパス
                # src_suffix = src_parsed[1]       # [1]が（tlgレイヤの）追加名

                if src_filepath.find('.gpx') >= 0:       # .gpxファイルあり
                    
                    kgm_dateset_name = self.set_kgmdataset_name(lyr)
                    tracklog_layer_name = lyr.name()
                    tracklog_source_filepath = src_filepath
                    
                    ##### 2024/02/21: .gpxファイルのsrc_filepathに基づき、
                    #     同じKGMフォルダ内にあるtrackpoint・sphotopointsを探し出し、
                    #     ３つのレイヤをまとめたKGMデータ辞書を作る
                    
                    dct_kgm_dataset = self.construct_kgm_dataset(tracklog_source_filepath)
                    
                    print('【find_existing_kgmdss】dct_kgm_datasetの値は：'\
                          '{}です。'.format(dct_kgm_dataset))
                    
                else:
                    print('【list_existing_tlgs】.gpxレイヤではありません：'\
                          '{}'.format(src_filepath))
        
        ##### 2024/02/21: これはNG！　もとの辞書自体が更新されるのでそれをそのまま使う！
        # kgmdss_updated = kgmdss.update(dct_kgm_dataset)
        
        kgmdss.update(dct_kgm_dataset)
        
        print('【find_existing_kgmdss】戻る直前のkgmdssの値は：'\
                          '{}です。'.format(kgmdss))
        
        print('【find_existing_kgmdss】戻る直前のdct_kgm_datasetの値は：'\
                          '{}です。'.format(dct_kgm_dataset))
        
        return kgmdss


    def parse_data_source_uri(self, dsu: str) -> list:
        """
        2022/05/26:
        dataSourceUri（ローカルファイルの）を以下の要素に分解
        １．ソースファイルのフルパス
        ２．「|」以降の部分
        """

        try:
            """ dsuを「|」で分割 """
            sourcefile_path, layername_suffix = dsu.split('|')
        except:
            """ 「|」がない場合（.shpなど）の処理 """
            sourcefile_path = dsu
            layername_suffix = ''
        else:
            pass

        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【parse_data_source_uri】sourcefile_pathの値は、'\
                  '{} です。'.format(sourcefile_path))
            print('【parse_data_source_uri】layername_suffixの値は、'\
                  '{} です。'.format(layername_suffix))

        dsu_parsed = [sourcefile_path, layername_suffix]

        return dsu_parsed






    def set_kgmdataset_name(self, lyr: object) -> str:
        """
        QGISに既登録のKGMデータの（tracklogの）レイヤを引数で受け取り、
        【要検討】必要に応じ（レイヤ名が同一になる場合など）レイヤ名を変更して、
        調整ずみのレイヤ名を返す
        """
        adjusted_name = lyr.name()
        
        return adjusted_name


    def find_dirname_of_layersourse(self, layername: str) -> str:
        """
        2022/05/26:
        レイヤのソースファイルのあるフォルダ名を返す
        """
        src_dirname = ''
        for lyr in QgsProject.instance().mapLayers().values():
            if lyr.name() == layername:
                try:
                    dpr = lyr.dataProvider()
                except:
                    print('【set_tracklog_layer】dataProviderのないレイヤ：'\
                          '{}'.format(lyr.name()))
                else:
                    src = dpr.dataSourceUri()        # レイヤのソース
                    print('【find_dirname_of_layersourse】dataSourceUriの値は：'\
                          '{}です。'.format(src))

                    src_parsed = self.parse_data_source_uri(src)

                    src_filepath = src_parsed[0]     # [0]がソースファイルのフルパス
                    sec_suffix = src_parsed[1]       # [1]が（tlgレイヤの）追加名

                    src_dirname = os.path.dirname(src_filepath)
                    print('【find_dirname_of_layersourse】src_dirnameの値は：'\
                          '{}です。'.format(src_dirname))

        return src_dirname


    def find_layers_by_sourcepath(self, plb_srcpath: object) -> list:
        """
        2024/02/21:
        QGISの既登録レイヤから、引数で指定したソースパスに対応するものを選択
        該当するレイヤをリストで返す（tracksとtrackpointsのような場合があるため）
        今後この処理はすべてこの関数に統一
        【げろげろ】Windowsでos.path.joinすると、joinした部分の区切り記号が
        「\」になるらしい？！
        これをそのままにしていると、dataSourceUriから切り出したフルパスと
        一致しない結果になる？！
        ∴今後はpathlib使用に順次移行する
        """
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【find_layers_by_sourcepath】plb_srcpathの値は、'\
                  '{} です。'.format(plb_srcpath))
        
        
        list_layers = []
        for lyr in QgsProject.instance().mapLayers().values():
            try:
                dpr = lyr.dataProvider()
            except:
                print('【find_layer_by_sourcepath】dataProviderのないレイヤ：'\
                      '{}'.format(lyr.name()))
                pass
            else:
                src = dpr.dataSourceUri()        # レイヤのソースURI

                print('【find_layer_by_sourcepath】dataSourceUriの値は：'\
                      '{}です。'.format(src))

                src_parsed = self.parse_data_source_uri(src)

                src_filepath = src_parsed[0]     # [0]がソースファイルのフルパス
                # src_suffix = src_parsed[1]       # [1]が（tlgレイヤの）追加名
                
                
                # plb_src_filepath = PurePath(src_filepath)
                plb_src_filepath = Path(src_filepath)
                
                print('【find_layer_by_sourcepath】plb_src_filepathの値は：'\
                      '{}です。'.format(plb_src_filepath))
                print('【find_layer_by_sourcepath】plb_srcpathの値は：'\
                      '{}です。'.format(plb_srcpath))
                
                if (plb_src_filepath == plb_srcpath):
                    print('【find_layer_by_sourcepath】一致しました！')
                    list_layers.append(lyr)
                    print('【find_layer_by_sourcepath】list_layersの値は：'\
                          '{}です。'.format(list_layers))
                else:
                    print('【find_layer_by_sourcepath】一致しません（泣）')
                
        return list_layers
    
    
    
    
    def get_kgmqp_tlgfile_path_in_assigned_kgmdir(self, kgmqp_folder_path: object) -> object:
        """
        2024/03/08:
        トラックログレイヤを新規・追加作成するため、
        指定されたKGMデータフォルダ内の.gpxファイルを検知し、
        それへのフルパスを返す。
        （以前のget_kgmqp_tlgfile_path_in_default_kgmdirをリライト）
        gpxファイルの検索はKgmQpDataのget_list_of_files_using_globで実施。
        【備考】結果はpathlibのオブジェクトで返す。
        """
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【get_kgmqp_tlgfile_path_in_assigned_kgmdir】kgmqp_folder_pathの値は、'\
                  '{} です。'.format(kgmqp_folder_path))
        
        # str_glob_target = str(kgmqp_folder_path / Path('*.gpx'))
        
        root_criteria = ''
        ext_criteria = '(gpx|GPX)'
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【get_kgmqp_tlgfile_path_in_assigned_kgmdir】root_criteriaの値は、'\
                  '{} です。'.format(root_criteria))
            print('【get_kgmqp_tlgfile_path_in_assigned_kgmdir】ext_criteriaの値は、'\
                  '{} です。'.format(ext_criteria))
        
        list_gpx_files = self._kgm_qp_data_instance.get_list_of_files_using_glob(\
                                            kgmqp_folder_path, \
                                            root_criteria, \
                                            ext_criteria
                                            )
        
        ##### 2024/03/08: 複数あるとき・見つからないときなどのエラー処理を今後検討
        gpx_file_name = list_gpx_files[0]
        
        gpx_file_fullpath = kgmqp_folder_path / Path(gpx_file_name)
        
        print('【get_kgmqp_tlgfile_path_in_assigned_kgmdir】gpxファイルへのパスは、'\
              '{} です。'.format(gpx_file_fullpath))
        
        return gpx_file_fullpath
    
    
    
    def set_pp_layer(self, \
                     kgmqp_folderpath: object, \
                     kgm_tracklog_layer: object, \
                     kgm_trackpoints_layer: object, \
                     exif_timeoffset: datetime \
                     ) -> object:
        """
        2024/03/08:
        QGIS上のPhotopointレイヤを選択／作成してレイヤ名を返す。
        KgmQpPhotopointsのset_kgmqp_pplayerとの関係を全面見直し、
        実質の処理をこっちで担うことに変更。
        引数はKGMデータのあるフォルダのpathlibオブジェクト
        戻り値はphotopointレイヤの表示名文字列
        この関数内では、
        KGMデータフォルダが指定された（ie.新規読込みまたは追加）
        場合のみを扱い、
        １．フォルダ内のphotopoints既存shpファイルの有無を判定し、
        　(1)あれば（当座）その最初のものをppレイヤに登録する
        　(2)なければ、ppレイヤの新規作成関数を呼ぶ
        【改訂：2024/03/19】
        戻り値をphotopointsレイヤオブジェクトへの参照に変更。
        KGMデータセット辞書の更新は別関数で実施。
        インスタンス変数参照回避のため引数にkgm_tracklog_layerを追加
        【改訂：2024/03/24】
        引数にkgm_trackpoints_layerも追加。
        【改訂：2024/03/27】
        引数にexif_timeoffsetも追加。Photopointsレイヤ新規作成時に、
        これによりEXIF日時とUTC日時との時差を補正。
        """
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【KgmQpQgisIo: set_pp_layer】kgmqp_folderpathの値は、'\
                  '{}です。'.format(kgmqp_folderpath))
        
        if not kgmqp_folderpath:
            """
            Noneで判定。KGMデータフォルダ指定なし
            """
            kgm_photopoints_layer = None  # photopointsレイヤ参照をNoneに設定
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: set_pp_layer】kgm_photopoints_layerの値を、'\
                      '{}に設定しました。'.format(kgm_photopoints_layer))
        else:
            """
            KGMデータフォルダ指定あり
            """
            
            ##### フォルダ内に既存shpファイルがあるかを判定
            str_kgmqp_folderpath = str(kgmqp_folderpath)
            
            glob_root_criteria = ''
            glob_ext_criteria = '(shp|SHP)'
            
            shpfiles = self._kgm_qp_data_instance.get_list_of_files_using_glob(\
                                            str_kgmqp_folderpath, \
                                            glob_root_criteria, \
                                            glob_ext_criteria)
            
            ##### 2024/03/08:【暫定】リストの最初のものに限定
            ##### 2024/03/10: 【NG！】これだと既存shpなし時にエラーになる！
            # ppsource_shpfile = shpfiles[0]
            
            ##### 2024/03/10: 既存shpなし判断と処理を改訂
            # if ppsource_shpfile:
            if shpfiles:
                """
                既存shpファイルがあれば、それによりppレイヤを作成
                """
                
                ##### 2024/03/10: 暫定】リストの最初のものに限定
                ppsource_shpfile = shpfiles[0]
                
                #     【要検討】KGMのppレイヤ以外のshpファイルがある場合？
                ##### 2024/03/08: 【暫定】「の撮影地点」をインスタンス変数から取得
                #     【暫定】レイヤ表示名はKgmQpDataのtlglyr_nameから作成
                pp_dsp_name_suffix  = self.kgmdd_mgr.pp_displayname_suffix
                
                
                pp_lyr_dsp_name = kgm_tracklog_layer.name() + pp_dsp_name_suffix
                
                ##### 2024/03/08:【重要！】引数をkgmqp_folderpathに変更したことに
                #     伴い、QgsVectorLayerの第１引数はこれとfilenameをつなげたもの
                #     にする必要があった！
                
                str_layer_path = str(kgmqp_folderpath / Path(ppsource_shpfile))
                
                if self._kgm_qp_data_instance._debug_mode == 'Y':
                    print('【KgmQpQgisIo: set_pp_layer】str_layer_pathの値は、'\
                          '{}です。'.format(str_layer_path))
                
                ##### QgsVectorLayerによりレイヤを作成
                kgm_photopoints_layer = QgsVectorLayer(str_layer_path, pp_lyr_dsp_name,
                                       'ogr')
                if not kgm_photopoints_layer.isValid():
                    print( "Layer failed to load!")
                else:
                    QgsProject.instance().addMapLayer(kgm_photopoints_layer)
                    self.kgmpic_layer = kgm_photopoints_layer
                    self._kgm_qp_data_instance.pplyr_name = kgm_photopoints_layer.name()
                
                '''
                if self._kgm_qp_data_instance._debug_mode == 'Y':
                    print('【KgmQpQgisIo: set_pp_layer】既存shpファイルからphotopointレイヤを'\
                          '作成しました：｛｝'.format(pp_lyr_dsp_name))
                
                ##### 結果をKGMデータセット辞書に反映
                count = self.prepare_kgm_datasets()
                '''
                
            else:
                """
                なければ、新規作成・追加
                """
                
                #####【改訂：2024/03/27】引数にexif_timeoffsetを追加。
                kgm_photopoints_layer = self.create_point_shape_layer(\
                                                    kgmqp_folderpath, \
                                                    kgm_tracklog_layer, \
                                                    kgm_trackpoints_layer, \
                                                    exif_timeoffset \
                                                    )
                
                if self._kgm_qp_data_instance._debug_mode == 'Y':
                    print('【KgmQpQgisIo: set_pp_layer】photopointレイヤを新規作成／追加'\
                          'しました：｛｝'.format(kgm_photopoints_layer))
                    
                pp_lyr_dsp_name = kgm_photopoints_layer.name()
            
                '''
                ##### 結果をKGMデータセット辞書に反映
                count = self.prepare_kgm_datasets()
                '''
        
        
        self.set_symbology_of_ppt_layer(kgm_photopoints_layer)
        
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【KgmQpQgisIo: set_pp_layer】photopointレイヤを'\
                  '作成しました：｛｝'.format(pp_lyr_dsp_name))
        
        
        return kgm_photopoints_layer
    
    
    
    def create_point_shape_layer(self, \
                    kgmqp_folderpath: object, \
                    kgm_tracklog_layer: object, \
                    kgm_trackpoints_layer: object, \
                    exif_timeoffset: datetime \
                    ) -> object:
        """
        KGM写真撮影地点のpoint shapeファイルを作成し、フィールドを定義
        --> see: PyQGIS_shapefileレイヤ作成テスト_20210315_直接地物から_
                 take2.txt
        【改訂：2024/03/19】
        処理対象のフォルダへのパスを引数から取得することに統一。
        trackpointsレイヤへの参照をインスタンス変数ではなく引数に変更。
        戻り値をphotopointsレイヤ名ではなくレイヤオブジェクトへの参照に変更。
        【改訂：2024/03/24】
        引数にkgm_tracklog_layerを追加。
        【改訂：2024/03/27】
        引数にexif_timeoffsetも追加。Photopointsレイヤ新規作成時に、
        これによりEXIF日時とUTC日時との時差を補正。
        """
        ##### 2021/11/06: これはフィールド定義までに限定、
        #                 フィーチャー追加は別途
        
        #####【改訂：2024/03/19】インスタンス変数の参照は関数冒頭で明示
        #####【改訂：2024/03/27】インスタンス変数参照を廃止。
        # jpgpics = self._kgm_qp_data_instance.kgmqp_list_jpgpics
        
        
        ##### 2024/03/08: 【暫定】「の撮影地点」をインスタンス変数から取得
        pp_dsp_name_suffix  = self.kgmdd_mgr.pp_displayname_suffix
        
        jpgpics = \
            self._kgm_qp_data_instance.set_kgmqp_list_jpgpics(kgmqp_folderpath)
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【create_point_shape_layer】kgmqp_folderpathの値は、'\
                  '{} です。'.format(kgmqp_folderpath))
            print('【create_point_shape_layer】kgm_trackpoints_layerの値は、'\
                  '{} です。'.format(kgm_trackpoints_layer))
            print('【create_point_shape_layer】exif_timeoffsetの値は、'\
                  '{} です。'.format(exif_timeoffset))
            print('【create_point_shape_layer】jpgpicsの値は、'\
                  '{} です。'.format(jpgpics))
        
        # define fields for feature attributes. A QgsFields object is needed
        fields = QgsFields()
        ##### 属性テーブルに写真ID・写真ファイル名のフィールドを作成
        #     （2021/11/06）
        fields.append(QgsField("pic_id", QVariant.Int))
        fields.append(QgsField("pic_filename", QVariant.String))
        fields.append(QgsField("memo_text", QVariant.String))
        fields.append(QgsField("shoot_time", QVariant.String))
                                           # 暫定的に文字列で

        ##### 2021/11/12: レイヤ名もここで指定
        ##### 2023/03/01: pp_layer_nameをtracksレイヤ名から取得
        ##### 2023/03/02: ↑これは撤回、以前の処理に戻す
        
        
        ##### 2024/03/10: pathlibによる処理に統一
        # layer_name = os.path.basename(
        #     self._kgm_qp_data_instance.kgmqp_folderpath) + pp_dsp_name_suffix
        
        #####【訂正：2024/03/20】kgmqp_folderpathはpathlibオブジェクトのはず。
        # pp_layer_source_name = str(Path(kgmqp_folderpath).stem) + pp_dsp_name_suffix
        pp_layer_source_name = str(kgmqp_folderpath.stem) + pp_dsp_name_suffix
        
        shapefile_name = pp_layer_source_name + '.shp'
        
        
        ##### 2024/03/10: pathlibによる処理に統一
        # layer_path = os.path.join(path, shapefile_name)
        # print("【layer_path】 ", layer_path)
        pp_layer_path = kgmqp_folderpath / Path(shapefile_name)
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【create_point_shape_layer】shapefile_nameの値は、'\
                  '{} です。'.format(shapefile_name))
            print('【create_point_shape_layer】pp_layer_pathの値は、'\
                  '{} です。'.format(pp_layer_path))
        
        
        
        ##### 2021/12/09: QgsVectorFileWriter.createに
        #                （少なくともv.3.10では）バグがあるらしい
        ##### 2021/12/13: バグ回避よりQGISのver.upを選択、12/10に
        #                 v.3.16に切り替えた。

        """ create an instance of vector file writer,
            which will create the vector file.
        Arguments:
        1. path to new file (will fail if exists already)
        2. field map
        3. geometry type - from WKBTYPE enum
        4. layer's spatial reference (instance of
           QgsCoordinateReferenceSystem)
        5. coordinate transform context
        6. save options (driver name for the output file, encoding etc.)
        """
        
        ##### 2024/03/10: temp_layer_pathはどこでも参照されてないようなのでコメントアウト
        # temp_layer_path = os.path.join(path, 'temp.shp')

        crs = QgsProject.instance().crs()
        
        
        ##### 2024/03/23: 現在のプロジェクトのCRSを確認
        print('【create_point_shape_layer】現在のプロジェクトのCRS：{}'.format(crs))
        
        
        transform_context = QgsProject.instance().transformContext()
        save_options = QgsVectorFileWriter.SaveVectorOptions()
        save_options.driverName = "ESRI Shapefile"
        save_options.fileEncoding = "UTF-8"
        
        
        str_pplayer_path = str(pp_layer_path)
        
        writer = QgsVectorFileWriter.create(
          str_pplayer_path,
          fields,
          QgsWkbTypes.Point,
          crs,
          transform_context,
          save_options)
        
        
        ##### 2024/03/10:【暫定】gpx_tpをインスタンス変数から取得
        ##### 【改訂：2024/03/19】インスタンス変数ではなく引数を使用。
        # gpx_tp = self.kgm_trackpoints_layer
        # tp_name = gpx_tp.name()
        tp_name = kgm_trackpoints_layer.name()
        
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【create_point_shape_layer】jpgpicsの要素数は、'\
                  '{} です。'.format(len(jpgpics)))
            print('【create_point_shape_layer】トラックポイントのレイヤ名は、'\
                  '{} です。'.format(tp_name))
            
        fet = QgsFeature()
        
        for ix, dummy in enumerate(jpgpics):
            """
            フォルダ内の全写真ファイルを対象にループを回す
            写真IDを続例フィールドに入れるためenumerate()を使う
            （2021/03/29）
            """

            # 参照する写真の順番をixで明示的に指定
            ##### 2024/03/10: 
            # jpg_file = os.path.join(kgmdir, jpgpics[ix])
            
            jpg_file_path = kgmqp_folderpath / Path(jpgpics[ix])
            
            
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【create_point_shape_layer】処理中の写真へのパスは、'\
                      '{} です。'.format(jpg_file_path))
            
            
            exifstr = \
              self._kgm_qp_data_instance.kgm_exif_inst.get_exif_of_image(
                  jpg_file_path)

            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('写真 {} のEXIFテーブルは、'\
                      '{} です。'.format(jpg_file_path, exifstr))
                
            exif_date_time = \
              self._kgm_qp_data_instance.kgm_exif_inst.get_datetime_of_image(
                  jpg_file_path)
            
            
            ### 2023/11/07: Python標準のdatetime（aware）による処理に切り替え
            # dt_gpx_date_time = self._kgm_qp_data_instance.kgm_exif_inst.conv_exifdt_to_gpxdt_aware(exif_date_time) 
            
            # 2023/11/07:【暫定】get_geometry_by_utcdtの引数dt_gpx_date_timeがQDateTime型だったため、
            #            当面これに変換した上で処理
            dt_gpx_date_time_pydt = \
                self._kgm_qp_data_instance.kgm_exif_inst.conv_exifdt_to_gpxdt_aware( \
                                                                        exif_date_time \
                                                                        )
            
            ### 2024/01/27: QGIS3.16用に一時変更：dt_gpx_date_time_str = dt_gpx_date_time_pydt.strftime("%Y-%m-%dT%H:%M:%S.000Z")
            dt_gpx_date_time_str = dt_gpx_date_time_pydt.strftime("%Y-%m-%dT%H:%M:%S.000")
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('dt_gpx_date_time_strの値は、'\
                      '{} です。'.format(dt_gpx_date_time_str))
            
            ## 2024/01/27: QGIS3.16用に一時変更：dt_gpx_date_time = QDateTime.fromString(dt_gpx_date_time_str, 'yyyy-MM-ddThh:mm:ss.000Z')
            dt_gpx_date_time = QDateTime.fromString(dt_gpx_date_time_str, 'yyyy-MM-ddThh:mm:ss.000')
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('dt_gpx_date_timeの値は、'\
                      '{} です。'.format(dt_gpx_date_time))
            
            
            gpx_gmy = self.get_geometry_by_utcdt(kgm_trackpoints_layer, dt_gpx_date_time)
            
            # fet.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(10,10)))
            fet.setGeometry(gpx_gmy)
            '''
            # fet.setAttributes([ix, os.path.basename(jpg_file),'Hello!',
                                exif_date_time])
            '''
            
            ##### 2022/03/06:
            #    【修正すみ】shpファイル自体を新規作成のときのみ実行
            
            
            fet.setAttributes([ix,
                               jpg_file_path.name,
                               'Hi!',
                               exif_date_time])
            
            
            result = writer.addFeature(fet)
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('addFeatureの結果は {} です。'.format(result))
                print('writer {} にfeature {} を追加しました'\
                      '。'.format(writer, fet))
                
        if writer.hasError() != QgsVectorFileWriter.NoError:
            print('Error when creating shapefile: ',
                  writer.errorMessage())
            
        # delete the writer to flush features to disk
        del writer
        
        
        ##### 2024/03/10: 引数名を変更
        # layer = QgsVectorLayer(layer_path, layer_name, 'ogr')
        kgm_photopoints_layer = QgsVectorLayer(str_pplayer_path, pp_layer_source_name, 'ogr')
        
        
        if not kgm_photopoints_layer.isValid():
            print( "Layer failed to load!")
        else:
            QgsProject.instance().addMapLayer(kgm_photopoints_layer)
            
            
            '''
            ##### 2024/02/20: shpファイルが既存のときエラーになる現象の原因調査
            print("「create_point_shape_kgm_photopoints_layer」で既存PointShapeレイヤを指定？")
            print('kgm_photopoints_layerの値は {} です。'.format(kgm_photopoints_layer))
            print('kgm_photopoints_layer.name()の値は {} です。'.format(kgm_photopoints_layer.name()))
            '''
        
        self.set_symbology_of_ppt_layer(kgm_photopoints_layer)
        
        
        #####【改訂：2024/03/24】ここでもインスタンス変数が紛れ込んでいた！
        # kgm_photopoints_layer.setName(self._kgm_qp_data_instance.tlglyr_name + pp_dsp_name_suffix)
        
        tlglayer_dsp_name = kgm_tracklog_layer.name()
        
        kgm_photopoints_layer.setName(tlglayer_dsp_name + pp_dsp_name_suffix)
        
        kgm_photopoints_layer.triggerRepaint()
        iface.layerTreeView().refreshLayerSymbology(kgm_photopoints_layer.id())
        
        
        return kgm_photopoints_layer
    
    
    
    def set_symbology_of_ppt_layer(self, kgm_photopoints_layer: object) -> None:
        """
        【2024/03/19】
        photopointsレイヤのシンボルを設定。
        当面はハードコードで実施。
        【暫定】デフォルトのシンボルへのパスはインスタンス変数から取得。
        　（当面、このパスは文字列型で定義されているのを継承）
        """
        
        ##### 2021/12/13:
        #     KGM photopointのデフォルトのスタイルを読み込む
        #     -> see Programmer's Guide, p.117
        
        style_file_path = \
          os.path.join(self._kgm_qp_data_instance.kgmqp_root_path,
                       'KGM-Qp_photopoints_white4mm_label16pt.qml')
        kgm_photopoints_layer.loadNamedStyle(style_file_path)
    
    
    
    
    def append_new_kgm_dataset_to_kgmdss_dictionary(self, \
                                    gpx_file_path: object, \
                                    exif_timeoffset \
                                    ) -> None:
        """
        【2024/03/19】
        KGMデータのレイヤを新規作成（既存shpファイル使用も含む）し、
        辞書登録用情報を抽出し、KGMデータセット辞書に追加する。
        【備考】引数はgpxファイルへのフルパス（pathlib形式）
        【備考】既存のKGMデータセット辞書（未作成でも可）は
        　　　　KgmDataDictManagerのインスタンス変数から取得。
        【改訂：2024/03/27】
        時差補正をPhotoPoint作成時に実施するため、exif_timeoffsetを
        引数に追加。
        【方針変更：2024/03/27】
        当初exif_timeoffsetをインスタンス変数から削除しようと考えたが、
        play_sound始め参照頻度があまりにも高いため断念。
        結果、append_new_kgm_dataset_to_kgmdss_dictionaryの引数に含める
        必要もなくなったと思われるが、（おそらく）含めていても実害は
        ないので、当面このまま温存。
        """
        
        ##### 既存のKGMデータセット辞書（未作成でも可）を
        #     KgmDataDictManagerのインスタンス変数から取得。
        dct_kgm_datasets = self.kgmdd_mgr.kgm_datasets
        
        
        ##### trackpointsレイヤ・tracklogレイヤを一括作成
        kgm_tptlg_layers = self.create_tptlg_layers_from_gpx_file_path( \
                                            gpx_file_path \
                                            )
        ##### リストをアンパック
        kgm_trackpoints_layer, kgm_tracklog_layer = kgm_tptlg_layers
        
        ##### photopointsレイヤを作成
        kgmqp_folderpath = gpx_file_path.parent
        
        #####【改訂：2024/03/19】set_pp_layerに引数を追加
        #####【改訂：2024/03/24】kgm_trackpoints_layerも引数に追加。
        #####【改訂：2024/03/27】exif_timeoffsetも引数に追加。
        kgm_photopoints_layer = self.set_pp_layer( \
                                        kgmqp_folderpath, \
                                        kgm_tracklog_layer, \
                                        kgm_trackpoints_layer, \
                                        exif_timeoffset \
                                        )
        

        tlglyr_source = kgm_tracklog_layer.source()
        
        # 【暫定】KGMデータレイヤの識別名をtracklogのソースパスのステム名にする
        #         事実上は当該KGMデータのあるディレクトリ名（パス名ではなく）
        kgmds_idname_commonpart = str(Path(tlglyr_source).stem)
        kgmds_dataset_name =  'kgmdst_' + kgmds_idname_commonpart
        kgmds_displayname_commonpart =  kgm_tracklog_layer.name()
        kgmds_tlg_layer_source = kgm_tracklog_layer.source()
        kgmds_ppt_layer_source = kgm_photopoints_layer.source()
        
        
        kgm_dataset_dict = self.kgmdd_mgr.creatre_kgmdataset_dictionary( \
                                    kgmds_dataset_name, \
                                    kgmds_idname_commonpart, \
                                    kgmds_displayname_commonpart, \
                                    kgm_tracklog_layer, \
                                    kgmds_tlg_layer_source, \
                                    kgm_trackpoints_layer, \
                                    kgm_photopoints_layer, \
                                    kgmds_ppt_layer_source \
                                    )
        
        if dct_kgm_datasets:
            """
            既存のKGMデータセット辞書があれば、追加更新。
            """
            dct_kgm_datasets.update(kgm_dataset_dict)
            
            #####【2024/03/27】ここでアクティブなKGMデータセット辞書を切替え
            updated_tlg_display_name = \
                self.kgmdd_mgr.switch_active_kgm_dataset_by_tlg_dsp_name(kgmds_displayname_commonpart)
            
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【ppend_new_kgm_dataset_to_kgmdss_dictionary】更新されたtlg_display_nameの値は'\
                      '{} です。'.format(updated_tlg_display_name))
                print('【ppend_new_kgm_dataset_to_kgmdss_dictionary】更新されたdct_kgm_datasetsの値は'\
                      '{} です。'.format(dct_kgm_datasets))
            
        else:
            """
            既存のKGMデータセット辞書がなければ、新規作成。
            """
            dct_kgm_datasets = dict()
            dct_kgm_datasets.update(kgm_dataset_dict)
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【ppend_new_kgm_dataset_to_kgmdss_dictionary】新規作成されたdct_kgm_datasetsの値は'\
                      '{} です。'.format(dct_kgm_datasets))
        
        return 
    
    
    
    
    def select_tlg_layer_in_kgmds(self, kgm_dataset_view: object) -> object:
        """
        2024/03/06:
        引数で受け取ったKGMデータセット辞書のビューにより、
        この辞書に登録ずみのtracklogレイヤを選択して返す。
        辞書中になければNoneを返す。
        辞書中になければNoneを返す。
        【改訂：2024/03/08】
        現在アクティブなtrackpointsレイヤは従来self.kgm_tracklog_layer
        に記録されてきた。
        これを全面変更するのは今後の課題とし、当面はKGMデータセット辞書
        経由の処理の際に確実にこのインスタンス変数を更新することで対処。
        """
        tlg_layer_info_key = 'tracklog'
        tlg_lyr_dsp_name_key = 'layer_display_name'
        
        tlg_lyr_dsp_name_value = self.kgmdd_mgr.get_layer_attribute_value_from_kgm_dataset(\
                    kgm_dataset_view, \
                    tlg_layer_info_key, \
                    tlg_lyr_dsp_name_key \
                    )
        
        tlg_layer_in_kgmdss = self.kgmdd_mgr.select_layer_in_qgis_mapcanvas_by_layer_display_name(\
                                    tlg_lyr_dsp_name_value \
                                    )
        
        ##### 2024/03/08:【経過措置】KgmQpDataのself.kgm_tracklog_layerを更新
        #     処理結果を既存のインスタンス変数に確実に反映する。
        self.kgm_tracklog_layer = tlg_layer_in_kgmdss
        
        return tlg_layer_in_kgmdss
    
    
    
    def select_tp_layer_in_kgmds(self, kgm_dataset_view: object) -> object:
        """
        2024/03/06:
        引数で受け取ったKGMデータセット辞書のビューにより、
        この辞書に登録ずみのtrackpointsレイヤを選択して返す。
        辞書中になければNoneを返す。
        【改訂：2024/03/08】
        現在アクティブなtrackpointsレイヤは従来self.kgm_trackpoints_layer
        に記録されてきた。
        これを全面変更するのは今後の課題とし、当面はKGMデータセット辞書
        経由の処理の際に確実にこのインスタンス変数を更新することで対処。
        """
        tp_layer_info_key = 'trackpoints'
        tp_lyr_dsp_name_key = 'layer_display_name'
        
        tp_lyr_dsp_name_value = self.kgmdd_mgr.get_layer_attribute_value_from_kgm_dataset(\
                    kgm_dataset_view, \
                    tp_layer_info_key, \
                    tp_lyr_dsp_name_key \
                    )
        
        tp_layer_in_kgmdss = self.kgmdd_mgr.select_layer_in_qgis_mapcanvas_by_layer_display_name(\
                                    tp_lyr_dsp_name_value \
                                    )
        
        ##### 2024/03/08:【経過措置】KgmQpDataのself.kgm_trackpoints_layerを更新
        #     処理結果を既存のインスタンス変数に確実に反映する。
        self.kgm_trackpoints_layer = tp_layer_in_kgmdss
        
        return tp_layer_in_kgmdss
    
    

    def select_pp_layer_in_kgmds(self, kgm_dataset_view: object) -> object:
        """
        2024/03/06:
        引数で受け取ったKGMデータセット辞書のビューにより、
        この辞書に登録ずみのPhotoPointsレイヤを選択して返す。
        辞書中になければNoneを返す。
        【改訂：2024/03/08】
        現在アクティブなphotopointsレイヤは従来self.kgmpic_layerに記録
        されてきた。
        これを全面変更するのは今後の課題とし、当面はKGMデータセット辞書
        経由の処理の際に確実にこのインスタンス変数を更新することで対処。
        """
        pp_layer_info_key = 'photopoints'
        pp_lyr_dsp_name_key = 'layer_display_name'
        
        pp_lyr_dsp_name_value = self.kgmdd_mgr.get_layer_attribute_value_from_kgm_dataset(\
                    kgm_dataset_view, \
                    pp_layer_info_key, \
                    pp_lyr_dsp_name_key \
                    )
        
        pp_layer_in_kgmdss = self.kgmdd_mgr.select_layer_in_qgis_mapcanvas_by_layer_display_name(\
                                    pp_lyr_dsp_name_value \
                                    )
        
        ##### 2024/03/08:【経過措置】KgmQpDataのself.kgmpic_layerを更新
        #     処理結果を既存のインスタンス変数に確実に反映する。
        self.kgmpic_layer = pp_layer_in_kgmdss
        
        return pp_layer_in_kgmdss
    
    
    
    def select_pp_layer(self, lyr_dsp_name: str) -> object:
        """
        2024/02/25:
        KGMデータセット辞書を介して、
        辞書に登録ずみのPhotoPointsレイヤを選択
        辞書中になければNoneを返す
        【暫定復活：2024/03/06】
        これはKgmQpDataから呼ばれるので、引数にKgmDataDictManagerの辞書
        などが使えない。
        暫定的に、ここでKGMデータセット辞書経由にラップする。
        【改訂：2024/03/08】
        現在アクティブなphotopointsレイヤは従来self.kgmpic_layerに記録
        されてきた。
        これを全面変更するのは今後の課題とし、当面はKGMデータセット辞書
        経由の処理の際に確実にこのインスタンス変数を更新することで対処。
        """
        
        pp_layer_info_key = 'photopoints'
        pp_lyr_dsp_name_key = 'layer_display_name'
        
        kgm_dataset_view = self.kgmdd_mgr.find_kgm_detaset_by_layer_display_name(lyr_dsp_name)
        
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【KgmQpQgisIo: select_pp_layer】'\
                  'lyr_dsp_nameの値は、{}です：'.format(lyr_dsp_name))
            print('【KgmQpQgisIo: select_pp_layer】'\
                  'kgm_dataset_viewの値は、{}です：'.format(kgm_dataset_view))
        
        pp_layer_in_kgmdss = self.select_pp_layer_in_kgmds(kgm_dataset_view)
        
        ##### 2024/03/08:【経過措置】KgmQpDataのself.kgmpic_layerを更新
        #     処理結果を既存のインスタンス変数に確実に反映する。
        self.kgmpic_layer = pp_layer_in_kgmdss
        
        return pp_layer_in_kgmdss
    
    
    
    def get_tlg_dsp_name_of_active_kgm_dataset(self) -> str:
        """
        【2024/03/22】
        現在アクティブなKGMデータセット辞書から、
        GPS tracklogの共通表示名を取得し、その文字列を返す。
        """
        
        active_kgmds_view = self.kgmdd_mgr.get_active_kgm_dataset()
        
        
        tlg_lyr = self.select_tlg_layer_in_kgmds(active_kgmds_view)
        tptlg_layer_common_name = tlg_lyr.name()
        
        return tptlg_layer_common_name
    
    
    def get_geometry_by_utcdt(self, tp, utcdt):
        """
        【2022/08/24】UTC日付時刻の一致するものがない場合に対処
        （例１：KGM-AGX版でGPS起動前に音声時刻合わせした場合）
        （例２：KGM-AGX版でGPS測位間隔が５秒などだった場合）
        （例３：GPS測位開始後に屋内に入りログ途絶の場合？）
        GPX-TrackPointsレイヤのフィーチャをUTC日付時刻で検索して
        ジオメトリを返す
        【2023/08/24】QGIS v.3.22（以前）と v.3.28（以降(?)）に両対応
        するよう再修正。
        ☆（どうやら）v.3.22までのsetFilterExpression()にバグがあったのを
        　v.3.28で訂正したため？
        　v.3.22（以前）は「'yyyy-MM-ddThh:mm:ss.000'」でないとヒットせず
        　v.3.28では「'yyyy-MM-ddThh:mm:ss.000Z'」でないとヒットしない模様。
        """
        list_tpdt = []
        list_tpdt_ascending = []
        ### list_features = []
        nearby_tpdt = ''
        nearby_feature = object
        
        ### 2023/08/24: setFilterExpression()の書式を切換える処理を追加
        xpr = self.select_xpr_format(tp, utcdt)
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【KgmQpQgisIo: get_geometry_by_utcdt】'\
                  '検索条件xprの値は、{}です：'.format(xpr))
            print('【KgmQpQgisIo: get_geometry_by_utcdt】'\
                  'tp.name()の値は、{}です：'.format(tp.name()))
            
        rq = QgsFeatureRequest().setFilterExpression(xpr)
        ### 2023/07/25: list_features = tp.getFeatures(rq)
        """ 検索結果を一旦リストに入れ、該当数を検討 """
        
        ### 2023/07/25: tp.getFeatures(rq)のforループが2回回る？現象への暫定対策
        list_features = []
        time_prev = 0
        for f in tp.getFeatures(rq):
            if f.attribute('time') != time_prev:
                list_features.append(f)
                print('【KgmQpQgisIo: get_geometry_by_utcdt】'\
                  'このfeatureのtimeの値は、{}です：'.format(f.attribute('time')))
            ### list_features.append(f)
            time_prev = f.attribute('time')
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【KgmQpQgisIo: get_geometry_by_utcdt】'\
                  'list_featuresの値は、{}です：'.format(list_features))
            print('【KgmQpQgisIo: get_geometry_by_utcdt】'\
                  'list_featuresのlengthは、{}です：'.format(len(list_features)))
        
        print('【タイミングテスト用】utcdt一致するものの有無別処理へ')
        
        if not list_features:
            """
            一致なし：
            「要素を持たない空リストは偽」
            （柴田 2019: p.53; p.169）
            """
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: get_geometry_by_utcdt】'\
                      '時刻の一致するフィーチャがありません！'\
                      '　近傍のものを探します。')

            """
            【2022/08/24】tpレイヤのフィーチャから、写真の撮影時刻と
            　　　　　　　UTC日付時刻がもっとも近いものを返す
            【2022/08/24】当初は時刻が近いフィーチャを検索と思ったが、
            むしろtpの時刻フィールドのリストを作り、それに検索条件の
            時刻をアペンドしてソートし、検索条件時刻のインデクス番号
            を取り出してその前後を見るのが速いのではと考えついた。

            nearby_feature = self.get_nearby_feature(tp, utcdt)
            """
            
            for f in tp.getFeatures():
                """
                2022/08/24: tpの全フィーチャの「time」フィールドのリスト
                """
                
                f_attribute_time = f.attribute('time')
                
                list_tpdt.append(f_attribute_time)
                
            list_tpdt_ascending = sorted(list_tpdt)   # 昇順にソート
            
            ### 【2023/08/27】ここにもsetFilterExpression()の書式を切換える処理を追加
            nearby_tpdt = self.get_nearby_tpdt(utcdt, list_tpdt_ascending)
            xpr_nearby = self.select_xpr_format(tp, nearby_tpdt)
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: get_geometry_by_utcdt】'\
                      'xpr_nearbyの値は、{}です：'.format(xpr_nearby))
            
            rq = QgsFeatureRequest().setFilterExpression(xpr_nearby)
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: get_geometry_by_utcdt】'\
                      'rqの値は、{}です：'.format(rq))
            
            for f in tp.getFeatures(rq):
                
                print('【KgmQpQgisIo: get_geometry_by_utcdt】'\
                      'f.geometry()の値は、{}です：'.format(f.geometry()))
                
                gmy = f.geometry()
        
        elif len(list_features) == 1:
            """ １つのみ一致 """
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: get_geometry_by_utcdt】'\
                      '時刻の一致するフィーチャは、'\
                      '{}個だけです。'.format(len(list_features)))
            gmy = list_features[0].geometry()
        elif len(list_features) > 1:
            """ ２つ以上一致 """
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: get_geometry_by_utcdt】'\
                      '要注意：同時刻のフィーチャが、{}個あります！：'\
                      '{} です。'.format(len(list_features), list_features))
            gmy = list_features[0].geometry()   ### とりあえず最初のを返す
        else:
            """ それ以外（ないと思うが） """
            print('【KgmQpQgisIo: get_geometry_by_utcdt】'\
                  '要注意：検索されたフィーチャ数が異常です！：'\
                  '{} です。'.format(len(list_features), list_features))
            gmy = list_features[0].geometry()   ### とりあえず最初のを返す
        
        return(gmy)
    
    
    
    def zoom_to_tlg_layer_of_active_kgm_dataset(self):
        """
        【2024/03/22】
        現在アクティブなKGMデータセットのtracklogレイヤの領域にズーム。
        【改訂：2024/03/23】
        まずmapCanvasのインスタンスを作ってからsetExtent
        """
        
        active_kgmds_view = self.kgmdd_mgr.get_active_kgm_dataset()
        tlg_layer = self.select_tlg_layer_in_kgmds(active_kgmds_view)
        tlg_layer_extent = tlg_layer.extent()
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【KgmQpQgisIo: zoom_to_tlg_layer_of_active_kgm_dataset】'\
                  'tlg_layerの値は、{}です：'.format(tlg_layer))
            print('【KgmQpQgisIo: zoom_to_tlg_layer_of_active_kgm_dataset】'\
                  'tlg_layer_extentの値は、{}です：'.format(tlg_layer_extent))
        
        
        for feature in tlg_layer.getFeatures():
            ext = feature.geometry().boundingBox() # this line is the relevant part
        
            print('ext = feature.geometry().boundingBox()直後：{}'.format(ext))
        
        
        
        iface.mapCanvas().setExtent(tlg_layer.extent())
        
        
        #####【これはNG】【2024/03/24】extにCRSを設定してみる。
        ### my_crs = QgsCoordinateReferenceSystem("EPSG:4326")
        ### ext_with_crs = ext.setCRS(my_crs)
        
        ##### 2024/03/23: 
        ### iface.mapCanvas().setExtent(tlg_layer_extent)
        ### iface.mapCanvas().setExtent(ext)
        ### iface.mapCanvas().setExtent(ext_with_crs)
        
        canvas_extent = iface.mapCanvas().extent()
        print('iface.mapCanvas().setExtent(tlg_layer_extent)直後：{}'.format(canvas_extent))
        
        iface.mapCanvas().refresh()
        
        return ext




    def zoom_to_selected_point_via_kgm_qgis_io(self, picid: str) -> None:
        """
        2021/11/15: 表示中のphotopointの地点にズーム
        【改訂：2024/03/07】
        KgmQpQgisIo内の関数として実装することに変更
        """
        
        active_kgmds = self.kgmdd_mgr.get_active_kgm_dataset()
        layer = self.select_pp_layer_in_kgmds(active_kgmds)
        
        
        if layer is None:
            """ 辞書中にない（＝pplayerを新規作成・追加した直後） """
            
            layer = self.kgmpic_layer  # 【暫定：2024/02/25】インスタンス変数を参照
            
        
        
        layer.selectByExpression('"pic_id" = ' + str(picid))

        box = layer.boundingBoxOfSelected()
        
        
        print('box = layer.boundingBoxOfSelected()直後：{}'.format(box))
        
        
        iface.mapCanvas().setExtent(box)
        # 【2022/02/15: 一時的にコメントアウト】iface.mapCanvas().refresh()
        
        return
    
    
    
    
    def select_xpr_format(self, tp: object, utcdt: datetime) -> str:
        """
        【2023/08/24】QGIS v.3.22（以前）と v.3.28（以降(?)）に両対応可能
        にするためのxpr書式切り替え関数を作成。【暫定版】
        一旦v.3.28形式で検索し、ノーヒットならv.3.22（以前）形式に設定。
        ☆（どうやら）v.3.22までのsetFilterExpression()にバグがあったのを
        　v.3.28で訂正したため？
        　v.3.22（以前）は「'yyyy-MM-ddThh:mm:ss.000'」でないとヒットせず
        　v.3.28では「'yyyy-MM-ddThh:mm:ss.000Z'」でないとヒットしない模様。

        【2023/08/26】tp.getFeatures(rq)でノーヒットになるの自体を検出して
        v.3.22（以前）とv.3.28とを判別するよう変更
        """


        
        #####【2023/08/26】getFeaturesループ回し方式による判定
        # v328書式でのヒットの有無を判定
        str_utcdt_v328 = utcdt.toString('yyyy-MM-ddThh:mm:ss.000Z')
        xpr_v328 = '"time" = ' + "'" + str_utcdt_v328 + "'"
        rq_v328 = QgsFeatureRequest().setFilterExpression(xpr_v328)
        
        fcount_v328 = 0
        for _ in tp.getFeatures(rq_v328):
            """
            「_」はその変数をループ内で使わないことを示す。
            （ → see 柴田（2019）p.103）
            Pythonのforやwhileは前判定のため実質素通りがありうる。
            （ → see 柴田（2019）p.91）
            ∴tp.getFeatures()がノーヒットならfcount_v328は0のまま。
            """
            fcount_v328 += 1
        
        str_utcdt_v322 = utcdt.toString('yyyy-MM-ddThh:mm:ss.000')
        xpr_v322 = '"time" = ' + "'" + str_utcdt_v322 + "'"
        rq_v322 = QgsFeatureRequest().setFilterExpression(xpr_v322)
        
        # v322書式でのヒットの有無を判定
        fcount_v322 = 0
        for _ in tp.getFeatures(rq_v322):
            """
            「_」はその変数をループ内で使わないことを示す。
            （ → see 柴田（2019）p.103）
            Pythonのforやwhileは前判定のため実質素通りがありうる。
            （ → see 柴田（2019）p.91）
            ∴tp.getFeatures()がノーヒットならfcount_v322は0のまま。
            """
            fcount_v322 += 1
        
        if fcount_v328 > 0:
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: select_xpr_format（v.3.28）】'\
                    'xpr_v328の値は、{}です：'.format(xpr_v328))
            return xpr_v328
        elif fcount_v322 > 0:
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: select_xpr_format（v.3.22）】'\
                      'xpr_v322の値は、{}です：'.format(xpr_v322))
            return xpr_v322
        else:
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: select_xpr_format（NOhit！）】'\
                      'v.3.28でもv3.22でもヒットしませんでした！')
            return ""           # 【暫定】どちらもヒットなしなら""


    def get_nearby_tpdt(self, qdt_utcdt: object, list_tpdt_a: list) -> object:
        """
        【2022/08/24】tpレイヤのフィーチャから、写真の撮影時刻と
        　　　　　　　UTC日付時刻がもっとも近いものを返す
        【2022/08/24】当初は時刻が近いフィーチャを検索と思ったが、
        むしろtpの時刻フィールドのリストを作り、それに検索条件の
        時刻をアペンドしてソートし、検索条件時刻のインデクス番号
        を取り出してその前後を見るのが速いのではと考えついた。
        """
        
        list_work = []
        list_work_ascending = []
        ix_qdt_utcdt = 0
        
        list_work = list_tpdt_a
        list_work.append(qdt_utcdt)
        list_work_ascending = sorted(list_work)
        
        if list_work_ascending[0] == qdt_utcdt:
            """ 検索条件のutcdtが先頭 → 次のを返す """
            nearby_tpdt = list_work_ascending[1]
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: get_nearby_tpdt＝先頭】'\
                      'nearby_tpdtの値は、{}です：'.format(nearby_tpdt))
            
        elif list_work_ascending[len(list_work_ascending)-1] == qdt_utcdt:
            """ 検索条件のutcdtが末尾 → その前のを返す """
            nearby_tpdt = list_work_ascending[len(list_work_ascending)-2]
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: get_nearby_tpdt＝末尾】'\
                      'nearby_tpdtの値は、{}です：'.format(nearby_tpdt))
        else:
            """
            先頭でも末尾でもない
            → 直前・直後と比較し、近いほうを返す
            """
            ix_qdt_utcdt = list_work_ascending.index(qdt_utcdt)
            prev_tpdt = list_work_ascending[ix_qdt_utcdt-1]
            next_tpdt = list_work_ascending[ix_qdt_utcdt+1]
            
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: get_nearby_tpdt＝近いほう】'\
                      'ix_qdt_utcdtの値は、{}です：'.format(ix_qdt_utcdt))
                
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: get_nearby_tpdt＝近いほう】'\
                      'prev_tpdtの値は、{}です：'.format(prev_tpdt))
                
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: get_nearby_tpdt＝近いほう】'\
                      'next_tpdtの値は、{}です：'.format(next_tpdt))
                
            ##### 2022/08/24: QDateTimeどうしの間隔はこれで計算するらしい
            qdt_org_prev = prev_tpdt.secsTo(qdt_utcdt)
            qdt_next_org = qdt_utcdt.secsTo(next_tpdt)

            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: get_nearby_tpdt＝近いほう】'\
                      'qdt_org_prevの値は、{}です：'.format(qdt_org_prev))
                print('【KgmQpQgisIo: get_nearby_tpdt＝近いほう】'\
                      'qdt_next_orgの値は、{}です：'.format(qdt_next_org))
            
            if qdt_org_prev <= qdt_next_org:
                """ 直前に近いか、同間隔 """
                nearby_tpdt = prev_tpdt
            else:
                """ 直後に近い """
                nearby_tpdt = next_tpdt
                
            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【KgmQpQgisIo: get_nearby_tpdt＝近いほう】'\
                      '{}です：'.format(nearby_tpdt))
            
        return (nearby_tpdt)

    def get_fields(self, layer_id_name: str) -> list:
        """
        指定された名前のレイヤの属性テーブルのフィールドのリストを返す
        """

        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【KgmQpQgisIo】photopointのレイヤ名は、'\
                  '{} です。'.format(layer_id_name))

        layers = QgsProject.instance().mapLayersByName(layer_id_name)
        lyr = layers[0]
        field_list = lyr.fields()
        return field_list

    def create_xtime_ppix_list(self) -> list:
        """
        【2023/03/05】
        【変更前】kgmpic_layerからEXIF時刻・写真番号リストを作成
        【変更後】写真のEXIF時刻のみの１次元配列に変更
        """
        
        
        ##### 2024/02/20: shpファイルが既存のときエラーになる現象の原因調査
        print("「【KgmQpQgisIo】create_xtime_ppix_list」に入った")
        
        print('【KgmQpQgisIo】self.kgmpic_layerの値は、'\
                  '{} です。'.format(self.kgmpic_layer))
        
        
        
        
        xtime_ppix_list = []

        ##### 2023/03/05: 【暫定】
        ##### 【これをリライト】2021/12/26: photopointsの書き出し
        pp_features = self.kgmpic_layer.getFeatures()

        for ix, f in enumerate(pp_features):

            # attrlist = self.sp_feature_attributes(ix)

            attrlist = f.attributes()

            # ixは[0]、EXIF時刻は[3]
            # 【要注意】２次元配列は厄介なので１次元に変更
            # xtime_ppix = [attrlist[0], attrlist[3]]
            xtime_ppix = attrlist[3]
            xtime_ppix_list.append(xtime_ppix)


        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【create_xtime_ppix_list】EXIF時刻・写真番号リストは、'\
                  '{} です。'.format(xtime_ppix_list))

        return xtime_ppix_list



    def sp_feature_attributes(self, ix: int) -> list:
        """
        KGM撮影地点[ix]の属性のリスト
        """

        ##### 2021/11/07: 下記を参考に試し書き
        # https://docs.qgis.org/3.16/en/docs/pyqgis_developer_cookbook/
        #         vector.html#selecting-features
        ##### 2121/11/12: それをもとにリライト
        select_expression = '"pic_id" = ' + str(ix)
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('選択条件の文字列は、'\
                  '{} です。'.format(select_expression))

        
        ##### 2024/03/08: 別の所にこんなのがあったので試してみる。
        ##### 2021/12/05: 変更を確定・保存するためにこれが必要？
        ##### 2024/03/08: そもそもself.kgmpic_layerがobjectのままだと言われた。
        # self.kgmpic_layer.commitChanges()
        
        
        self.kgmpic_layer.selectByExpression(
            select_expression,
            QgsVectorLayer.SetSelection)
        
        # これはエラーになったので後回し：
        # iface.mapCanvas().setSelectionColor( QColor("yellow") )

        selection = self.kgmpic_layer.selectedFeatures()

        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('選択されたフィーチャは、'\
                  '{} です。'.format(selection))
            print('選択されたフィーチャの属性１は、'\
                  '{} です。'.format(selection[0]))

        ipf_current_attrlist = selection[0].attributes()

        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('返される属性リストは、'\
                  '{} です。'.format(ipf_current_attrlist))

        return ipf_current_attrlist


    def set_photopoint_memotext(self, ix: int, txt: str) -> None:
        """
        photopointの写真番号ixの属性テーブルの'memo_text'フィールドに、
        txtの内容を記入する。
        """
        ##### 2021/11/27：
        # 【重要】属性テーブルの内容を変更する際には、
        # selectしたフィーチャに変更を加えても、もとの属性テーブルに
        # 反映されない！
        # 変更対象のレイヤのデータプロバイダのchangeAttributeValues
        # メソッドを使う必要がある（らしい）。
        # その手順は以下のとおり：
        # １．変更対象のフィールドとその値を、辞書型で用意する。
        #   attrs = { 【フィールドのインデクス番号】: 【記入する値】 }
        # ２．変更対象の地物のフィーチャIDと、上記の（辞書型）変数とを
        #  （組み合わせた辞書型の）引数にして、changeAttributeValues
        #   に渡す。
        #   pplayer.dataProvider().changeAttributeValues(
        #                                  { crnt_ppl_fid : attrs })
        # 【出典】『GIS実習オープン教材』
        # 「ベクターデータの属性情報に基づく処理」の
        # 「地物の属性情報の編集」
        #  https://gis-oer.github.io/gitbook/book/materials/python/
        #          03/03.html
        #

        ##### 2021/11/27：
        #     変更対象のレイヤを確実に指定するため、KgmQpDataの
        #     インスタンス変数へのアクセッサでレイヤ名を取得
        pplname = self._kgm_qp_data_instance.pplyr_name
        layers = QgsProject.instance().mapLayersByName(pplname)
        pplayer = layers[0]

        ##### 2021/11/27：
        #    【要検討】変更対象の地物のフィーチャIDはselectで
        #     取っているが、これでよいか？
        #     （2021/11/27現在、とくに支障なく処理できている模様）
        select_expression = '"pic_id" = ' + str(ix)
        pplayer.selectByExpression(select_expression,
                                   QgsVectorLayer.SetSelection)
        selection = pplayer.selectedFeatures()
        crnt_ppl_fid = selection[0].id()


        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('pplnamedの値は、{} です。'.format(pplname))
            print('pplayerのソースは{}です。'.format(pplayer.source()))
            print('crnt_ppl_fidの値は、{} です。'.format(crnt_ppl_fid))


        attrs = { selection[0].fieldNameIndex('memo_text') : txt}
        pplayer.dataProvider().changeAttributeValues(
            { crnt_ppl_fid : attrs })


        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('QgsVectorDataProvider.ChangeAttributeValuesの値は'\
                  '{}です。'.format(
                      QgsVectorDataProvider.ChangeAttributeValues))
            # print('capsの値は{}です。'.format(caps))
            print('attrsの内容は、{} です。'.format(attrs))

        ##### 2021/12/05: 変更を確定・保存するためにこれが必要？
        self.kgmpic_layer.commitChanges()




    def loadXYZ(self, url, name):
        """
        XYZレイヤを読み込む（2021/12/13）
        出典：https://docs.qgis.org/3.10/ja/docs/pyqgis_developer_cookbook/
                      cheat_sheet.html#layers
        【改訂：2024/03/23】
        【これはNG→】addMapLayerでなくinsertLayerにより最下層に挿入
        【解決：2024/03/23】下記資料p.20を参照。
        https://docs.qgis.org/3.28/pdf/ja/QGIS-3.28-PyQGISDeveloperCookbook-ja.pdf
        """
        rasterLyr = QgsRasterLayer("type=xyz&url=" + url, name, "wms")
        
        ##### QgsProject.instance().addMapLayer(rasterLyr)
        #####【2024/03/23】↓これはエラーになる。
        # QgsProject.instance().insertLayer(-1, rasterLyr)
        
        
        #####【2024/03/23】出典：QGIS-3.28-PyQGISDeveloperCookbook-ja.pdf, p.20
        # first add the layer without showing it
        ### QgsProject.instance().addMapLayer(rasterLyr, False)
        
        
        # obtain the layer tree of the top-level group in the project
        layerTree = iface.layerTreeCanvasBridge().rootGroup()
        
        # the position is a number starting from 0, with-1 an alias for the end
        layerTree.insertChildNode(-1, QgsLayerTreeLayer(rasterLyr))
        
    
    def load_xyz_osm(self) -> None:
        """
        【2024/03/22】
        OpenStreetMapのXYZタイルを背景地図として読み込む。
        参考：https://docs.qgis.org/3.10/ja/docs/pyqgis_developer_cookbook/
                cheat_sheet.html#layers
        【要検討】すでにMapCanvasの既存レイヤにOSMがあれば追加しない？
        """
        
        ### urlWithParams = 'type=xyz&url=https://a.tile.openstreetmap.org/%7Bz%7D/%7Bx%7D/%7By%7D.png&zmax=19&zmin=0&crs=EPSG3857'
        ### self.loadXYZ(urlWithParams, 'OpenStreetMap')
        
        
        osm_layer_dsp_name = 'OpenStreetMap'
        osm_layer = self.find_layer_in_dict_layers_by_layer_display_name( \
                                            osm_layer_dsp_name \
                                            )
        if not osm_layer:
            """
            既存のOSMレイヤがない
            """
            
            tms = 'type=xyz&url=https://tile.openstreetmap.org/{z}/{x}/{y}.png&zmax=19&zmin=0'
            osm_layer = QgsRasterLayer(tms,'OpenStreetMap', 'wms')
            
            '''
            QMessageBox.information(
                None,
                "通知",
                "osm_layerの値は" + format(osm_layer),
                QMessageBox.Yes)
            '''
            
            '''
            【2024/03/24】このへんの四苦八苦はすべて無駄だった模様（泣）
            iface.mapCanvas().extent()の後（あたり）で少し間を空けないと、
            再描画されないうちに次へ進む(?)か何かで、extent変更が実際の
            画面に反映されない現象が出るらしい。詳細は不明だが・・・
            
            osm_layer_crs_original = osm_layer.crs()
            print('【load_xyz_osm】osm_layerのオリジナルCRSは：{}'.format(osm_layer_crs_original))
            
            crs_destination = QgsCoordinateReferenceSystem("EPSG:4326")
            print('【load_xyz_osm】変換先のCRSは：{}'.format(crs_destination))
            
            transformContext = QgsProject.instance().transformContext()
            xform = QgsCoordinateTransform(osm_layer_crs_original, crs_destination, transformContext)
            
            osm_layer_transformed = xform.transform(osm_layer)
            
            #####【2024/03/24】osm_layerのCRSをWGS84に設定。
            # osm_layer.setCrs(QgsCoordinateReferenceSystem("EPSG:4326"))
            
            print('【load_xyz_osm】osm_layer_transformedのCRSは：{}'.format(osm_layer_transformed.crs()))
            
            
            #####【2024/03/23】出典：QGIS-3.28-PyQGISDeveloperCookbook-ja.pdf, p.20
            # first add the layer without showing it
            ### QgsProject.instance().addMapLayer(osm_layer, False)
            ### QgsProject.instance().addMapLayer(osm_layer)
            ### QgsProject.instance().addMapLayer(osm_layer, False)
            #####【2024/03/24】
            QgsProject.instance().addMapLayer(osm_layer_transformed, False)
            '''
            
            QgsProject.instance().addMapLayer(osm_layer, False)
            
            
            project_crs = QgsProject.instance().crs()
            print('project_crs = QgsProject.instance().crs()直後：{}'.format(project_crs))
            
            
            ext = self.zoom_to_tlg_layer_of_active_kgm_dataset()
            print('ext = self.zoom_to_tlg_layer_of_active_kgm_dataset()直後：{}'.format(ext))
            
            
            ### iface.mapCanvas().setExtent(ext)
            ### iface.mapCanvas().refresh()
            
            canvas = iface.mapCanvas()
            
            '''
            canvas_crs = canvas.crs()
            print('canvas_crs = canvas.crs()直後：{}'.format(canvas_crs))
            '''
            
            ### canvas.setExtent(ext, False)
            canvas.setExtent(ext)
            canvas.refresh()
            ### canvas.refreshAllLayers()
            
            
            canvas_extent = iface.mapCanvas().extent()
            print('QgsProject.instance().addMapLayer(osm_layer, False)直後：{}'.format(canvas_extent))
            
            
            '''
            QMessageBox.information(
                None,
                "通知",
                "canvas_extentの値は" + format(canvas_extent),
                QMessageBox.Yes)
            '''
            
            #####【2024/03/24】メッセージボックスを出して時間稼ぎする
            #     ∵ 少し間を置かないとmapCanvasのズーム・再描画がスベる？
            #       これのおかげでまた半日ロスした（泣）
            QMessageBox.information(
                None,
                "通知",
                "背景地図にOpenStreetMapを使います。",
                QMessageBox.Yes)
            
            
            # obtain the layer tree of the top-level group in the project
            layerTree = iface.layerTreeCanvasBridge().rootGroup()
            
            
            canvas_extent = iface.mapCanvas().extent()
            print('layerTree = iface.layerTreeCanvasBridge().rootGroup()直後：{}'.format(canvas_extent))
            
            
            # the position is a number starting from 0, with-1 an alias for the end
            layerTree.insertChildNode(-1, QgsLayerTreeLayer(osm_layer))
            
            canvas_extent = iface.mapCanvas().extent()
            print('layerTree.insertChildNode(-1, QgsLayerTreeLayer(osm_layer))直後：{}'.format(canvas_extent))
            
        else:
            """
            既存のOSMレイヤあり
            """
            pass
        
        return
    
    
    
    
    def pplayer_selectionChangedSlot(self):
        """
        【2022/02/15】
        photopointレイヤのフィーチャがマウスクリックで選択された
        イベントの処理
        """
        
        selection = self.kgmpic_layer.selectedFeatures()
        
        ##### 2022/10/05: 近傍tp検索時のエラー対策（暫定）
        if selection:
            pp_fidlist = []
            # for ix, f in enumerate(selection):
            for f in selection:
                pp_fidlist.append(f.id())

            if self._kgm_qp_data_instance._debug_mode == 'Y':
                print('【pplayer_selectionChangedSlot】selectionChangedが'\
                      '{}で検知されました。'.format(pp_fidlist))
                print('【pplayer_selectionChangedSlot】選択されたphotopoint'\
                      'の数は{}です。'.format(len(selection)))

            if len(pp_fidlist) == 0:
                # photopoint以外の地点がクリックされた場合：
                #  → 直前の選択を回復
                ix = self._kgm_qp_data_instance.current_photo_index
                select_expression = '"pic_id" = ' + str(ix)
                self.kgmpic_layer.selectByExpression(
                    select_expression,
                    QgsVectorLayer.SetSelection)
            elif len(pp_fidlist) == 1:
                # photopointの１地点のみが選択された場合：
                signaled_photo_attributes = selection[0].attributes()
                signaled_photo_index = signaled_photo_attributes[0]
                    # 属性[0]が写真ID番号
                if signaled_photo_index == \
                    self._kgm_qp_data_instance.current_photo_index:
                    # もと選択されていた写真番号と同一：何もしない
                    pass
                else:
                    # もと選択されていた写真番号と異なる：そこへ移動
                    if self._kgm_qp_data_instance._debug_mode == 'Y':
                        print('【pplayer_selectionChangedSlot】新規に'\
                              '写真番号{}が選択されました'\
                              '。'.format(signaled_photo_index))

                    # kqm_qp_coreのcurrent_photo_indexを更新後に
                    # メイン窓の写真ID番号欄更新メソッドを呼ぶ
                    self._kgm_qp_data_instance.current_photo_index = \
                        signaled_photo_index
                    self._kgm_qp_data_instance.photopoint_to_be_shown_update()
        else:
            pass


    def pplayer_nameChangedSlot(self):
        """
        【2022/03/06】
        photopointレイヤのレイヤ名が変更された
        イベントの処理
        """
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【pplayer_nameChangedSlot】レイヤ名の変更が'\
                  '{}で検知されました。'.format(self.kgmpic_layer))

        self._kgm_qp_data_instance.pplyr_name = self.kgmpic_layer.name()

        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【pplayer_nameChangedSlot】新しいレイヤ名は'\
                  '{}です。'.format(self._kgm_qp_data_instance.pplyr_name))
    
    
    def tplayer_nameChangedSlot(self):
        """
        【2024/02/26】
        self.kgm_tracklog_layerとself.kgm_trackpoints_layerとを
        明示的に切り分けたことに伴う変更
        trackpointsレイヤのレイヤ名が変更されたイベントの処理
        """
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【tplayer_nameChangedSlot】レイヤ名の変更が'\
                  '{}で検知されました。'.format(self.kgm_trackpoints_layer))
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【tplayer_nameChangedSlot】新しいレイヤ名は'\
                  '{}です。'.format(self._kgm_qp_data_instance.tlglyr_name))
    
    
    def tlglayer_nameChangedSlot(self):
        """
        【2024/02/26】
        self.kgm_tracklog_layerとself.kgm_trackpoints_layerとを
        明示的に切り分けたことに伴う変更
        racklogレイヤのレイヤ名が変更されたイベントの処理
        """
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【tlglayer_nameChangedSlot】レイヤ名の変更が'\
                  '{}で検知されました。'.format(self.__kgm_tracklog_layer))
        
        ##### 2023/03/01: KgmQpDataのtlglyr_nameにtracksレイヤの名称を使用
        self._kgm_qp_data_instance.tlglyr_name = self.kgm_tracklog_layer.name()
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【tlglayer_nameChangedSlot】新しいレイヤ名は'\
                  '{}です。'.format(self._kgm_qp_data_instance.tlglyr_name))
    
    
    
    def set_active_kgmqp_data_path(self) -> object:
        """
        2024/03/07:
        現在操作対象となるKGMデータフォルダの切替えのために、
        トラックログレイヤのソースの親ディレクトリのパスを
        pathlibのオブジェクトとして返す。
        """
        
        active_kgmds = self.kgmdd_mgr.get_active_kgm_dataset()
        
        
        if active_kgmds:
            """
            念のため、active_kgmdsが見つかった場合
            """
            
            layer_info_key = 'tracklog'
            layer_attribute_key = 'layer_source'
            
            tlg_lyr_src_path = self.kgmdd_mgr.get_layer_attribute_value_from_kgm_dataset( \
                                active_kgmds, \
                                layer_info_key, \
                                layer_attribute_key \
                                )
            if tlg_lyr_src_path:
                """
                トラックログが既存ならその親ディレクトリを
                KGMの現在アクティブなディレクトリに設定
                """
                active_kgm_data_path = Path(tlg_lyr_src_path).parent
                
            else:
                active_kgm_data_path = None
        else:
            active_kgm_data_path = None
            
        
        if self._kgm_qp_data_instance._debug_mode == 'Y':
            print('【set_active_kgmqp_data_path】active_kgm_data_pathの値は'\
              '{} です。'.format(active_kgm_data_path))
        
        return active_kgm_data_path
    
    
    def save_map_as_image(self, map_export_path: str) -> None:
        """
        【2022/02/26】
        現在表示中の地図をPNG画像ファイルに書き出す
        """
        canvas = iface.mapCanvas()
        canvas.saveAsImage(map_export_path)



class KgmDataDictManager:
    """
    2024/02/22:
    QGISに登録されたKGMデータのレイヤを管理するクラス
    KgmOpdSRの３種類のレイヤ（tracklog, trackpoints, photopoints）を
    まとめて１つのKGMデータセットとして扱い、
    複数のKGMデータセットを登録可能な辞書として管理する。
    QGIS上のKGMデータのレイヤにKgmQpsSRからアクセスする処理は、
    すべてこのクラス（のインスタンス）を介して行う。
    【改訂：2024/03/05】
    KgmQpsSRの３種類のレイヤとQGISのMapCanvas上の対応するレイヤとを
    一意に紐づけるための名称「layer_id_name」を新設、
    （↑QGIS3.28現在、レイヤ名のエイリアスが正式サポートされてない
    　　らしいための暫定的措置）
    （↑使用文字をASCII英数字に限定：多言語対応化への布石）
    MapCanvasに表示されるレイヤ名を「layer_display_name」として区別
    あわせて、現在アクティブなKGMデータセットを示すフラグを新設
    逆にlayer_sourceは削除、QGISのMapCanvas上のレイヤ情報を都度参照
    以前の「picpoints」を「photopoints」に改称
    【再改訂：2024/03/05】
    残念ながら「layer_id_name」は放棄。
    QGIS本体側に受け皿（レイヤ名エイリアス機能）がなければ、結局、
    都度「layer_display_name」を検索して処理するため逆効果と判断。
    それに代えて、
    (1)「layer_display_name」の値からKGMデータセット辞書を選択
    　（.items()によりdict_items型のビューとして扱う）
    (2)その辞書名「kgmds_name」をKGMデータセットのID名として使用
    (3)KgmQpDataには「アクティブなKGMデータセット辞書」だけ見せる
    　（↑KgmQpQgisIo経由で）
    (4)QGIS（MapCanvas）とのやりとりもKGMデータセット単位で行う
    　（３つのレイヤの特定には「layer_display_name」を使用）
    の方針を試す。
    【再々改訂：2024/03/18】
    KGMデータセット辞書に各レイヤ自体へのオブジェクト参照も含める。
    KgmQpDataやKgmQpDocSRDockWidgetに対しては、辞書内の、現在
    アクティブな単一のデータセットだけを見せる。
    （例外：操作窓のデータ切り替え用コンボボックス）
    かつ、見せるのは（dict_items型など）のビューの形で実施。
    【備考】'layer_id_name'は、将来QGISがレイヤ名エイリアスをサポート
    した場合に備え、一応残す。
    """
    
    def __init__(self, coredata: object, mapio: object):
        """
        コンストラクタ：
        self._kgm_qp_coredata：KgmQpDataのインスタンス
        self._kgm_qp_mapio: KgmQpQgisIoのインスタンス
        """
        self._kgm_qp_coredata = coredata
        self._kgm_qp_mapio = mapio
        
        
        ##### 2024/02/21: KGMデータ構造を示す辞書を作成
        #     これをKgmQpQgisIoクラスのインスタンス変数として管理
        #     それへの参照はすべてアクセッサにより実施
        ##### 2024/03/05: 【改訂】KgmDataDictManagerクラスの
        #     インスタンス変数に変更ずみだった。
        self.__kgm_datasets = dict()
        
        
        
        ##### 2024/03/05: 【暫定】trackpoint・photopointのレイヤ表示名
        #     に付加する文字列をインスタンス変数に記録
        self.tp_displayname_suffix = 'のtrack points'
        self.pp_displayname_suffix = 'の撮影地点'
    
    
    
    @property
    def kgm_datasets(self) -> dict:
        """
        QGISレイヤとして登録されたKGMデータセットの辞書を返すgetter
        データセットが複数の場合はkgm_dataset_idで区別
        """
        return self.__kgm_datasets
    
    @kgm_datasets.setter
    def kgm_datasets(self, updated_kgmdss: dict) -> None:
        """
        KGMデータセットをQGISレイヤとして登録・更新するsetter
        データセットが複数の場合は辞書に登録したデータセット名で区別
        データセット全体を更新版に置き換える形で実施
        """
        self.__kgm_datasets = updated_kgmdss
    
    
    
    def amiok(self):
        """
        KgmDataDictManagerのインスタンスが正常に作成されたかを確認
        """
        print('【KgmDataDictManager_amiok】KgmQpDataのインスタンスへの参照は、'\
          '{} です。'.format(self._kgm_qp_coredata))
        print('【KKgmDataDictManager_amiok】KgmQpQgisIoのインスタンスへの参照は、'\
          '{} です。'.format(self._kgm_qp_mapio))
        
        dummy_tlg_layer_obj = object
        dummy_tpt_layer_obj = object
        dummy_ppt_layer_obj = object
        
        ##### 2024/03/05: self.__kgm_datasetsの作成確認
        self.kgm_datasets = self.creatre_kgmdataset_dictionary(\
                                'kgm_dataset_dummy', \
                                'dummy_kgm_dirname', \
                                'dummy_kgm_routetitle', \
                                dummy_tlg_layer_obj, \
                                'dummy_tracklog_source', \
                                dummy_tpt_layer_obj, \
                                dummy_ppt_layer_obj, \
                                'dummy_photopoints_source' \
                                )
        
        print('【KgmDataDictManager_amiok】self.kgm_datasetsのテスト用ダミー値は、'\
          '{} です。'.format(self.kgm_datasets))
        
        ##### 2024/02/21: self.__kgm_datasetsの作成が確認できたら即削除
        self.kgm_datasets.clear()
        print('【KgmDataDictManager_amiok】クリア後のself.kgm_datasetsの値は、'\
          '{} です。'.format(self.kgm_datasets))
        
        
        self.test_layer_dict()
        
        return
    
    
    def test_layer_dict(self):
        """
        2024/02/22:
        self._kgm_qp_mapio.get_existing_layers_as_dict()の動作確認用
        """
        
        dct_current_layers = self._kgm_qp_mapio.get_existing_layers_as_dict()
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmDataDictManager_test_layer_dict】dct_current_layersの値は'\
                  '{} です。'.format(dct_current_layers))
        
        return
    
    
    
    
    def creatre_kgmdataset_dictionary(self, \
            kgmds_name: str, \
            kgmds_idname_commonpart: str, \
            kgmds_displayname_commonpart: str, \
            kgmds_tlg_layer_obj: object, \
            kgmds_tlg_layer_source: str, \
            kgmds_tpt_layer_obj: object, \
            kgmds_ppt_layer_obj: object, \
            kgmds_ppt_layer_source: str \
            ) -> dict:
        """
        2024/03/05:
        KGM Dataset（単一）辞書を作成
        'layer_id_name'と'layer_display_name'とを峻別
        【暫定】現在アクティブかのフラグ（'flagactive'）は、
        この関数内では引数による設定はせず、
        必ず「１」（active）を返す。
        【備考】当初はレイヤソースへの参照は削除するつもりだったが、
        QGISでレイヤ名のエイリアスが正式サポートされてないらしいため、
        レイヤ表示名での参照を極力避けるため、レイヤソース情報も
        こっちで保持することに変更した。
        【改訂：2024/03/18】
        KGMデータセット辞書に各レイヤ自体へのオブジェクト参照も含める。
        KgmQpDataやKgmQpDocSRDockWidgetに対しては、辞書内の、現在
        アクティブな単一のデータセットだけを見せる。
        （例外：操作窓のデータ切り替え用コンボボックス）
        かつ、見せるのは（dict_items型など）のビューの形で実施。
        【備考】tlgレイヤとtptレイヤとは同一ソースであると前提。
        【備考】'layer_id_name'は、将来QGISがレイヤ名エイリアスをサポート
        した場合に備え、一応残す。
        """
        
        
        ##### 2024/03/05: インスタンス変数の参照を関数冒頭で明示
        tpt_dpn_suffix = self.tp_displayname_suffix
        ppt_dpn_suffix = self.pp_displayname_suffix
        
        
        created_kgm_dataset = {
            kgmds_name: {\
                'flagactive': 1, \
                'tracklog': {\
                    'layer_id_name': kgmds_idname_commonpart + '_tlg' + '_idn', \
                    'layer_display_name': kgmds_displayname_commonpart, \
                    'layer_obj': kgmds_tlg_layer_obj, \
                    'layer_source': kgmds_tlg_layer_source, \
                    }, \
                'trackpoints': {\
                    'layer_id_name': kgmds_idname_commonpart  + '_tpt' + '_idn', \
                    'layer_display_name': kgmds_displayname_commonpart + tpt_dpn_suffix, \
                    'layer_obj': kgmds_tpt_layer_obj, \
                    'layer_source': kgmds_tlg_layer_source, \
                    }, \
                'photopoints': {\
                    'layer_id_name': kgmds_idname_commonpart + '_ppt' + '_idn', \
                    'layer_display_name': kgmds_displayname_commonpart + ppt_dpn_suffix, \
                    'layer_obj': kgmds_ppt_layer_obj, \
                    'layer_source': kgmds_ppt_layer_source, \
                    } \
                } \
            }
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmDataDictManager_creatre_kgmdataset_dictionary】created_kgm_datasetの値は'\
                  '{} です。'.format(created_kgm_dataset))
        
        return created_kgm_dataset
    
    
    
    def get_layer_attribute_value_from_kgm_dataset(self, \
                    kgm_dataset_dict_items: object, \
                    layer_info_key: str, \
                    layer_attribute_key: str \
                    ) -> str:
        """
        2024/03/06:
        引数で指定された１つのKGMデータセット辞書のビュー
        （↑dict_items型：辞書名と値のタプル）から、
        引数で指定されたレイヤ情報キー（例：'tracklog'）と
        レイヤ属性キー（例：'layer_display_name'）とにより、
        該当するレイヤ属性値を得て返す。
        キーで指定された情報が見つからなければNoneを返す。
        """
        
        kgmds_name, kgmds_value = kgm_dataset_dict_items   # ビューをアンパック
        
        kgmds_lyr_info = kgmds_value.get(layer_info_key)
        kgmds_lyr_attr_value = kgmds_lyr_info.get(layer_attribute_key)
        if kgmds_lyr_attr_value:
            hit_lyr_attr_value = kgmds_lyr_attr_value
        else:
            hit_lyr_attr_value = None
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmDataDictManager_get_layer_attribute_value_from_kgm_dataset】hit_lyr_attr_valueの値は'\
                  '{} です。'.format(hit_lyr_attr_value))
        
        return hit_lyr_attr_value
    
    
    
    def get_active_kgm_dataset(self) -> object:
        """
        2024/03/06:
        【2024/03/05付け同名関数を改訂】
        改訂版KGSDSSの'flagactive'により現在アクティブなデータセットを
        特定し、そのKGMデータセット辞書の内容を、
        （データセット名・データセット内容）のタプルとして、
        dict_items型のビューで返す。
        （→ see 柴田（2019）p.224-225）
        【改訂：2024/03/28】
        「self.kgm_datasetsに値がなければ新規作成した上で」の形に変更。
        """
        
        ##### 2024/03/05: インスタンス変数の参照を関数冒頭で明示
        dct_kgmdss = self.kgm_datasets
        
        if not dct_kgmdss:
            """
            2024/03/28:
            まだself.kgm_datasetsに値がない場合は、新規作成。
            """
            count = self.initialize_kgm_datasets()
            
        else:
            """
            2024/03/28:
            すでにself.kgm_datasetsに値がある場合は、そのまま次へ。
            """
            pass
        
        ##### 2024/03/05: あらためて更新後のインスタンス変数を参照
        dct_kgmdss = self.kgm_datasets
        
        lyr_info_key = 'flagactive'
        int_active = 1
        
        for kgmdss_item in dct_kgmdss.items():
            kgmds_name, kgmds_value = kgmdss_item   # ビューをアンパック
            kgmds_flag_active = kgmds_value.get(lyr_info_key)
            if (kgmds_flag_active == int_active):
                active_kgmdss_item = kgmdss_item    # dict_items型ビューを返す
                break
            else:
                active_kgmdss_item = None
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmDataDictManager_get_active_kgm_dataset】active_kgmdss_itemの値は'\
                  '{} です。'.format(active_kgmdss_item))
        
        return active_kgmdss_item
    
    
    
    def switch_active_kgm_dataset_by_tlg_dsp_name(self, \
                                    tlg_dsp_name: str \
                                    ) -> str:
        """
        【2024/03/22】
        （メイン窓のコンボボックスから取得した）tlg表示名により、
        KGMデータセット辞書中のこれに対応するデータセットを取得し、
        このデータセットを現在アクティブなKGMデータセットに指定し、
        他のデータセットを非アクティブに設定し、
        アクティブ化されたKGMデータセットのtlg表示名を返す。
        """
        
        ##### インスタンス変数の参照を関数冒頭で明示
        dct_kgmdss = self.kgm_datasets
        
        
        lyr_info_key_tlg = 'tracklog'
        tlg_lyr_dsp_name_key = 'layer_display_name'
        
        
        ### lyr_info_key_actvflg = 'flagactive'
        int_active = 1
        int_inactive = 0
        
        for  kgmdss_item in dct_kgmdss.items():
            kgmds_name, kgmds_value = kgmdss_item   # ビューをアンパック
            kgmds_lyr_info = kgmds_value.get(lyr_info_key_tlg)
            kgmds_lyr_dsp_name = kgmds_lyr_info.get(tlg_lyr_dsp_name_key)
            if (kgmds_lyr_dsp_name == tlg_dsp_name):
                """
                tlg表示名が引数と一致
                """
                
                #####【2024/03/27】「タプルはupdateできない」エラーになる。
                # kgmdss_item.update(flagactive = int_active)
                kgmds_value.update(flagactive = int_active)
                tlg_dsp_name_of_activated_kgmds = kgmds_lyr_dsp_name
                
                
                ##### 2024/03/27: 【経過措置】ここで暫定的にKgmQpQgisIoの
                #     self.kgmpic_layerにphotopointレイヤへの参照をセット。
                
                
                #####【2024/03/27】ここでphotopointsレイヤも更新
                #     【備考】この関数内でインスタンス変数もセットされる。
                pp_layer_in_kgmdss = self._kgm_qp_mapio.select_pp_layer_in_kgmds(kgmdss_item)
                
                if self._kgm_qp_coredata._debug_mode == 'Y':
                    print('【KgmDataDictManager: switch_active_kgm_dataset_by_tlg_dsp_name】更新されたpp_layer_in_kgmdssの値は'\
                          '{} です。'.format(pp_layer_in_kgmdss))
                
            else:
                
                #####【2024/03/27】「タプルはupdateできない」エラーになる。
                # kgmdss_item.update(flagactive = int_inactive)
                kgmds_value.update(flagactive = int_inactive)
        
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmDataDictManager: switch_active_kgm_dataset_by_tlg_dsp_name】更新されたkgmdss_itemの値は'\
                 '{} です。'.format(kgmdss_item))
            print('【KgmDataDictManager: switch_active_kgm_dataset_by_tlg_dsp_name】現在アクティブな' \
                  'KGMデータセットのtlg表示名は'\
                  '{} です。'.format(tlg_dsp_name_of_activated_kgmds))
        
        return tlg_dsp_name_of_activated_kgmds
    
    
    def find_kgm_detaset_by_layer_display_name(self, lyr_dsp_name: str) -> object:
        """
        2024/03/06:
        QGISのtracklogレイヤ表示名（＝KGMの【経路】プルダウンメニュー表示名）
        の文字列により、そのtracklogを含むKGMデータセット辞書を特定し、
        そのKGMデータセット辞書の内容を、
        （データセット名・データセット内容）のタプルとして、
        dict_items型のビューで返す。
        （→ see 柴田（2019）p.224-225）
        【備考】2024/03/05付け「get_a_kgm_dataset_by_kgm_display_name」をリライト
        """
        
        ##### 2024/03/05: インスタンス変数の参照を関数冒頭で明示
        dct_kgmdss = self.kgm_datasets
        
        lyr_info_key = 'tracklog'
        tlg_lyr_dsp_name_key = 'layer_display_name'
        
        for  kgmdss_item in dct_kgmdss.items():
            kgmds_name, kgmds_value = kgmdss_item   # ビューをアンパック
            kgmds_lyr_info = kgmds_value.get(lyr_info_key)
            kgmds_lyr_dsp_name = kgmds_lyr_info.get(tlg_lyr_dsp_name_key)
            if (kgmds_lyr_dsp_name == lyr_dsp_name):
                found_kgmds = kgmdss_item
                break
            else:
                found_kgmds = None
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmDataDictManager_find_kgm_detaset_by_layer_display_name】lyr_dsp_nameの値は'\
                  '{} です。'.format(lyr_dsp_name))
            print('【KgmDataDictManager_find_kgm_detaset_by_layer_display_name】found_kgmdsの値は'\
                  '{} です。'.format(found_kgmds))
        
        return found_kgmds
    
    
    
    def initialize_kgm_datasets(self) -> int:
        """
        QGISのMaplayersに既登録のKGMデータセットを検出し、
        インスタンス変数にセットする
        【2024/02/23】戻り値をデータセット数（int型）に
        """
        
        dct_maplayers = self._kgm_qp_mapio.get_existing_layers_as_dict()
        self.kgm_datasets = self.create_kgm_dataset_via_maplayers_dictionary(dct_maplayers)
        
        
        #####【改訂：2024/03/29】素でKGMを立ち上げた場合に対処。
        if self.kgm_datasets:
            count_of_datasets = len(self.kgm_datasets)
        else:
            count_of_datasets = 0
        
        return count_of_datasets
    
    
    
    def get_list_kgmdirs_in_maplayers(self, dct_maplayers: dict) -> list:
        """
        2024/03/05:（これを独立の関数化）
        dct_maplayersの値（各レイヤの名称・ソースパス・サフィックス）を調べ、
        サフィックスがtracksであるものを抽出して、
        そのソースパスの親フォルダ（各KGMデータセットを格納したフォルダ）の
        リストを作る。
        """
        
        list_kgm_dirs = []
        for lyr_info in dct_maplayers.values():
            """
            dct_maplayersの値（各レイヤの名称・ソースパス・サフィックス）を調べ、
            サフィックスがtracksであるものを抽出して、
            そのソースパスの親フォルダ（各KGMデータセットを格納したフォルダ）の
            リストを作る。
            """
            if self._kgm_qp_coredata._debug_mode == 'Y':
                print('【KgmDataDictManager_get_list_kgmdirs_in_maplayers】lyr_infoの値は'\
                      '{} です。'.format(lyr_info))
            
            ls_suffix = lyr_info.get('layer_source_suffix')
            ls_path = lyr_info.get('layer_source_path')
            
            if self._kgm_qp_coredata._debug_mode == 'Y':
                print('【KgmDataDictManager_get_list_kgmdirs_in_maplayers】ls_suffixの値は'\
                      '{} です。'.format(ls_suffix))
            
            if ls_suffix.find('tracks') > 0:
                ls_dir = Path(ls_path).parent
                
                if self._kgm_qp_coredata._debug_mode == 'Y':
                    print('【KgmDataDictManager_get_list_kgmdirs_in_maplayers】ls_dirの値は'\
                          '{} です。'.format(ls_dir))
                
                list_kgm_dirs.append(ls_dir)
            
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmDataDictManager_get_list_kgmdirs_in_maplayers】list_kgm_dirsの値は'\
                  '{} です。'.format(list_kgm_dirs))
        
        return list_kgm_dirs
    
    
    
    def create_kgm_dataset_via_maplayers_dictionary(self, dct_maplayers: dict) -> dict:
        """
        2024/02/22:
        get_existing_layers_as_dict()で作成したレイヤ辞書にもとづき、
        そのなかからKGMデータセット（複数可）を構成するレイヤを抽出し、
        それぞれのKGMデータセットに対応する３種のレイヤをまとめて、
        KGMデータセットの辞書を作成する。
        【改訂：2024/03/05】
        改訂版KGMDSS準拠に変更
        【再改訂：2024/03/18】
        KGMデータセット辞書に各レイヤ自体へのオブジェクト参照も含める。
        """
        
        ##### 2024/03/05: インスタンス変数の参照を関数冒頭で明示
        ppt_dpn_suffix = self.pp_displayname_suffix
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmDataDictManager: create_kgm_dataset_via_maplayers_dictionary】ppt_dpn_suffixの値は'\
                  '{} です。'.format(ppt_dpn_suffix))
        
        
        dct_kgm_datasets = dict()
        
        
        list_kgm_dirs = self.get_list_kgmdirs_in_maplayers(dct_maplayers) 
        
        
        #####【改訂：2024/03/29】素でKGMを立ち上げたときの処理を追記。
        if not list_kgm_dirs:
            dct_kgm_datasets = None
            return dct_kgm_datasets
        
        
        for kgm_dir in list_kgm_dirs:
            """
            KGMデータセットを格納したフォルダ（複数可）のリストをもとに、
            dct_maplayersを再度走査し、
            それぞれフォルダごとにKGMデータセットを構成する３種のレイヤをまとめ、
            KGMデータセットの辞書を作成する。
            """
            for lyr_info in dct_maplayers.values():
                ls_dir = Path(lyr_info.get('layer_source_path')).parent
                
                ##### 2024/03/05: 改訂版KGMDSS準拠に変更
                if (ls_dir == kgm_dir):
                    lyr_disp_name = lyr_info.get('layer_display_name')
                    
                    print('【create_kgm_dataset_via_maplayers_dictionary】lyr_disp_nameの値は、'\
                          '{}です。'.format(lyr_disp_name))
                    
                    if lyr_info.get('layer_source_suffix').find('tracks') > 0:
                        """
                        2024/03/05:
                        suffixが'tracks'のときにKGMデータセット作成を一括実施
                        するつもりだったが・・・
                        その後、レイヤソースの情報もKGMDSS側で持たせることに変更
                        したため、photopointsのレイヤソース情報のみ、
                        別途そのレイヤから取ることに変更。
                        """
                        tlglyr_source = lyr_info.get('layer_source_path')
                        
                        # 【暫定】KGMデータレイヤの識別名をtracklogのソースパスのステム名にする
                        #         事実上は当該KGMデータのあるディレクトリ名（パス名ではなく）
                        kgmdst_idname_commonpart = str(Path(tlglyr_source).stem)
                        kgmdst_dataset_name =  'kgmdst_' + kgmdst_idname_commonpart
                        ### kgmdst_displayname_commonpart = lyr_info.get('layer_display_name')
                        kgmdst_displayname_commonpart = lyr_disp_name
                        kgmds_tlg_layer_source = lyr_info.get('layer_source_path')
                        
                        ##### 2024/03/18: KGMデータセット辞書に各レイヤ自体へのオブジェクト
                        #     参照も含めることにしたことに伴う追加処理。
                        kgmds_tlg_layer_obj = lyr_info.get('layer_obj')
                        
                    elif lyr_info.get('layer_source_suffix').find('track_points') > 0:
                        """
                        2024/03/18: KGMデータセット辞書に各レイヤ自体へのオブジェクト
                        参照も含めることにしたことに伴う追加処理。
                        """
                        
                        kgmds_tpt_layer_obj = lyr_info.get('layer_obj')
                        
                    elif lyr_disp_name.find(ppt_dpn_suffix) > 0:
                        """
                        2024/03/05:
                        【暫定】レイヤ名での判定は避けたかったが、photopointsだけは
                        他にいい手を思いつかないため、残念ながらインスタンス変数参照で
                        逃げる。
                        ただ逆に見れば、毎回これで参照するよりは、最初に限定して、
                        以後はKGMDSSの直接参照にするのが、結局は良策なのかも。
                        QGIS3.28でレイヤのエイリアス機能が（たぶん）ないことによる
                        苦渋の暫定措置と言えよう・・・
                        """
                        
                        kgmds_ppt_layer_source = lyr_info.get('layer_source_path')
                        
                        ##### 2024/03/18: KGMデータセット辞書に各レイヤ自体へのオブジェクト
                        #     参照も含めることにしたことに伴う追加処理。
                        kgmds_ppt_layer_obj = lyr_info.get('layer_obj')
                        
                        
                        ##### 2024/03/08: 【経過措置】ここで暫定的にKgmQpQgisIoの
                        #     self.kgmpic_layerにphotopointレイヤへの参照をセット。
                        self._kgm_qp_mapio.kgmpic_layer = lyr_info.get('layer_obj')
                        
                        if self._kgm_qp_coredata._debug_mode == 'Y':
                            print('【KgmDataDictManager_create_kgm_dataset_via_maplayers_dictionary】'\
                                  'self._kgm_qp_mapio.kgmpic_layerにphotopointレイヤへの参照をセットしました：'\
                                  '{}'.format(self._kgm_qp_mapio.kgmpic_layer))
                        
                    else:
                        pass
                    
                    
            if self._kgm_qp_coredata._debug_mode == 'Y':
                print('【KgmDataDictManager_create_kgm_dataset_via_maplayers_dictionary】kgmdst_dataset_nameの値は'\
                      '{} です。'.format(kgmdst_dataset_name))
                print('【KgmDataDictManager_create_kgm_dataset_via_maplayers_dictionary】kgmdst_idname_commonpartの値は'\
                      '{} です。'.format(kgmdst_idname_commonpart))
                print('【KgmDataDictManager_create_kgm_dataset_via_maplayers_dictionary】kgmdst_displayname_commonpartの値は'\
                      '{} です。'.format(kgmdst_displayname_commonpart))
                print('【KgmDataDictManager_create_kgm_dataset_via_maplayers_dictionary】kgmds_tlg_layer_objの値は'\
                      '{} です。'.format(kgmds_tlg_layer_obj))
                print('【KgmDataDictManager_create_kgm_dataset_via_maplayers_dictionary】kgmds_tlg_layer_sourceの値は'\
                      '{} です。'.format(kgmds_tlg_layer_source))
                print('【KgmDataDictManager_create_kgm_dataset_via_maplayers_dictionary】kgmds_tpt_layer_objの値は'\
                      '{} です。'.format(kgmds_tpt_layer_obj))
                print('【KgmDataDictManager_create_kgm_dataset_via_maplayers_dictionary】kgmds_ppt_layer_objの値は'\
                      '{} です。'.format(kgmds_ppt_layer_obj))
                print('【KgmDataDictManager_create_kgm_dataset_via_maplayers_dictionary】kgmds_ppt_layer_sourceの値は'\
                      '{} です。'.format(kgmds_ppt_layer_source))
            
            dct_single_kgmds = self.creatre_kgmdataset_dictionary(\
                                kgmdst_dataset_name, \
                                kgmdst_idname_commonpart, \
                                kgmdst_displayname_commonpart, \
                                kgmds_tlg_layer_obj, \
                                kgmds_tlg_layer_source, \
                                kgmds_tpt_layer_obj, \
                                kgmds_ppt_layer_obj, \
                                kgmds_ppt_layer_source \
                                )
            
            
            dct_kgm_datasets.update(dct_single_kgmds)
            
        
        #####【改訂：2024/03/28】ここでアクティブなKGMデータセット辞書を切替え。
        #    【備考】最後に追加されたKGMデータセットがアクティブになる。
        #####【再改定：2024/03/29】切替えに先立ちインスタンス変数をセットする要あり。
        self.kgm_datasets = dct_kgm_datasets
        updated_tlg_display_name = \
            self.switch_active_kgm_dataset_by_tlg_dsp_name(kgmdst_displayname_commonpart)
        
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmDataDictManager_create_kgm_dataset_via_maplayers_dictionary】dct_kgm_datasetsの値は'\
                  '{} です。'.format(dct_kgm_datasets))
        
        return dct_kgm_datasets
    
    
    
    def get_default_kgmqp_data_path(self) -> str:
        """
        2024/03/06:
        self.kgm_datasetsを参照し、
        そのうち最初のデータセットの
        tracksレイヤのソースの親ディレクトリへのパスを
        デフォルトのデータパスとして返す
        【改訂：2024/03/06】
        get_layer_attribute_value_from_kgm_datasetによる処理に変更
        【改訂：2024/03/08】
        KgmQpDataのprepare_datasetsで新規・追加作成時とそれ以外
        （QGZに既保存のKGMレイヤがある場合など）を峻別したので、
        ここでは何も見つからなければ単純にNoneを返すことに変更。
        """
        
        ##### 2024/03/05: インスタンス変数の参照を関数冒頭で明示
        dct_kgmdss = self.kgm_datasets
        
        layer_info_key = 'tracklog'
        layer_attribute_key = 'layer_source'
        
        if dct_kgmdss:
            """
            作成ずみのKGMデータセット（複数可）があれば、
            そのうち最初のもののビューを作り、その中を調べる
            """
            
            kgm_dataset_dict_items = list(dct_kgmdss.items())[0]
            
            tlg_lyr_src_path = self.get_layer_attribute_value_from_kgm_dataset( \
                                kgm_dataset_dict_items, \
                                layer_info_key, \
                                layer_attribute_key \
                                )
            if tlg_lyr_src_path:
                """
                トラックログが既存ならその親ディレクトリを
                KGMのデフォルトディレクトリにする
                """
                dflt_kgm_data_path = Path(tlg_lyr_src_path).parent
            else:
                """
                KGMデータセットが既存なのにトラックログがない？
                """
                print('KgmDataDictManager_get_default_kgmqp_data_path】KGMデータセットを要点検！\n' + \
                      '{}'.format(kgm_dataset_dict_items))
        else:
            """ 2024/02/25: 既存のKGMレイヤなし"""
            
            ##### 2024/02/26:【暫定】既存のKGMがレイヤないのは新規作成のとき
            #     ∴「読み込み」時に選択したフォルダとして、
            #        KgmQpDataのインスタンス変数に記録されているはず。
            # dflt_kgm_data_path = ''
            # dflt_kgm_data_path = self._kgm_qp_coredata.kgmqp_folderpath
            ##### 2024/03/08:【方針変更】何も見つからなければ単純にNoneを返す。
            dflt_kgm_data_path = None
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmDataDictManager_get_default_kgmqp_data_path】dflt_kgm_data_pathの値は'\
                  '{} です。'.format(dflt_kgm_data_path))
        
        return dflt_kgm_data_path
    
    
    
    def select_layer_in_qgis_mapcanvas_by_layer_display_name(self, \
                                    layer_display_name: str \
                                    ) -> object:
        """
        2024/03/06:
        QGISのMapCanvasに表示されたレイヤから、
        レイヤ表示名がlayer_display_nameであるものを検索し、
        見つかればそのレイヤへの参照を返す。
        見つからなければNoneを返す。
        """
        layers = QgsProject.instance().mapLayersByName(layer_display_name)
        if not layers:
            """ 該当レイヤが辞書中にあるのにQGIS中にない """
            hit_layer = None
            print('【KgmDataDictManager_select_layer_in_qgis_mapcanvas_by_layer_display_name】このレイヤが見つかりません！：'\
                  '{}'.format(layer_display_name))
        elif (len(layers) == 1):
            """ 該当レイヤが１つあり """
            hit_layer = layers[0]
        else:
            """ 該当レイヤが複数あり（これはないはずだが） """
            print('【KgmDataDictManager_find_layer_in_kgmdss_by_layer_id_name】QGIS上に該当レイヤが複数あります：'\
                  '{}個！'.format(len(layers)))
            hit_layer = layers[0]    # 【暫定：2024/03/06】Noneだと新規作成に行くので暫定的に最初のを返す
        
        return hit_layer
    
    
    
    def get_layernames_list_in_kgmdss(self) -> list:
        """
        2024/02/26:
        現在のインスタンス変数に登録されたKGMデータセットを参照し、
        その中に含まれる'tracklog'レイヤのレイヤ名一覧のリストを返す。
        （１つもなければ空リストを返す。）
        【改訂：2024/03/06】
        以前の「lyr_info」を「lyr_info_key」に改名
        以前の「tlg_lyr_dsp_name」を「tlg_lyr_dsp_name_key」に改名
        """
        
        ##### 2024/03/05: インスタンス変数の参照を関数冒頭で明示
        dct_kgmdss = self.kgm_datasets
        
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmDataDictManager_get_layernames_list_in_kgmdss】dct_kgmdssの値は'\
                  '{} です。'.format(dct_kgmdss))
        
        
        lyr_info_key = 'tracklog'
        tlg_lyr_dsp_name_key = 'layer_display_name'
        
        tlglyr_dsp_names = []
        for kgmds_name, kgmds_value in dct_kgmdss.items():
            kgmds_lyr_info = kgmds_value.get(lyr_info_key)
            kgmds_lyr_dsp_name = kgmds_lyr_info.get(tlg_lyr_dsp_name_key)
            
            tlglyr_dsp_names.append(kgmds_lyr_dsp_name)
            
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmDataDictManager_get_layernames_list_in_kgmdss】tlglyr_dsp_namesの値は'\
                  '{} です。'.format(tlglyr_dsp_names))
        
        return tlglyr_dsp_names
