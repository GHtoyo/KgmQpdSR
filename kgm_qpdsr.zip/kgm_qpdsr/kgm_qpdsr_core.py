# -*- coding: utf-8 -*-
"""
#############################################################################
KgmQpData

QGISプラグイン版『聞き書きマップ』のデータアクセス処理

【基本方針】（改訂：2021/12/01）
モジュール「kgm-qp」に、QtやQGISエンジンに依存しない部分を集約:

その中心となるクラス「KgmData」に、QtやQGISエンジンから参照されるプロパティや
メソッドを置く。

上記のプロパティは、KgmDataのインスタンス変数として定義し、QtやQGISエンジン
などからは、各プロパティへのアクセッサ経由でのみ扱えるようにする。

2021/11/08-09の方法でGUI窓同士を相互参照するためのポインタ(?)も、KgmQpDataの
インスタンス変数として定義する。

メイン窓の「読み込み」でKGMデータのフォルダが指定されたとき、そのデータフォル
ダに対応するKgmQpDataのインスタンスを作る。

KGMが扱う３つのデータ（＝GPSログ、写真画像・メモ欄テキスト、音声）それぞれに
対する処理も、GUIやGISに直接関わる部分を除き、モジュール「kgm-qp」の中で、３つ
のデータそれぞれに対応するクラスとして定義する。

（Qtによる）GUIやQGISによる地図画面は、KgmQpData（のインスタンス）の内容を表示
する、言わば「ビュー」のようなものとして扱う。
として扱う。

【例外】（2021/11/13）
音声の処理に使うQtMultimediaは（例外的に）ここに含める。
∵ KgmQpDialogのメイン窓・拡大窓で共用する必要がある。

【追記】（2021/12/13）
v.3.10のQgsVectorFileWriter.createにバグがあるため、v.3.16（以降）専用とする。

#############################################################################
"""

import os

##### 2024/02/26: 【重要】今後os.pathからpathlibへ全面移行
from pathlib import Path, PurePath

##### 2022/06/23: 冒頭でWindowsかMacintoshかを判定、各OS用の処理を実施
#                 その処理自体をここでやるのはNGらしいので、
#                 ここではそれに必要なモジュールのimportだけを行い、
#                 実際の処理はKgmQpDataの__init__中で実施
import sys
import platform
from os.path import expanduser

#####【2024/05/22】こんな見たことのないやつが紛れ込んでエラーになった模様・・・
# from coverage import data

#####【2024/03/27】またパンダ出現したので駆除。
# from pandas.tests.arrays.test_datetimelike import timedelta_index


##### from OpenGL.EGL.KHR import stream


platform_system_result = platform.system()
print(platform_system_result)

path_to_user_home = expanduser("~")
print(path_to_user_home)

if 'Darwin' in platform_system_result:

    print('【KgmQpData】このコンピュータで稼働中のシステムは、' \
              '{} です。'.format(platform_system_result))
    
    ##### 【2023/08/26】2023/07/03 Mac版でPython 3.9対応にしていた。
    #      それがその後上書きされていたので、改めて復活。
    ##### 2023/07/03: QGIS3.28でPython3.9が標準になったことに伴い
    #     これまでのPython3.8のsite-packagesへのパスは順位を下げる
    path_to_old_sitepackages = os.path.join(
        path_to_user_home,
        'library',
        'Python',
        '3.8',
        'lib',
        'python',
        'site-packages')
    
    print (path_to_old_sitepackages)
    sys.path.insert(0, path_to_old_sitepackages)
    
    ##### 2023/07/03: QGIS3.28でPython3.9が標準になったことに伴う変更
    #     これを最優先のパスに設定する（PILのエラー防止のため）
    path_to_sitepackages = os.path.join(
        'Applications',
        'QGIS-LTR 2.app',
        'Contents',
        'MacOS',
        'lib',
        'Python3.9',
        'site-packages',
        'pillow-7.2.0-py3.9-macosx-10.13.0-x86_64.egg'
        )

    print (path_to_sitepackages)
    sys.path.insert(0, path_to_sitepackages)


    '''
    ##### 2022/06/30: zshによるインストールは結局ギブアップ
    #     pipを使ったモジュールのインストールは手動でやることとし、
    #     その手順書を作った：
    #     「【Win・Mac】simplekmlをpipでインストールする手順_asof_20220630.pdf」
    ##### 2022/06/30: ここでsimplekmlインポートをtryし、
    #     エラーになったらzshでインストールする
    try:
        import simplekml
    except:
        commandline_list = []
        pass
    '''

elif 'Windows' in platform_system_result:

    print('【KgmQpData】このコンピュータで稼働中のシステムは、' \
              '{} です。'.format(platform_system_result))

    path_to_sitepackages = ''
    print (path_to_sitepackages)

else:
    print('【KgmQpData：要注意】システムが特定できません！')


##### globライブラリをインポート
import glob    # ディレクトリ内の画像ファイル一覧の取得に使用
import re      # 2021/12/03: globと組み合わせてJPGの大文字小文字問題に対処

##### 2021/12/16: 改行入り文字列リテラル使用のために必要
# https://qiita.com/tag1216/items/3447def88ed6b1d51d60
import textwrap

##### ifaceを使うために必要
#     --> see: PyGIS Developer Cookbook, 1.1
#     (2021/03/19)
from qgis.core import *
import qgis.utils
from qgis.utils import iface

#####【2024/05/22】こんな見たことのないやつが紛れ込んでエラーになった模様・・・
# from decorator import __init__

##### Pillow(PIL)ライブラリ読み込み(2021/03/07)
# Anacondaに同梱のPillowは「Python2のPILをフォークしたものらしい」とのこと
# --> see https://kapibara-sos.net/archives/658
from PIL import Image
from PIL.ExifTags import TAGS

##### 2022/03/11: 写真画像に文字を重ねるため追加
# https://www.codegrepper.com/code-examples/python/add+text+to+image+python
from PIL import ImageFont, ImageDraw

##### 2022/03/19: メッセージボックスを使うために追加
# https://webbibouroku.com/Blog/Article/qgis3-python-messagebox
from PyQt5.QtWidgets import QMessageBox

##### (2021/03/19)
#      2021/11/13: 音声再生用にQtCoreを追加
from qgis.PyQt import QtCore


#####【2024/10/04】QDateTime全面廃止準備
# from qgis.PyQt.QtCore import QDateTime


from numpy import ix_


##### 音声再生用にPyQt5.QtMultimediaを使う（2021/03/21）
#     2021/11/13: ここに移動＆
from PyQt5 import QtMultimedia
from PyQt5.QtMultimedia import QMediaPlayer
from networkx.classes.function import selfloop_edges

##### kgm_qpd_qgisioモジュールからKgmQpQgisIoクラスをインポート
#     2021/11/11：インポート対象をこれだけに限定
# from .kgm_qpd_qgisio import KgmQpQgisIo
##### 2023/02/21: kgm_qpdsr_qgisioに変更
# from .kgm_qpdsr_qgisio import KgmQpQgisIo
##### 2024/02/22: KgmDataDictIoを追加
##### 2024/02/26: KgmDataDictManagerに改名
from .kgm_qpdsr_qgisio import KgmQpQgisIo, KgmDataDictManager


from builtins import property
##### 2022/06/02: いつの間にか↓これが入っていてエラーになるので削除
# from OpenGL.raw.WGL._types import PLAYERPLANEDESCRIPTOR


##### 【2023/08/26】2023/07/03 Mac版でPython 3.9対応にしていた。
#      それがその後上書きされていたので、改めて復活。
##### 2023/02/24: SRT形式データの表示用
#####【暫定：2024/05/03】SRT関係処理を一時的に停止
#####【暫定：2024/05/20】センター支援費報告書作成用にSRTを再開
#####【暫定：2024/05/22】QGIS v.3.34起動テストのため、SRT関係処理を一時的に停止
#####【2024/05/22】QGIS v.3.34のOSGeo4W Shellでsrtをインストールしたので再開。
import srt



##### 2023/03/05: KgmQpData内でもPython標準のdatatimeを使用可にする
#     （いずれはQDateTimeでなくこっちに統一？）
##### 2023/02/26: Subtitleオブジェクトのtimedeltaの処理に必要？
#     see "Python & Qt5" p.312-314
import datetime
# 2023/11/07: from datetime import datetime, timedelta
from datetime import timedelta

##### 2023/03/17: ProjectKikiGaki.pjのXMLを処理するため
#     xml.etree.ElementTreeを使用
#     ( -> see https://docs.python.org/ja/3/library/xml.etree.elementtree.html)
import xml.etree.ElementTree as ET


##### 2024/08/16: KGMindex.txtのパースのためのモジュールを追加
import csv
from io import StringIO



class KgmQpData:
    """
    KGM-Opの各構成部分を橋渡しする基幹部分。以下のものをここで定義・管理：
    １．各構成部分から参照されるインスタンス変数（アクセッサ経由で処理）
    ２．KGM-Qpの各機能を司るメソッドを呼び出す関数「 [#文言再考?]
    """

    ##### 2024/03/07: folderpathをpathlibオブジェクトに変更
    # def __init__(self, mainwindow: object, folderpath: str):
    def __init__(self, mainwindow: object, folderpath: object):
        """
        コンストラクタ：
        メイン窓のスレッドから呼ばれるので、以下を引数とする。
        １．mainwindow: 呼び出し側のメイン窓のインスタンス
        ２．folderpath: 呼び出し時に指定された、KGMデータのフォルダへのフルパス
        """
        ##### デバッグモードのフラグをインスタンス変数として定義
        self._debug_mode = 'Y'   # 直接参照できるように隠蔽なしの名称にした


        ##### KGM-Opの中心的構成部品のインスタンスへの参照 #################
        #     自分自身（KgmQpData）への参照も含む
        #    （インスタンス化時点で参照先が未定のものの初期値は「object」）
        #    （☆「object」については、→ see 柴田2019、p,331）
        self.__my_instance = self               # 自分自身のインスタンス
        self._current_mainwindow = mainwindow  # メイン窓のインスタンス
        self._kgm_qp_mapio = object            # KgmQpQgisIoのインスタンス

        ### 2022/05/12: KgmQpSoundのインスタンスも定義し初期値をobjectに
        self.kgm_snd_inst = object             # KgmQpSoundのインスタンス
        self.kgm_snd_inst_exist = 'N'          # 地味に存否フラグで判定

        ##### ユーザには操作させないインスタンス変数
        self.__kgmqp_root_path = ''       # 本pluginを置くフォルダへのパス
        ### 2024/03/07: folderpathをpathlibオブジェクトに変更
        #####【改訂：2024/03/20】これは廃止、KGMデータセット辞書から取得に統一
        # self.__kgmqp_folderpath = folderpath  # KGMデータのフォルダへのパス
        
        
        self.__kgmqp_list_jpgpics = list  # KGMフォルダ内のjpg画像のリスト
        self.__kgmqp_soundfile_path = ''  # 音声ファイルへのパス
        self.__kgmindex_exists = ''       # KGMindex.txtの存否を示すフラグ
        self.__kgmindex_str = ''          # KGMindex.txtの内容を保持
        # 2023/11/07: ↓これを追加
        self.__kgmindex_startdt = object  # KGMindex.txtによる記録開始日時
        
        
        ##### ユーザの操作などで値を変更可能なインスタンス変数
        self.__current_photo_index = 0         # 表示中のppのインデクス番号
        
        
        ##### 2023/03/05: datetime型で保存した録音開始時刻
        #     とりあえず初期値はtoday（timezone付き）に設定
        # 【要注意：これはNG？】self.__ss_datetime = datetime.today()
        # self.__ss_datetime = datetime.now()
        self.__ss_datetime = object

        ##### 2023/03/05: EXIF時刻からの写真番号検索用のリスト
        self.__exiftime_ppix_list = []


        ##### 2023/02/26: SRTデータのスクロール用に経過時間も保持
        #     【要修正】これで確定ならアクセッサとして定義
        self.sound_elapsed_milisec_adjusted_for_srt = 0


        ##### 起動時に値が確定するインスタンス変数に値を設定
        ##### 2022/06/03: この参照先がkbm_qpdのままだった！!
        self.__kgmqp_root_path = os.path.join(
                                 QgsApplication.qgisSettingsDirPath(),
                                 'python', 'plugins', 'kgm_qpdsr'
                                 )
        
        ##### 2023/11/06:【暫定】異なるTimeZone対応用のインスタンス変数をここで定義
        #     2023/11/07: これはやめる方向。追って削除。
        ##### 2024/03/16:【確定】正式に削除
        # self.kgm_data_timezone = 0
        
        ##### 2023/11/07: EXIF時刻とUTC時刻との時差
        #    （あとでtimedeltaオブジェクトとして保存）
        # self.__exif_timeoffset = datetime.timedelta()
        ##### 2024/03/12: 【暫定】初期値として+9時間を設定
        # self.__exif_timeoffset = object
        # self.__exif_timeoffset = datetime.timedelta(hours=9)
        ###### 2024/03/12: ↑これだけだと別の所で引っかかるので元に戻す
        # self.__exif_timeoffset = object
        
        #####【改訂：2024/03/27】timedeltaとして定義。
        self.__exif_timeoffset = datetime.timedelta()
        
        
        ##### 2022/06/26: クラス定義前に判定したOSがらみの環境の情報を
        #                 グローバル変数から取得しインスタンス変数に記録
        #                 これによりgetter経由での参照に限定する

        # クラス定義前に定義された変数はグローバル変数として参照可
        # 参照だけならglobal宣言は不要、代入するときは必須
        # （参照：柴田 2019、p.280）
        global platform_system_result
        global path_to_user_home
        # 2023/08/25: global path_to_sitepackages

        self.__platform_system_result = platform_system_result
        self.__path_to_user_home = path_to_user_home
        # 2023/08/25: self.__path_to_sitepackages = path_to_sitepackages
        ##### 【2023/08/26】2023/07/03 Mac版でPython 3.9対応にしていた。
        #      それがその後上書きされていたので、改めて復活。
        self.__path_to_sitepackages = path_to_sitepackages

    def amiok(self):
        """ 自分のインスタンスが正しく作られたかの確認 """

        ##### 2022/06/26: QGIS起動時の処理結果を確認
        '''
        # クラス定義前に定義された変数はグローバル変数として参照可
        # 参照だけならglobal宣言は不要、代入するときは必須
        # （参照：柴田 2019、p.280）
        global platform_system_result
        global path_to_user_home
        global path_to_sitepackages
        '''

        print('【KgmQpData: amiok】このコンピュータで稼働中のシステムは、' \
              '{} です。'.format(self.iv_platform_system_result))

        print('【KgmQpData: amiok】self.iv_path_to_user_homeの値は、' \
              '{} です。'.format(self.iv_path_to_user_home))

        print('【KgmQpData: amiok】self.iv_path_to_sitepackagesの値は、' \
              '{} です。'.format(self.iv_path_to_sitepackages))

        print('【KgmQpData: amiok】メイン窓への参照は、' \
              '{} です。'.format(self._current_mainwindow))
        
        
        print('【KgmQpData: amiok】このpluginのあるフォルダへのパスは、'\
              '{} です。'.format(self.__kgmqp_root_path))

        self._current_mainwindow.textEdit.setText('Hello, '\
              'this is an instance of KgmData!')



    ##### KgmQpData内で管理するインスタンス変数のアクセッサ
    #     （柴田2019, p.320-321）

    # 2022/06/26: OS環境関連の情報をインスタンス変数にも記録
    @property
    def iv_platform_system_result(self) -> str:
        """
        【ReadOnly】稼働中のシステムのOS情報（platform.systemによる）
        """
        return self.__platform_system_result

    @property
    def iv_path_to_user_home(self) -> str:
        """
        【ReadOnly】使用中のユーザのルートフォルダへのパス
        """
        return self.__path_to_user_home

    ##### 【2023/08/26】2023/07/03 Mac版でPython 3.9対応にしていた。
    #      それがその後上書きされていたので、改めて復活。
    @property
    def iv_path_to_sitepackages(self) -> str:
        """
        【ReadOnly】（Macintosh限定）
        （QGIS3.16以降で）PIL使用に必要となる、pillowをインストール
        したフォルダへのパス
        """
        return self.__path_to_sitepackages


    @property
    def kgmqp_root_path(self) -> str:
        """
        【ReadOnly】KgmQp pluginを置くフォルダへのパス
        ここにtracklogやphotopointのスタイルファイルも置く
        """
        return self.__kgmqp_root_path
    
    
    @property
    def kgmqp_list_jpgpics(self) -> list:
        """
        【ReadOnly】KGMデータフォルダ内のjpg画像ファイルのリスト
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmqp_list_jpgpics


    @property
    def kgmqp_soundfile_path(self) -> str:
        """
        【ReadOnly】音声ファイルへのパス
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmqp_soundfile_path

    @property
    def kgmindex_exists(self) -> str:
        """
        【ReadOnly】KGMindex.txtの存否を示すフラグ
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmindex_exists

    @property
    def kgmindex_str(self):
        """
        【ReadOnly】KGMindex.txtの内容を保持
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmindex_str

    ##### 2023/11/07：追加
    @property
    def kgmindex_startdt(self) -> datetime:
        """
        【ReadOnly】KGMindex.txtから取得した記録開始日時
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmindex_startdt
    #####

    
    
    @property
    def pplyr_fields(self):
        """ photopointsレイヤの属性フィールド一覧のgetter """
        return self.__pplyr_fields

    @pplyr_fields.setter
    def pplyr_fields(self, flds: list) -> None:
        """ photopointsレイヤの属性フィールド一覧のsetter """
        self.__pplyr_fields = flds

    @property
    def current_photo_index(self) -> int:
        """ 写真画像窓に表示される写真のインデクス番号のgetter """
        return self.__current_photo_index

    @current_photo_index.setter
    def current_photo_index(self, ix: int) -> None:
        """ 写真画像窓に表示される写真のインデクス番号のsetter """
        self.__current_photo_index = ix


    ##### 2023/11/07: EXIF時刻とUTC時刻との時差
    #               （timedeltaオブジェクトとして保持）
    @property
    def exif_timeoffset(self) -> timedelta:
        """
        EXIF時刻とUTC時刻との時差を示すtimedelta
        """
        return self.__exif_timeoffset
    
    @exif_timeoffset.setter
    def exif_timeoffset(self, exif_toff: timedelta) -> None:
        """
        EXIF時刻とUTC時刻との時差を示すtimedeltaのsetter
        """
        self.__exif_timeoffset = exif_toff


    ##### 2023/03/05: 文字列検索でのKGM表示更新用の変数を追加
    # 【変更】当初はEXIF時刻・写真番号の２次元配列のつもりだったが、
    #         厄介だったのでEXIF時刻のみの１次元配列に変更
    @property
    def exiftime_ppix_list(self) -> list:
        """ EXIF時刻リストのgetter """
        return self.__exiftime_ppix_list

    @exiftime_ppix_list.setter
    def exiftime_ppix_list(self, ixpplist: list) -> None:
        """ EXIF時刻リストのsetter """
        self.__exiftime_ppix_list = ixpplist

    @property
    def ss_datetime(self) -> datetime:
        """  """
        return self.__ss_datetime

    @ss_datetime.setter
    def ss_datetime(self, recss: datetime) -> None:
        """  """
        self.__ss_datetime = recss




    def create_instances(self):
        """
        【2024/02/22】改訂：１の(2)を追加
        １．以下のインスタンスとそれへの参照を作成
          (1) KgmQpQgisIoのインスタンスを作りself._kgm_qp_mapioに入れる
          (2) KgmDataDictIoのインスタンスを作りself._kgm_dd_ioに入れる
        ２．KGMの３種類のデータ各々を処理する４クラスのインスタンスを作成
          (1) KgmQpTracklog： GPSトラックログに関する処理を担当
          (2) KgmQpPhotopoints： 写真画像・メモテキストに関する処理を担当
          (3) KgmQpExif： 写真画像のEXIF情報に関する処理を担当
          (4) KgmQpSound： 音声に関する処理を担当
        【2024/02/26】方針変更：１の(2)は廃止、KgmQpQgisIoにカプセル化
        """
        ##### １-(1) KgmQpQgisIoのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        #    変数名は「_kgm_qp_mapio」と一般的な名称にする
        self._kgm_qp_mapio = KgmQpQgisIo(self.__my_instance)

        if self._debug_mode == 'Y':
            print('【KgmQpData】KgmQpQgisIoのインスタンスへの参照は、'\
                  '{} です。'.format(self._kgm_qp_mapio))
        self._kgm_qp_mapio.amiok()
        
        
        
        ##### 2024/02/26: KgmDataDictManagerのインスタンス作成を
        #                 KgmQpQgisIoに依頼
        self._kgm_qp_mapio.create_instances()
        
        
        
        ##### 2024/02/23: この位置に移動
        ##### ２-(1) KgmQpTracklogのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        self.kgm_tlg_inst = KgmQpTracklog(self.__my_instance,
                                          self._kgm_qp_mapio)

        if self._debug_mode == 'Y':
            self.kgm_tlg_inst.amiok()
        
        ##### ２-(3) KgmQpExifのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        self.kgm_exif_inst = KgmQpExif(self.__my_instance)


        # 【2023/03/05】KgmQpExifへの参照を引数に追加したため、
        #  ２-(2) KgmQpPhotopointsのインスタンス作成をここへ移動

        self.kgm_pp_inst = KgmQpPhotopoints(self.__my_instance,
                                            self._kgm_qp_mapio,
                                            self.kgm_exif_inst)
        if self._debug_mode == 'Y':
            self.kgm_pp_inst.amiok()


        ##### ２-(4) KgmQpSoundのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        self.kgm_snd_inst = KgmQpSound(self.__my_instance)
        
        
        
        #####【2024/03/27】QGZから開いたデータがある場合の処理
        ##### self.setup_kgm_datasets_dictionary_by_existing_data()
    
    
    
    def append_new_kgm_dataset_to_dict(self, kgmqp_folderpath: object) -> None:
        """
        【2024/03/19】
        「読み込み」ボタンクリック時の処理に特化した新関数として定義。
        【備考】この場合、
            ・処理対象フォルダは指定されている
            ・KGMレイヤの新規作成を伴う
            ・KGMデータセットに新辞書を追加
        【改訂：2024/03/27】
        ・時差補正関係処理を整理・別関数化。
        ・append_new_kgm_dataset_to_kgmdss_dictionaryの引数に、
        　int_exif_timeoffsetを追加。
        """
        
        #####【方針変更：2024/03/27】インスタンス変数exif_timeoffsetを廃止しようと
        #     思ったが、play_soundeほかあまりにも多くの箇所で参照されているため、
        #     現時点で廃止は無理と判断。専用の関数で一括セットする方針に変更。
        
        
        ##### 2024/03/19: フォルダ内にgpxファイルが１つだけあることを確認し、
        #     そのフルパスをpathlibオブジェクトとして受け取る
        fullpath_to_kgm_gpx_file = self.specify_fullpath_to_kgm_gpx_file(kgmqp_folderpath)
        
        ##### 2024/03/27: KGMindex.txtの内容をコンマ区切りテキストで取得。
        #     【要検討】KGMindex.txtがない場合（abliedaなど）の処理？
        kgmindex_csv_string = self.get_kgmindex_string(kgmqp_folderpath)
        
        
        #####【暫定：2024/08/16】KGMindex.txtをパースしたリストを取得
        kgmindex_fields = self.parse_kgmindex_fields(kgmindex_csv_string)
        
        for ix, fld in enumerate(kgmindex_fields):
            print("kgmindex_fields[{}]: {}".format(ix, fld))
        
        #####【暫定：2024/08/16】新リストkgmindex_fieldsの[0]を使用
        kgmindex_startdt = kgmindex_fields[0]
        
        
        '''
        【改訂：2024/08/16】多言語対応化のためparse_kgmindex_fields使用に変更。
        ##### 2024/03/27: KGMindex.txtから録音開始日時をdateteime(aware)で取得。
        kgmindex_startdt = self.get_kgmindex_startdt(kgmindex_csv_string) 
        '''
        
        
        ##### 2024/03/27: フォルダ内の写真のリストを取得。
        list_jpegpics = self.set_kgmqp_list_jpgpics(kgmqp_folderpath)
        
        ##### 2024/03/27: フォルダ内写真中のEXIF日時で、最も早いものを取得。
        exifdt_1st = self.kgm_exif_inst.get_exifdt_1st(kgmqp_folderpath, list_jpegpics)
        
        ##### 2024/03/27: EXIF日時とUTC日時との時差をtimedeltaで取得。
        #    【方針変更：2024/03/27】self.exif_timeoffsetは温存。
        timedelta_exif_timeoffset = \
            self.kgm_exif_inst.calculate_time_offset_of_exif_datetime( \
                                    kgmindex_startdt, \
                                    exifdt_1st \
                                    )
        
        ##### 2024/03/27: インスタンス変数をここで一括設定。
        self.set_kgmqpdata_instance_variables( \
                            timedelta_exif_timeoffset, \
                            kgmindex_startdt, \
                            list_jpegpics \
                            )
        
        
        ##### 2024/03/19: gpxファイルへのパスを引数でKgmQpQgisIoの関数に渡し、
        #     KGMデータの３種のレイヤを一括作成して、その内容により、
        #     KGMデータセット辞書に追加（または辞書を新規作成）。
        #####【改訂：2024/03/27】
        #     時差補正をPhotoPoint作成時に実施するため、exif_timeoffsetを
        #     引数に追加。
        #     【備考：2027/03/27】ここは別モジュールのクラス内関数の呼び出し
        #      なので、self.exif_timeoffsetを明示的に引数で参照。
        self._kgm_qp_mapio.append_new_kgm_dataset_to_kgmdss_dictionary( \
                                                fullpath_to_kgm_gpx_file, \
                                                self.exif_timeoffset \
                                                )
        
        
        #####【改訂：2024/03/23】OpenStreetMapをここで読み込む
        self._kgm_qp_mapio.load_xyz_osm()
        
        
        
        
        #####【暫定：2024/05/20】set_exiftime_ppix_listの呼び出しが削除されていた？
        #     引数ppsource_pathは関数内で使われていないようなので、とりあえず空文字列
        ppsource_path = ''        
        self.exiftime_ppix_list = self.kgm_pp_inst.set_exiftime_ppix_list(ppsource_path)
        
        print('【setup_kgm_datasets_dictionary_by_existing_data】self.exiftime_ppix_listの値は' \
              '{}です。'.format(self.exiftime_ppix_list))
        
        
        
        
        return
    
    
    
    def set_kgmqpdata_instance_variables(self, \
                                        timedelta_exif_timeoffset: timedelta, \
                                        kgmindex_startdt: datetime, \
                                        list_jpegpics: list \
                                        ) -> None:
        """
        【2024/03/27】
        KgmQpDataのインスタンス変数をすべて排除するのは非現実的と判断、
        専用の関数でまとめてセットする方針に転換。
        データの新規・追加読み込み時、切替え時、QGZから読み込み時に、
        必ずこの関数により、アクティブなKGMデータセットに対応する
        インスタンス変数を一括セットする。
        それらの変数は引数により明示的に与える。
        """
        
        
        self.__exif_timeoffset = timedelta_exif_timeoffset
        self.__kgmindex_startdt = kgmindex_startdt
        self.__kgmqp_list_jpgpics = list_jpegpics
        
        
        print('【set_kgmqpdata_instance_variables】現時点のself.exif_timeoffsetの値は' \
              '{}です。'.format(self.exif_timeoffset))
        print('【set_kgmqpdata_instance_variables】現時点のself.kgmindex_startdtの値は' \
              '{}です。'.format(self.kgmindex_startdt))
        print('【set_kgmqpdata_instance_variables】現時点のself.kgmqp_list_jpgpicsの値は' \
              '{}です。'.format(self.kgmqp_list_jpgpics))
        
        return
    
    
    
    def setup_kgm_datasets_dictionary_by_existing_data(self) -> bool:
        """
        【2024/03/27】
        既存のQGZプロジェクトを開いてからKGMを立ち上げた場合に、
        既登録のKGMデータレイヤからKGMデータセット辞書を作成し、
        その最初のものをアクティブにする。
        【改訂：2024/03/29】
        素からKGMを立ち上げた場合に対処するためbool型戻り値を追加。
        """
        
        #####【2024/03/27】既登録KGMデータレイヤからデータセット辞書を作成。
        datasets_count = self._kgm_qp_mapio.prepare_kgm_datasets()
        
        if (datasets_count > 0):
            """
            KGMデータセット辞書が作成できた。
            """
            active_tlg_dsp_name = self._kgm_qp_mapio.get_tlg_dsp_name_of_active_kgm_dataset()
            
            print('【setup_kgm_datasets_dictionary_by_existing_data】active_tlg_dsp_nameの値は' \
                  '{}です。'.format(active_tlg_dsp_name))
            
            
            '''
            ##### 2024/03/19: フォルダ内にgpxファイルが１つだけあることを確認し、
            #     そのフルパスをpathlibオブジェクトとして受け取る
            fullpath_to_kgm_gpx_file = self.specify_fullpath_to_kgm_gpx_file(kgmqp_folderpath)
            '''
            
            ##### 2024/03/27: 現在アクティブなKGMデータセット辞書から、データフォルダへの
            #     パスを取得。
            kgmqp_folderpath = self._kgm_qp_mapio.set_active_kgmqp_data_path()
            
            ##### 2024/03/27: KGMindex.txtの内容をコンマ区切りテキストで取得。
            #     【要検討】KGMindex.txtがない場合（abliedaなど）の処理？
            kgmindex_csv_string = self.get_kgmindex_string(kgmqp_folderpath)
            
            
            
            
            '''
            【改訂：2024/08/16】多言語対応化のためparse_kgmindex_fields使用に変更。
            ##### 2024/03/27: KGMindex.txtから録音開始日時をdateteime(aware)で取得。
            kgmindex_startdt = self.get_kgmindex_startdt(kgmindex_csv_string)
            '''
            
            #####【暫定：2024/08/16】KGMindex.txtをパースしたリストを取得
            kgmindex_fields = self.parse_kgmindex_fields(kgmindex_csv_string)
            
            for ix, fld in enumerate(kgmindex_fields):
                print("kgmindex_fields[{}]: {}".format(ix, fld))
            
            #####【暫定：2024/08/16】新リストkgmindex_fieldsの[0]を使用
            kgmindex_startdt = kgmindex_fields[0]
            
            
            
            
            ##### 2024/03/27: フォルダ内の写真のリストを取得。
            list_jpegpics = self.set_kgmqp_list_jpgpics(kgmqp_folderpath)
            
            ##### 2024/03/27: フォルダ内写真中のEXIF日時で、最も早いものを取得。
            exifdt_1st = self.kgm_exif_inst.get_exifdt_1st(kgmqp_folderpath, list_jpegpics)
            
            ##### 2024/03/27: EXIF日時とUTC日時との時差をtimedeltaで取得。
            #    【方針変更：2024/03/27】self.exif_timeoffsetは温存。
            timedelta_exif_timeoffset = \
                self.kgm_exif_inst.calculate_time_offset_of_exif_datetime( \
                                        kgmindex_startdt, \
                                        exifdt_1st \
                                        )
            
            ##### 2024/03/27: インスタンス変数をここで一括設定。
            self.set_kgmqpdata_instance_variables( \
                                timedelta_exif_timeoffset, \
                                kgmindex_startdt, \
                                list_jpegpics \
                                )
            
            #####【改訂：2024/03/29】cbxへの追加は別関数で実施。
            # self.add_tlglyr_name_to_cbx()
            
            
            #####【暫定：2024/05/20】set_exiftime_ppix_listの呼び出しが削除されていた？
            #     引数ppsource_pathは関数内で使われていないようなので、とりあえず空文字列
            ppsource_path = ''        
            self.exiftime_ppix_list = self.kgm_pp_inst.set_exiftime_ppix_list(ppsource_path)
            
            print('【setup_kgm_datasets_dictionary_by_existing_data】self.exiftime_ppix_listの値は' \
                  '{}です。'.format(self.exiftime_ppix_list))
            
            result = True
            
        else:
            result = False
        
        return result
    
    
    
    def add_tlglyr_name_to_cbx(self):
        """
        【改訂：2024/03/22】
        現在アクティブなKGMデータセットをKGMデータセット辞書から、
        GPXのtracklogの共通表示名を取得し、
        その文字列をメイン窓のコンボボックスに追加する。
        """
        
        tptlg_layer_common_name = self._kgm_qp_mapio.get_tlg_dsp_name_of_active_kgm_dataset()
        
        self._current_mainwindow.insert_new_tracklog_into_cbx(tptlg_layer_common_name)
        
        return
    
    
    
    def add_tlglyr_names_list_to_cbx(self):
        """
        【2024/03/29】
        KGMデータセット辞書に登録ずみの全データセットから、各データの
        tlg表示名のリストを作り、降順にソートしたうえで、
        それをメイン窓のcbxに一括登録。
        【備考】その際一時的にcbxの変更シグナルを止め追加完了後に再開。
        """
        
        tlglyr_names_list = \
            self._kgm_qp_mapio.get_layernames_list_in_kgmdss_using_kgmdd_mgr()
        
        if tlglyr_names_list:
            """
            既存のtlg表示名があれば
            """
            
            tlglyr_names_list_sorted = sorted(tlglyr_names_list, reverse=True)
            self._current_mainwindow.insert_tracklog_names_into_cbx(tlglyr_names_list_sorted)
        
        else:
            pass
        
        return
    
    
    
    def switch_active_kgm_dataset_by_cbx(self, \
                            crnt_cbx_text: str \
                            ) -> str:
        """
        【2024/03/22】
        メイン窓のコンボボックスの選択内容により、
        アクティブなKGMデータセット辞書を切り換え、
        そのtlg表示名を返す。
        【備考】KGMデータセット新規追加は、cbx表示名が
        アクティブKGMデータセットのtlg表示名と同一である
        ことで判定、その場合は、現在アクティブなKGMデータ
        セット辞書のtlg表示名を返す。
        """
        tlg_dsp_name_in_kgmds = self._kgm_qp_mapio.get_tlg_dsp_name_of_active_kgm_dataset()
        
        if (crnt_cbx_text == tlg_dsp_name_in_kgmds):
            """
            cbxのテキストが現在アクティブなKGMデータセットのtlg表示名と同一
            """
            pass
        
        else:
            """
            アクティブなKGMデータセットを切り換え
            """
            tlg_dsp_name_in_kgmds = \
                self._kgm_qp_mapio.kgmdd_mgr.switch_active_kgm_dataset_by_tlg_dsp_name(crnt_cbx_text)
            
            
            #####【2024/03/29】一連の処理をこの関数でまとめて実施。
            self.setup_variables_based_on_active_kgm_datafolder()
        
        return tlg_dsp_name_in_kgmds
    
    
    
    def setup_variables_based_on_active_kgm_datafolder(self):
        """
        【2024/03/29】
        アクティブなKGMデータセットに基づき、それに対応する
        KGMデータフォルダ内のファイルから時刻・写真・音声の処理に
        必要な情報を取得し、KgmQpDataのインスタンス変数に登録する。
        """
        
        ##### 2024/03/27: 現在アクティブなKGMデータセット辞書から、データフォルダへの
        #     パスを取得。
        kgmqp_folderpath = self._kgm_qp_mapio.set_active_kgmqp_data_path()
        
        ##### 2024/03/27: KGMindex.txtの内容をコンマ区切りテキストで取得。
        #     【要検討】KGMindex.txtがない場合（abliedaなど）の処理？
        kgmindex_csv_string = self.get_kgmindex_string(kgmqp_folderpath)
        
        
        
        
        
        
        '''
        【改訂：2024/08/16】多言語対応化のためparse_kgmindex_fields使用に変更。
        ##### 2024/03/27: KGMindex.txtから録音開始日時をdateteime(aware)で取得。
        kgmindex_startdt = self.get_kgmindex_startdt(kgmindex_csv_string)
        '''
        
        #####【暫定：2024/08/16】KGMindex.txtをパースしたリストを取得
        kgmindex_fields = self.parse_kgmindex_fields(kgmindex_csv_string)
        
        for ix, fld in enumerate(kgmindex_fields):
            print("kgmindex_fields[{}]: {}".format(ix, fld))
        
        #####【暫定：2024/08/16】新リストkgmindex_fieldsの[0]を使用
        kgmindex_startdt = kgmindex_fields[0]
        
        
        
        
        
        ##### 2024/03/27: フォルダ内の写真のリストを取得。
        list_jpegpics = self.set_kgmqp_list_jpgpics(kgmqp_folderpath)
        
        ##### 2024/03/27: フォルダ内写真中のEXIF日時で、最も早いものを取得。
        exifdt_1st = self.kgm_exif_inst.get_exifdt_1st(kgmqp_folderpath, list_jpegpics)
        
        ##### 2024/03/27: EXIF日時とUTC日時との時差をtimedeltaで取得。
        #    【方針変更：2024/03/27】self.exif_timeoffsetは温存。
        timedelta_exif_timeoffset = \
            self.kgm_exif_inst.calculate_time_offset_of_exif_datetime( \
                                    kgmindex_startdt, \
                                    exifdt_1st \
                                    )
        
        ##### 2024/03/27: インスタンス変数をここで一括設定。
        self.set_kgmqpdata_instance_variables( \
                            timedelta_exif_timeoffset, \
                            kgmindex_startdt, \
                            list_jpegpics \
                            )
        
        
        
        #####【暫定：2024/05/20】set_exiftime_ppix_listの呼び出しが削除されていた？
        #     引数ppsource_pathは関数内で使われていないようなので、とりあえず空文字列
        ppsource_path = ''        
        self.exiftime_ppix_list = self.kgm_pp_inst.set_exiftime_ppix_list(ppsource_path)
        
        print('【setup_kgm_datasets_dictionary_by_existing_data】self.exiftime_ppix_listの値は' \
              '{}です。'.format(self.exiftime_ppix_list))
        
        return
    
    
    def get_list_of_files_using_glob(self, kgmqp_folderpath: object, root_criteria: str, ext_criteria: str) -> list:
        """
        2024/02/21:
        get_list_of_files_with_specified_extentionからglob検索の部分を切り出し
        extention以外の部分で（も）検索可能にする
        【改訂：2024/03/19】
        検索対象フォルダへのパスを文字列でなくpathlibオブジェクトに変更。
        glob検索式作成時点で文字列に変換して使用する。
        """
        
        ##### 2024/03/07: ↓検索条件の作り方が間違っていた模様
        # glob_search_criteria = root_criteria + '*.*\.' + ext_criteria      # extention非限定にする
        
        glob_search_criteria = '.*' + root_criteria + '.' + ext_criteria      # extention非限定にする
        
        print('globの検索条件式は、{} です。'.format(glob_search_criteria))
        
        
        #####【改訂：2024/03/19】pathlibオブジェクトからここで文字列に変換
        str_kgmqp_folderpath = str(kgmqp_folderpath)
        
        list_of_files = []
        
        #####【2024/03/19：今後要検討】ここではos.path.joinを使用
        str_glob_target = os.path.join(str_kgmqp_folderpath, '*.*')
        list_of_files_fullpath = \
                [fp for fp in glob.glob(str_glob_target) \
                 if re.search(glob_search_criteria, str(fp))]
        for file in sorted(list_of_files_fullpath):
                # ファイル名（ソートずみ）のリストを作成
            filenameonly = os.path.basename(file)
            list_of_files.append(filenameonly)
        
        print('検索条件に合致するファイルのリストは、{} です。'.format(list_of_files))
        
        return list_of_files
    
    
    
    def specify_fullpath_to_kgm_gpx_file(self, \
                                         kgmqp_folderpath: object \
                                         ) -> object:
        """
        【2024/03/19】
        kgmqp_folderpath内を検索し、gpxファイルが１つだけ存在することを確認し、
        そのgpxファイルへのフルパスをpathlibオブジェクトとして返す。
        見つからない・複数ある等の場合は、メッセージを出した上でNoneを返す。
        【備考】もとはKgmQpDocSRDockWidget内にあった処理を修正してここへ移動。
        """
        
        list_gpxfile_fullpath = []
        
        ##### 2024/03/19: .gpxファイルを検索
        root_criteria = ''
        ext_criteria = '(gpx|GPX)'
        
        try:
            list_gpx_filenames = \
                self.get_list_of_files_using_glob(\
                                    kgmqp_folderpath, \
                                    root_criteria, \
                                    ext_criteria)
        except:
            QMessageBox.information(None,
                "【警告：エラーが起こりました！】",
                "『聞き書きマップ』のデータのあるフォルダを指定してください。",
                QMessageBox.Yes)
            result = None
        else:
            if not list_gpx_filenames:
                QMessageBox.information(None,
                    "【警告：GPXファイルがありません！】",
                    "『聞き書きマップ』のデータのあるフォルダを指定してください。",
                     QMessageBox.Yes)
                result = None
            elif len(list_gpx_filenames) > 1:
                QMessageBox.information(None,
                    "【警告：GPXファイルが２つ以上あります！】",
                    "『聞き書きマップ』のデータのあるフォルダを指定してください。",
                    QMessageBox.Yes)
                result = None
            else:
                ##### 2024/03/07: 正しく指定されたことを確認
                print('【KgmQpData: specify_fullpath_to_kgm_gpx_file】kgmqp_folderpathの値は' + \
                      '{}です。'.format(kgmqp_folderpath))
                
                gpx_filename = list_gpx_filenames[0]
                fullpath_to_kgm_gpx_file = kgmqp_folderpath / Path(gpx_filename)
                
                print('【KgmQpData: specify_fullpath_to_kgm_gpx_file】fullpath_to_kgm_gpx_fileの値は' + \
                      '{}です。'.format(fullpath_to_kgm_gpx_file))
                
                result = fullpath_to_kgm_gpx_file
        
        return result
    
    
    
    def get_fullpath_to_active_kgm_data_folder(self) -> object:
        """
        【2024/03/20】
        現在アクティブなKGMデータフォルダへのパスをpathlibのオブジェクト
        として取得。
        実質はKgmQpQgisIoのset_active_kgmqp_data_pathにより実施。
        【方針】今後はKgmQpQgisIo以外のクラスから呼ぶときは、これを経由
        するのを基本にする。
        """
        
        active_kgm_data_path = self._kgm_qp_mapio.set_active_kgmqp_data_path()
        
        return active_kgm_data_path
    
    
    
    def set_kgmqp_list_jpgpics(self, kgmqp_folder_path: object) -> list:
        """
        写真画像のjpgファイル名リストを返す
        【改訂：2024/03/24】
        これはPhotopointsレイヤ新規作成（shpファイルなし）のときに
        必要なため、KGMデータフォルダを引数にする形で、
        KgmQpData名内に置く。
        
        """
        
        list_jpgpics = []
        
        #####【改訂：2024/03/24】この参照は廃止。引数を使用。
        # kgmqp_folder_path = self._kgm_qp_coredata.get_fullpath_to_active_kgm_data_folder()
        
        
        root_criteria = ''
        ext_criteria = '(jpg|JPG)'
        
        if self._debug_mode == 'Y':
            print('【set_kgmqp_list_jpgpics】root_criteriaの値は、'\
                  '{} です。'.format(root_criteria))
            print('【set_kgmqp_list_jpgpics】ext_criteriaの値は、'\
                  '{} です。'.format(ext_criteria))
        
        list_jpgpics = self.get_list_of_files_using_glob(\
                                        kgmqp_folder_path, \
                                        root_criteria, \
                                        ext_criteria
                                        )
        
        
        if self._debug_mode == 'Y':
            print('抽出した写真のリストは、{} です。'.format(list_jpgpics))
        
        return list_jpgpics
    
    
    
    ##### 2021/11/15: メイン窓のボタン（など）の操作に対応する処理
    def button_sound_forward(self):
        """  音声を〇秒進める"""
        milisec = self.kgm_snd_inst.player.position() + \
                  self.kgm_snd_inst.foward_backward_seconds*1000
        # 頭出しして再生
        self.kgm_snd_inst.player.setPosition(milisec)
        self.kgm_snd_inst.player.play()

    def button_sound_backward(self):
        """  音声を〇秒戻す"""
        milisec = self.kgm_snd_inst.player.position() - \
                  self.kgm_snd_inst.foward_backward_seconds*1000
        # 頭出しして再生
        self.kgm_snd_inst.player.setPosition(milisec)
        self.kgm_snd_inst.player.play()

    def button_sound_stopresume(self) -> str:
        """
        音声再生を停止・再開
        arg: None
        return: text to be shown in the button
        """

        if (self.kgm_snd_inst.player.state() == QMediaPlayer.PlayingState):
            self.kgm_snd_inst.player.pause()
            # labeltext = '再開'
            labeltext = self.labeltext_stopresume()
        elif (self.kgm_snd_inst.player.state() == QMediaPlayer.PausedState):
            self.kgm_snd_inst.player.play()
            # labeltext = '停止'
            labeltext = self.labeltext_stopresume()
        else:
            self.kgm_snd_inst.player.stop()
            # labeltext = '【終了】'
            labeltext = self.labeltext_stopresume()

        return labeltext

    def button_sound_listen_again(self):
        """ もう一度聞く """
        milisec = self.kgm_snd_inst.sound_elapsed_milisec_adjusted
        # 頭出しして再生
        self.kgm_snd_inst.player.setPosition(milisec)
        self.kgm_snd_inst.player.play()

    def button_pic_next(self) -> list:
        """ 「次の写真へ」 """

        int_max = len(self.kgmqp_list_jpgpics)
        # print(".jpgファイルの総数は、", int_max, "個です。")
        if self.current_photo_index >= int_max - 1:
            self.current_photo_index = int_max - 1
        else:
            self.current_photo_index += 1          # incliment

        self.kgm_pp_inst.zoom_to_selected_point()
        self.kgm_snd_inst.play_sound(self.current_photo_index)
        pp_attrlist = \
            self.current_photo_attributes(self.current_photo_index)

        return pp_attrlist

    def button_pic_previous(self) -> list:
        """ 「前の写真へ」 """

        int_max = len(self.kgmqp_list_jpgpics)
        # print(".jpgファイルの総数は、", int_max, "個です。")
        
        
        if self.current_photo_index > int_max - 1:
            #####【2024/10/09】↓これだと写真総数が１枚だけのとき
            #     self.current_photo_indexが「-1」でエラーになる！
            # if self.current_photo_index >= int_max - 1:
            ##### 2023/09/30: これだと最後の写真から戻れなくなる！
            #     self.current_photo_index = int_max - 1
            self.current_photo_index -= 1          # decliment
        elif self.current_photo_index <= 0:
            self.current_photo_index = 0           # 0が最小
        else:
            self.current_photo_index -= 1          # decliment

        self.kgm_pp_inst.zoom_to_selected_point()
        self.kgm_snd_inst.play_sound(self.current_photo_index)
        pp_attrlist = \
            self.current_photo_attributes(self.current_photo_index)

        return pp_attrlist

    def labeltext_stopresume(self) -> str:
        """
        音声再生の停止・再開・終了の表示を更新
        arg: None
        return: text to be shown on Stop/Resume button
        """

        if (self.kgm_snd_inst.player.state() == QMediaPlayer.PlayingState):
            labeltext = '停止'
        elif (self.kgm_snd_inst.player.state() == QMediaPlayer.PausedState):
            labeltext = '再開'
        else:
            labeltext = '【終了】'

        return labeltext
    
    
    
    def button_qtableview(self) -> None:
        """
        【暫定：2023/02/22】
        pushButton_KmlExportクリックからここへ飛ぶ
        QTableViewのテスト用
        """
        
        '''
        #####【暫定：2024/05/20】センター支援費報告書作成用にSRTを再開
        #####【暫定：TableView関係処理は一時的に停止】
        QMessageBox.information(None,
                        "【暫定】",
                        "この処理は一時的に停止中です。",
                        QMessageBox.Yes)
        '''
        
        
        #####【暫定：2024/05/20】センター支援費報告書作成用にSRTを再開
        #####【暫定：2024/05/03】TableView関係処理は一時的に停止
        
        ##### 2023/02/22: 【暫定：QTableViewのテスト用】
        if self._debug_mode == 'Y':
            print('【button_qtableview】「拡張機能」ボタンがクリックされました。')


        ##### 2023/02/25: SRT表示のテスト
        #     based on: gpxファイルへのパス設定のルーチン
        
        
        #####【要改訂】pathlibに統一・共通glob関数使用に
        #####【暫定：2024/05/20】センター支援費報告書作成用にSRTを再開に併せ改訂
        # str_glob_target = os.path.join(
        #                  self.kgmqp_folderpath,
        #                  '*.srt')
        
        active_kgm_data_path = self.get_fullpath_to_active_kgm_data_folder()
        ### str_glob_target = active_kgm_data_path / Path('*.srt')
        
        ###if self._debug_mode == 'Y':
        ###    print('【button_qtableview】str_glob_targetの値：{}'.format(str_glob_target))
        
        root_criteria = ''
        ext_criteria = '(SRT|srt)'
        list_srtfiles = self.get_list_of_files_using_glob(active_kgm_data_path, root_criteria, ext_criteria)
        srtfile_path = active_kgm_data_path / Path(list_srtfiles[0])
        
        if self._debug_mode == 'Y':
            print('【button_qtableview】srtファイルへのパスは、'\
                  '{} です。'.format(srtfile_path))
        
        
        
        '''
        try:
            list_srtfile_fullpath = glob.glob(str_glob_target)
        except:
            ##### 2022/02/19: 今後、ファイルなしなどのエラー処理を追記
            pass
        else:
            if len(list_srtfile_fullpath) > 1:
                ##### 2022/02/19: 今後、一覧から選ばせる処理を追記
                print('【button_qtableview】srtファイルが複数あります：'\
                      '{} '.format(list_srtfile_fullpath))
            else:
                srtfile_path = list_srtfile_fullpath[0]
        finally:
            print('【button_qtableview】srtファイルへのパスは、'\
                  '{} です。'.format(srtfile_path))

            # return srtfile_path
        '''


        with open(srtfile_path, mode='r', encoding="utf-8") as f:
            subs = srt.parse(f.read())
        


            ##### 2023/02/26: subs（＝generatorオブジェクト）をもとに、
            #     その各行（＝Subtitleオブジェクト）を要素とする配列に変換
            #     これをlf.subs_test01に入れる
            self.subs_test01 = list(subs)

            print(self.subs_test01)
        
        
        return
    
    
    
    def button_jamboard_export(self, export_path: str) -> None:
        """
        「写真印刷」ボタンクリック時の処理
        ☆2022/02/26: 当面は、JamBoard用画像ファイルの書き出し
        【改訂：2024/04/19】
        KGMデータ辞書版化にあわせた改訂：
        ☆地図・写真画像名のベースを辞書から取得したtptlg表示名に変更。
        get_tlg_dsp_name_of_active_kgm_dataset()により、QGZからの起動
        直後にも対応。
        【再改定：2024/05/03】
        地図・写真画像の書き出しフォルダを引数から取得。
        その旨を引数export_pathで明示。
        """

        ##### 2022/20/06: 全写真か現表示写真かのフラグ
        flag_allpics = 'Y'

        if self._debug_mode == 'Y':
            print('【KgmQpData】「写真印刷」ボタンがクリックされました。')
        
        tptlg_display_name =  self._kgm_qp_mapio.get_tlg_dsp_name_of_active_kgm_dataset()
        
        map_image_name = tptlg_display_name + \
                        '_撮影地点_' + \
                        str(self.current_photo_index) + \
                        '_地図.png'
        
        '''
        #####【要改訂】pathlibに統一
        fullpath_map = os.path.join(path, map_image_name)
        '''
        
        #####【改訂：2024/04/29】KGMデータフォルダへのパスを辞書から取得。
        #      処理をpathlibに統一。
        kgmqp_folderpath = self.get_fullpath_to_active_kgm_data_folder()
        
        #####【再改定：2024/05/03】地図・写真画像の書き出しフォルダは引数から取得。
        # fullpath_map = kgmqp_folderpath / Path(map_image_name)
        fullpath_map = export_path / Path(map_image_name)
        
        
        #####【改訂：2024/04/29】QGISの都合により引数を文字列に戻す。
        str_fullpath_map = str(fullpath_map)
        self._kgm_qp_mapio.save_map_as_image(str_fullpath_map)
        
        
        #####【改訂：2024/04/29】写真画像名のベースを、KGMデータセット辞書から
        #     取得したtptlg表示名に変更。
        
        if flag_allpics != 'Y':
            """ 現在表示中の写真だけを書き出す """
            jb_image = self.compose_jb_image(kgmqp_folderpath, self.current_photo_index)
            jb_image_name = tptlg_display_name + \
                            '_撮影地点_' + \
                            str(self.current_photo_index) + \
                            '_写真.jpg'
            
            '''
            fullpath_jb_image = os.path.join(path, jb_image_name)
            '''
            
            #####【再改定：2024/05/03】地図・写真画像の書き出しフォルダは引数から取得。
            fullpath_jb_image = export_path / Path(jb_image_name)
            
            jb_image.save(fullpath_jb_image)
        else:
            """ すべての写真を書き出す """
            for ix, jpg_filename in enumerate(self.kgmqp_list_jpgpics):
                jb_image = self.compose_jb_image(kgmqp_folderpath, ix)
                jb_image_name = tptlg_display_name + \
                        '_撮影地点_' + \
                        str(ix) + \
                        '_写真.jpg'
                
                '''
                fullpath_jb_image = os.path.join(path, jb_image_name)
                '''
                
                #####【再改定：2024/05/03】地図・写真画像の書き出しフォルダは引数から取得。
                # fullpath_jb_image = kgmqp_folderpath / Path(jb_image_name)
                fullpath_jb_image = export_path / Path(jb_image_name)
                
                jb_image.save(fullpath_jb_image)
                
        QMessageBox.information(None,
                                "通知",
                                "写真・地図の画像を書き出しました。",
                                QMessageBox.Yes)

    def compose_jb_image(self, pp_pic_folder: object, ix: int) -> object:
        """
        現在表示中の写真にID番号を付しリサイズした画像を作成
        arg1: 写真画像のあるフォルダのフルパス
        return: リサイズしてID番号を付した画像
        【改訂：2024/04/19】
        pp_pic_folderをpathlibオブジェクトに変更
        """
        cpa = self.current_photo_attributes(ix)
        pp_pic_filename = cpa[1]
        
        
        '''
        #####【要改訂】pathlibに統一
        pp_pic_fullpath = os.path.join(pp_pic_folder, pp_pic_filename)
        '''
        
        pp_pic_fullpath = pp_pic_folder / pp_pic_filename
        
        ##### 2022/03/23: Pillowで読み込んだ後にEXIF により写真画像を回転
        original_image = Image.open(pp_pic_fullpath)
        my_image = self.rotate_image_using_exif(original_image)

        resized_image = self.resize_image_by_longside(my_image, 640)

        ##### 2022/03/18:
        # title_font = ImageFont.load_default()
        ##### 2022/06/26: Macではフォント名の頭を大文字にする要あり
        #     ∴インスタンス変数に保存したOS種別により処理を選択
        if 'Windows' in self.iv_platform_system_result:
            ##### 2022/06/30: フォントが見つからないエラーの回避
            try:
                title_font = ImageFont.truetype("arial.ttf", 40)
            except:
                title_font = ImageFont.load_default()
        elif 'Darwin' in self.iv_platform_system_result:
            ##### 2022/06/30: フォントが見つからないエラーの回避
            try:
                title_font = ImageFont.truetype("Arial.ttf", 40)
            except:
                title_font = ImageFont.load_default()
        else:
            print('【KgmQpData：要注意】システムが特定できません！')


        image_editable = ImageDraw.Draw(resized_image)

        ##### 2022/03/18:
        # image_editable.text((20,20), str(ix), (0, 0, 0), title_font, None, None,"center")
        image_editable.rectangle([(0, 0), (70, 70)], (255, 255, 255), (0, 0, 0), 3)
        image_editable.text((35,35), str(ix), fill="black", anchor="mm", font=title_font)

        return  resized_image

    def rotate_image_using_exif(self,
                                image_original: object) -> object:
        """
        画像をEXIF情報（もしあれば）にしたがって回転
        aug1:  original image
        return: rotated image
        """

        exif_table = self.kgm_exif_inst.get_exif_of_image2(image_original)
        exif_orientation_code = exif_table.get("Orientation")

        if (exif_orientation_code == 1):
            degree = 0
        elif (exif_orientation_code == 3):
            degree = 180
        elif (exif_orientation_code == 6):
            degree = 270
        elif (exif_orientation_code == 8):
            degree = 90
        else:
            degree = 0

        # original_image = Image.open(pic_fullpath)
        rotated_image = image_original.rotate(degree, expand = 1)

        return rotated_image

    def resize_image_by_longside(self,
                               image_original: object,
                               longside_pixel: int) -> object:
        """
        画像の長辺のピクセル数を指定してリサイズ
        aug1: original image
        aug2: longside size (in pixels)
        return: resized image
        """
        size_width = image_original.width
        size_height = image_original.height

        if size_width >= size_height:
            resized_width = longside_pixel
            resized_height = int(longside_pixel*size_height/size_width)
        else:
            resized_width = int(longside_pixel*size_width/size_height)
            resized_height = longside_pixel

        resized_image =  image_original.resize((resized_width, resized_height))

        return resized_image

    

    def current_photo_attributes(self, ix: int) -> list:
        """ 表示中のphotopointの属性リストを返す """
        pp_attrlist = self._kgm_qp_mapio.sp_feature_attributes(ix)
        return pp_attrlist
    
    
    
    def photopoint_to_be_shown_update(self):
        """
        【2022/02/15】地図上のphotopointクリックによる表示の更新
        （当座）メイン窓のshow_kgm_pic_attrで実施
        （当座）メイン窓の写真ID番号表示欄（lineEdit）の更新で
                拡大窓にも反映
        　☆事前にself.current_photo_indexを更新しておく！
        """

        cpa = self.current_photo_attributes(self.current_photo_index)
        self._current_mainwindow.show_kgm_pic_attr(cpa)

        ##### 2022/03/04:【要修正】ここで直接lineEdit_PicIDに書き込む是非
        self._current_mainwindow.lineEdit_PicID.setText(
                                           str(self.current_photo_index)
                                           )
        self.kgm_pp_inst.zoom_to_selected_point()
        self.kgm_snd_inst.play_sound(self.current_photo_index)


    def show_data_by_hittext(self, pic_ix: int, cue_milisec: int) -> None:
        """
        【2023/03/05】文字列検索結果から写真・地図・音声を更新

        """
        self.current_photo_index = pic_ix
        cpa = self.current_photo_attributes(pic_ix)
        self._current_mainwindow.show_kgm_pic_attr(cpa)
        self.kgm_pp_inst.zoom_to_selected_point()

        ##### 2023/03/07: 音声をSRTのstart時刻から再生するよう変更
        # self.kgm_snd_inst.play_sound(self.current_photo_index)
        self.kgm_snd_inst.play_sound_from_cue_milisec(cue_milisec)





    def get_kgmindex_string(self, kgmqp_folderpath: object) -> str:
        """
        【2024/03/27】
        KGMデータフォルダ内にKGMindex.txtがあれば、その文字列を返す。
        なければ、Noneを返す。
        """
        
        kgmindex_path = kgmqp_folderpath / Path('KGMindex.txt')
        
        ##### KGMindex.txtのオープンを試み、
        #     成功ならその文字列を返す。
        #     エラーならNoneを返す。
        try:
            
            #####【要検討：2024/03/27】encodingの扱い？
            
            
            ##### 2022/10/05: encodingを「utf-8」に訂正
            ##### 【訂正：2024/08/16】KGM-a（v.1.01から？）ではutf-8になった？
            kgmindex_txtfile = open(kgmindex_path,
                                    'r',
                                    encoding='utf-8')
            
            
            '''
            ##### 2022/10/05: encodingを「shift-jis」に訂正
            kgmindex_txtfile = open(kgmindex_path,
                                    'r',
                                    encoding='shift-jis')
            '''
        
        except:
            
            kgmindex_csv_string = None
            
        else:
            if self._debug_mode == 'Y':
                 print('【prepare_datasets】KGMindex.txtへのパス = '\
                  '{}'.format(kgmindex_path))
            
            kgmindex_csv_string = kgmindex_txtfile.readline()
            
        if self._debug_mode == 'Y':
            print('KGMindex.txtの内容 = '\
                  '{}'.format(kgmindex_csv_string))
        
        return kgmindex_csv_string
    
    
    def parse_kgmindex_fields(self, kgmindex_string: str) -> list:
        """
        【2024/08/16】スマホ版多言語対応可に伴い、KGMindex.txtの汎用化
        のため、各フィールドを型変換してリストで返す関数を新規作成。
        """
        
        list_kgmindex_fields = [None] * 5
        
        csvreader = csv.reader(StringIO(kgmindex_string.strip()))
        for row in csvreader:
            print(row)
        ### list_kgmindex_fields = row
        
        
        kix_startdtstr = row[0]
        kix_enddtstr = row[1]
        
        '''
        kix_routetitle = row[2]
        '''
        
        try:
            kix_ostype = row[3]
        except:
            kix_ostype = ''     # iPhone版はrow[3]なし（2024/08/17現在）
        else:
            pass
        
        
        try:
            kgmix_locale_info = row[4]
        except:
            kgmix_locale_info = 'ja_JP.UTF-8'   #第5フィールドなし
        else:
            pass
        
        if(kgmix_locale_info == 'en_US.UTF-8'):
            kix_startdatetime = self.convert_kix_dt_to_datetime_of_enus(kix_startdtstr)
            kix_enddatetime = self.convert_kix_dt_to_datetime_of_enus(kix_enddtstr)
            
        elif(kgmix_locale_info == 'ja_JP.UTF-8'):
            kix_startdatetime = self.convert_kix_dt_to_datetime_of_jajp(kix_startdtstr)
            kix_enddatetime = self.convert_kix_dt_to_datetime_of_jajp(kix_enddtstr)
            
        else:
            print("【要確認】サポートされていないロケールです！")
        
        
        list_kgmindex_fields[0] = kix_startdatetime
        list_kgmindex_fields[1] = kix_enddatetime
        list_kgmindex_fields[2] = row[2]
        list_kgmindex_fields[3] = kix_ostype
        list_kgmindex_fields[4] = kgmix_locale_info
        
        return list_kgmindex_fields
    
    
    
    def convert_kix_dt_to_datetime_of_enus(self, kix_dtstr: str) -> datetime:
        """
        2024/08/16: KGMindex.txtの日付時刻情報をdatetimeに変換
        【en_US.UTF-8用】
        """
        
        kix_month = int(kix_dtstr[0:2])
        kix_day = int(kix_dtstr[3:5])
        kix_year = int(kix_dtstr[6:10])
        kix_hour = int(kix_dtstr[11:13])
        kix_minute = int(kix_dtstr[14:16])
        kix_second = int(kix_dtstr[17:19])
        
        kix_datetime = datetime.datetime(
            year = kix_year,
            month = kix_month,
            day = kix_day,
            hour = kix_hour,
            minute = kix_minute,
            second = kix_second,
            microsecond = 0,
            tzinfo = datetime.timezone.utc)
        
        return kix_datetime
    
    
    def convert_kix_dt_to_datetime_of_jajp(self, kix_dtstr: str) -> datetime:
        """
        2024/08/16: KGMindex.txtの日付時刻情報をdatetimeに変換
        【ja_JP.UTF-8用】
        """
        
        kix_year = int(kix_dtstr[0:4])
        kix_month = int(kix_dtstr[5:7])
        kix_day = int(kix_dtstr[8:10])
        kix_hour = int(kix_dtstr[11:13])
        kix_minute = int(kix_dtstr[14:16])
        kix_second = int(kix_dtstr[17:19])
        
        kix_datetime = datetime.datetime(
            year = kix_year,
            month = kix_month,
            day = kix_day,
            hour = kix_hour,
            minute = kix_minute,
            second = kix_second,
            microsecond = 0,
            tzinfo = datetime.timezone.utc)
        
        return kix_datetime
    
    
    def zzz_get_kgmindex_startdt(self, kgmindex_string: str) -> datetime:
        """
        【改訂：2024/08/16】スマホ版多言語対応可に伴い、この関数は廃止。
        【2023/11/07】KGMindexから記録開始日時（UTC）を抽出し、
        datetime（aware）オブジェクトとして返す
        """
        
        ##### Android版：iOS版の違いに対処
        kgmindex_stripped = kgmindex_string.strip('"')
        
        
        ##### 録音開始日時を「YYYY/MM/DD hh:mm:ss」から切り出す
        #     部分文字列のインデクスは、終了文字「の次」まで！
        kix_year = int(kgmindex_stripped[0:4])
        kix_month = int(kgmindex_stripped[5:7])
        kix_day = int(kgmindex_stripped[8:10])
        kix_hour = int(kgmindex_stripped[11:13])
        kix_minute = int(kgmindex_stripped[14:16])
        kix_second = int(kgmindex_stripped[17:19])
        
        
        kix_startdt = datetime.datetime(
            year = kix_year,
            month = kix_month,
            day = kix_day,
            hour = kix_hour,
            minute = kix_minute,
            second = kix_second,
            microsecond = 0,
            tzinfo = datetime.timezone.utc)
        
        return kix_startdt


class KgmQpTracklog:
    """
    KGMのトラックログ処理クラス
    【2024/02/26】実質的処理はKgmQpQgisIoに丸投げ
    かつ、パスは文字列を廃しpathlibに変更
    【要検討：2024/02/26】実はこのクラス自体不要になるかも？
    """

    def __init__(self, coredata:object, mapio: object):
        """
        コンストラクタ：

        """

        self._kgm_qp_coredata = coredata
        self._kgm_qp_mapio = mapio     # KgmQpQgisIoのインスタンスへの参照


    def amiok(self):
        print('【KgmQpTracklog】KgmQpQgisIoのインスタンス参照は、'\
              '{} です。'.format(self._kgm_qp_mapio))
    
    
    
    def set_kgmqp_tlglayer(self, kgm_tlglyr_name: str) -> str:
        """
        KgmQpTracklogレイヤを作成・設定してレイヤ名を返す
        【2024/02/26】全面改訂：この処理はKgmQpQgisIoに丸投げ
        　'tracklog'・'trackpoints'両レイヤを一括作成・設定し、
        　両レイヤのレイヤ名の共通部分を文字列として返す。
        　（趣旨：'tracklog'と'trackpoints'がQGIS上では別レイヤであることを
        　　KgmQpDataから隠す）
        """
        
        tlglayer_common_name = self._kgm_qp_mapio.set_tptlg_layer(kgm_tlglyr_name)
        
        
        return tlglayer_common_name



class KgmQpPhotopoints:
    """ KGMの写真画像＋メモ文字列処理クラス """

    def __init__(self, coredata: object, mapio: object, exifio: object):
        """
        コンストラクタ：
        【2023/03/05】KgmQpExifのインスタンスへの参照を追加

        """

        self._kgm_qp_coredata = coredata
        self._kgm_qp_mapio = mapio     # KgmQpQgisIoのインスタンスへの参照

        ##### 2023/03/05: KgmQpExifのインスタンスへの参照を追加
        self._kgm_qp_exifio = exifio

    def amiok(self):
        
        '''
        print('【KgmQpPhotopoints】KGMデータのあるフォルダへのパスは、'\
              '{} です。'.format(self._kgm_qp_coredata.kgmqp_folderpath))
        '''
        
        return


    def set_kgmqp_ppsource_path(self) -> str:
        """ KgmQpPhotopointsソースへのパスをセット """
        str_glob_target = os.path.join(self._kgm_qp_coredata.kgmqp_folderpath,
                                       '*.shp')
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmQpPhotopoints】str_glob_targetの値は、'\
                  '{}です。'.format(str_glob_target))

        try:
            list_shpfile_fullpath = glob.glob(str_glob_target)
            if self._kgm_qp_coredata._debug_mode == 'Y':
                print('【KgmQpPhotopoints】list_shpfile_fullpathの値は、'\
                      '{}です。'.format(list_shpfile_fullpath))
        except:
            ##### 2022/02/24: globはtargetが見つからないと[]を返す
            #                 ie.エラーにはならない
            # pass

            QMessageBox.information(None,
                "【注意：要調査】",
                "globのtargetが見つからない",
                QMessageBox.Yes)

        else:

            ##### 2022/10/05: 空リスト判定法を訂正
            # if not list_shpfile_fullpath:
            # if len(list_shpfile_fullpath) < 1:
            if not list_shpfile_fullpath:

                list_pics = self._kgm_qp_coredata.kgmqp_list_jpgpics

                if self._kgm_qp_coredata._debug_mode == 'Y':
                    print('【確認用】抽出した写真のリストは、{} です。'.format(list_pics))

                ##### 2022/10/05: 写真がない・あってもEXIF情報がない場合
                if not list_pics:
                    QMessageBox.information(None,
                        "【注意：要調査】",
                        "写真画像のファイルがありません！",
                        QMessageBox.Yes)
                    ppsource_path = ''
                    ##### return ppsource_path

                else:
                    ##### 2022/10/06: とりあえずリスト中の[0]番写真で判定

                    if self._kgm_qp_coredata._debug_mode == 'Y':
                        print('【確認用】リスト[0]の写真は、{} です。'.format(list_pics[0]))

                    pic_fullpath = os.path.join(self._kgm_qp_coredata.kgmqp_folderpath, list_pics[0])

                    if self._kgm_qp_coredata._debug_mode == 'Y':
                        print('【確認用】リスト[0]の写真のフルパスは、{} です。'.format(pic_fullpath))

                    list_exif = self._kgm_qp_coredata.kgm_exif_inst.get_exif_of_image(pic_fullpath)

                    if self._kgm_qp_coredata._debug_mode == 'Y':
                        print('【確認用】list_exifの値は、{} です。'.format(list_exif))


                    if not list_exif:
                        """ EXIF情報なし """

                        if self._kgm_qp_coredata._debug_mode == 'Y':
                            print('【確認用】「if not list_exif:」を実行中：')


                        QMessageBox.information(None,
                        "【注意：要調査】",
                        "写真の撮影時刻情報が見つかりません！",
                        QMessageBox.Yes)
                        ppsource_path = ''
                        ##### return ppsource_path

                    else:
                        """ EXIF情報あり """

                        if self._kgm_qp_coredata._debug_mode == 'Y':
                            print('【新規作成前】list_shpfile_fullpathの値が、'\
                                  '{}なので新規作成します。'.format(list_shpfile_fullpath))

                        #### 2022/02/24: shpファイル・ppレイヤを新規作成
                        layer_name = self._kgm_qp_mapio.create_point_shape_layer()
                        list_shpfile_fullpath = glob.glob(str_glob_target)
                        if self._kgm_qp_coredata._debug_mode == 'Y':
                            print('【新規作成後】list_shpfile_fullpathの値は、'\
                                  '{}です。'.format(list_shpfile_fullpath))
                        ppsource_path = list_shpfile_fullpath[0]

            elif len(list_shpfile_fullpath) > 1:
                ##### 2022/02/19: 今後、一覧から選ばせる処理を追記
                print('【KgmQpPhotopoints】shpファイルが複数あります：'\
                      '{} '.format(list_shpfile_fullpath))
            else:

                ppsource_path = list_shpfile_fullpath[0]

        finally:

            '''
            print('【KgmQpPhotopoints】shpファイルへのパスは、'\
                  '{} です。'.format(ppsource_path))
            '''

            '''
            QMessageBox.information(None,
                "【注意：要調査（本来はここに来ないはず）】",
                "list_shpfile_fullpathの要素数は、" + str(len(list_shpfile_fullpath)) + "です。",
                QMessageBox.Yes)
            '''
        
        return ppsource_path
    
    
    def get_pplyr_fields(self):

        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmQpPhotopoints】photopointのレイヤ名は、'\
                  '{}です。'.format(self._kgm_qp_coredata.pplyr_name))

        pplyr_fields = \
            self._kgm_qp_mapio.get_fields(self._kgm_qp_coredata.pplyr_name)

        return pplyr_fields
    
    
    
    def zoom_to_selected_point(self) -> None:
        """
        2021/11/15: 表示中のphotopointの地点にズーム
        【改訂：2024/03/07】
        KgmQpQgisIo内の関数を呼ぶ形に変更
        【要検討】この種の処理は本来KgmQpQgisIo内でやるべきだった
        """
        
        
        '''
        【改訂：2024/03/24】インスタンス変数は廃止。
        layer_name = self._kgm_qp_coredata.pplyr_name
        '''
        
        ix = self._kgm_qp_coredata.current_photo_index
        attrlist = self._kgm_qp_coredata.current_photo_attributes(ix)
        picid = attrlist[0]
        
        self._kgm_qp_mapio.zoom_to_selected_point_via_kgm_qgis_io(picid)
        
        return
    
    
    
    def get_memotext_of_photopoint(self, ix: int) -> str:
        """
        現在参照中のphotopointレイヤの属性テーブルを読んで、
        current_photo_attributesを更新し、
        そのフィールド[2]にあるテキストを返す
        """

        attrlist = self._kgm_qp_mapio.sp_feature_attributes(ix)
        txt = attrlist[2]              # メモテキストはフィールド[2]
        return txt

    def set_memotext_of_photopoint(self, ix: int,  txt: str) -> None:
        """
        引数のテキストを、photopointの、引数ixのフィーチャの、
        属性テーブル（の該当フィールド）に書き込む

        """
        self._kgm_qp_mapio.set_photopoint_memotext(ix, txt)

        return


    def set_exiftime_ppix_list(self, ppsource_path: str) -> list:
        ##### 2024/02/20: 【暫定：引数を変更】def set_exiftime_ppix_list(self) -> list:
        """
        【2023/03/05】
        【変更前】EXIF時刻・写真番号リストを作成・保存
        【変更後】写真のEXIF時刻のみの１次元配列に変更
        その際、EXIR時刻を文字列からdatetimeに変換
        【2024/02/20】
        【暫定】引数にppsource_pathを追加
        """
        
        
        ##### 2024/02/20: shpファイルが既存のときエラーになる現象の原因調査
        print("「set_exiftime_ppix_list」に入った")
        
        str_xtp_list = self._kgm_qp_mapio.create_xtime_ppix_list()
        
        
        xtime_ppix_list = []
        # datetime_xtp = []

        for ix, str_xtp in enumerate(str_xtp_list):

            # converted_xtp = self._kgm_qp_exifio.conv_exifdt_string_to_datetime(str_xtp[1])
            # datetime_xtp =[str_xtp[0], converted_xtp]
            # datetime_xtp =[str_xtp[0], converted_xtp]
            converted_xtp = self._kgm_qp_exifio.conv_exifdt_string_to_datetime(str_xtp)

            datetime_xtp = converted_xtp        # これだけの１次元配列に変更


            if self._kgm_qp_coredata._debug_mode == 'Y':
                print('【set_exiftime_ppix_list】datetime_xtpの値は、'\
                      '{}です。'.format(datetime_xtp))

            xtime_ppix_list.append(datetime_xtp)

        '''
        xtime_ppix_list = self._kgm_qp_mapio.create_xtime_ppix_list()
        '''

        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【set_exiftime_ppix_list】xtime_ppix_listの値は、'\
                  '{}です。'.format(xtime_ppix_list))
        
        return xtime_ppix_list



class KgmQpExif:
    """ 寫眞のEXIF情報を処理するクラス"""
    def __init__(self, coredata: object):
        """
        コンストラクタ
        """
        self._kgm_qp_coredata = coredata


    def get_exif_of_image(self, jpgpic_path: str) -> list:
        """
        写真のEXIF情報をテーブルとして取得
        Get ESIF of an image if exists.
        指定した画像のEXIFデータを取り出す関数
        @return exif table Exif --- データを格納した辞書
        """
        ##### 2022/10/05: そもそも写真ファイルが開けない場合に対処
        #                 im = Image.open(jpgpic_path)
        try:
            im = Image.open(jpgpic_path)
        except:
            
            print('【get_exif_of_image：写真画像ファイルを開くことができません！】jpgpic_pathの値は：{}'.format(jpgpic_path))
            
            QMessageBox.information(None,
                    "【注意：要調査】",
                    "写真画像ファイルを開くことができません！",
                    QMessageBox.Yes)
            return {}

        # Exifデータを取得
        # 存在しなければそのまま終了、空の辞書を返す。
        try:
            exif = im._getexif()
        except AttributeError:

            ##### 2022/10/05：EXIF情報の異常を通知
            
            print('【get_exif_of_image：写真の撮影時刻の情報が見つかりません！】jpgpic_pathの値は：{}'.format(jpgpic_path))
            
            QMessageBox.information(None,
                    "【注意：要調査】",
                    "写真の撮影時刻の情報が見つかりません！",
                    QMessageBox.Yes)

            return {}

        # タグIDそのままでは人が読めないのででコードして
        # テーブルに格納する。
        exif_table = {}
        for tag_id, value in exif.items():
            tag = TAGS.get(tag_id, tag_id)
            exif_table[tag] = value

        return exif_table

    def get_exif_of_image2(self, image_original: object) -> list:
        """
        2022/03/23:
        pillowで読み込んだ写真画像のEXIF情報をテーブルとして取得
        Get ESIF of an image if exists.
        指定した画像のEXIFデータを取り出す関数
        @return exif table Exif --- データを格納した辞書
        """
        # im = Image.open(jpgpic_path)

        # Exifデータを取得
        # 存在しなければそのまま終了、空の辞書を返す。
        try:
            exif = image_original._getexif()
        except AttributeError:
            return {}

        # タグIDそのままでは人が読めないのででコードして
        # テーブルに格納する。
        exif_table = {}
        for tag_id, value in exif.items():
            tag = TAGS.get(tag_id, tag_id)
            exif_table[tag] = value

        return exif_table


    def get_datetime_of_image(self, jpgpic_path: str) -> str:
        """ 取得したEXIfテーブルから撮影日時を取り出す
            Get date-time of an image if exists
            指定した画像のEXIFデータのうち撮影日時データを取り出す
            @return yyyy:mm:dd HH:MM:SS 形式の文字列
            """

        # get_esif_of_imageの戻り値のうち
        # 日付時刻データのみを取得して返す
        exif_table = self.get_exif_of_image(jpgpic_path)
        datetime_original = exif_table.get("DateTimeOriginal")
        return datetime_original



    def conv_exifdt_to_gpxdt_aware(self, \
                        str_exifdt: str, \
                        ) -> datetime:
        """
        【2023/11/07】
        EXIFのDateTimeをGPXのDateTime(UTC)に変換
        直接datetime（aware）オブジェクトとして返す
        【改訂取りやめ：2024/03/27】
        インスタンス変数参照回避のため引数にexif_timeoffsetを追加しようと
        考えたが、self._kgm_qp_coredata.exif_timeoffsetの参照があまりにも
        多数あるため、これの廃止は無理と判断。
        """
        
        #####【改訂取りやめ：2024/03/27】インスタンス変数参照を使用。
        # gpxdt_naive = xdt_naive - exif_timeoffset
        
        #####【2024/03/27】インスタンス変数の現在値をモニタ
        print('【conv_exifdt_to_gpxdt_aware】現時点のself._kgm_qp_coredata.exif_timeoffsetの値は' \
              '{}です。'.format(self._kgm_qp_coredata.exif_timeoffset))
        
        xdt_naive = self.conv_exifdt_string_to_datetime(str_exifdt)
        gpxdt_naive = xdt_naive - self._kgm_qp_coredata.exif_timeoffset
        
        gpxdt_aware = gpxdt_naive.replace(tzinfo = datetime.timezone.utc)
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【conv_exifdt_to_gpxdt_aware】gpxdt_awareの値は、'\
                  '{}です。'.format(gpxdt_aware))
        
        return gpxdt_aware


    def conv_exifdt_string_to_datetime(self, str_exifdt: str) -> datetime:
        """
        【2023/03/05】
        kgmpic_layerから取ったEXIF時刻（＝文字列）をdatetimeに変換
        """

        # 2023/11/07: xdt = datetime.strptime(str_exifdt, '%Y:%m:%d %H:%M:%S')
        xdt = datetime.datetime.strptime(str_exifdt, '%Y:%m:%d %H:%M:%S')

        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【conv_exifdt_string_to_datetime】xdtの値は、'\
                  '{}です。'.format(xdt))

        return xdt
    
    
    
    def get_exifdt_1st(self, kgmqp_folderpath: object, list_jpgpics: list) -> datetime:
        """
        【2023/11/07】jpg写真のリストからEXIF日時のもっとも早いもの
        を選び、そのEXIF日時をdatetime（naive）オブジェクトとして返す
        """
        
        print('【get_exifdt_1st】list_jpgpicsの値は、'\
          '{} です。'.format(list_jpgpics))
        
        
        list_exifdts = []
        
        for pic in list_jpgpics:
            
            
            ##### 2024/03/10: pathlibによる記述に統一
            # pic_path = os.path.join(kgmqp_folderpath, pic)
            
            pic_path = kgmqp_folderpath / Path(pic)
            if self._kgm_qp_coredata._debug_mode == 'Y':
                print('【get_exifdt_1st】pic_pathの値は、'\
                  '{} です。'.format(pic_path))
            str_exifdt = self.get_datetime_of_image(pic_path)
            xdt = self.conv_exifdt_string_to_datetime(str_exifdt)
            list_exifdts.append(xdt)
        
        list_exifdts_sorted = sorted(list_exifdts)
        exifdt_1st = list_exifdts_sorted[0]
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【get_exifdt_1st】exifdt_1stの値は、'\
                '{} です。'.format(exifdt_1st))
        
        return exifdt_1st
    
    
    
    
    def calculate_time_offset_of_exif_datetime(self, \
                                kix_startdt: datetime, \
                                exifdt_1st: datetime \
                                ) -> datetime:
        """
        【2024/03/27】
        写真のEXIFに記録された撮影日時とUTC日時との時差を計算し、
        timedelta形式で返す。
        KGMindex.txtの記録開始日時（UTC）と最初の写真のEXIF日時の比較による。
        """
        
        
        # exifdt_1stはnaiveなので、naiveどうしで演算する要あり
        kgmindex_startdt_naive = kix_startdt.replace(tzinfo=None)
        
        
        exif_timeoffset_real = exifdt_1st - kgmindex_startdt_naive
        
        # 単純減算だと端数が出るのでtimedeltaで割り算
        int_exif_timeoffset = round( exif_timeoffset_real / timedelta (hours=1) )
        
        # この割り算の結果はint型になるので、それを再度timedeltaに変換
        timedelta_exif_timeoffset = timedelta(hours = int_exif_timeoffset)
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('self.exif_timeoffsetの値 = '\
                  '{}'.format(timedelta_exif_timeoffset))
        
        return timedelta_exif_timeoffset
    
    
    
class KgmQpSound:
    """ KGMの音声データ処理クラス """

    def __init__(self, coredata: object):
        """
        コンストラクタ：

        """

        self._kgm_qp_coredata = coredata

        ##### 2022'04/24: これを入れるとデータ切り替え時に前の音声が止まらず残るが
        #                 入れないと「playerがない」エラーになる・・・
        self.player = QMediaPlayer()

        ### 2022/05/12: null_contentをインスタンス変数として定義
        self.null_content = QtMultimedia.QMediaContent()
        
        
        # 音声データの伸縮を調整するの係数をインスタンス変数に保持
        # （2021/03/22）
        # self.adjust_coeff = 0.885
        self.adjust_coeff = 1.000   # KGM-i用に1.000に戻した (2021/05/29)

        # 音声を「進める」「戻す」ボタンの秒数をインスタンス変数に保持
        self.foward_backward_seconds = 3

        # 撮影時刻までの（調整後）経過時間もインスタンス変数に保持
        # （2021/03/25）
        self.sound_elapsed_milisec_adjusted = 0


    def amiok(self):
        print('【KgmQpSound】KGMデータのあるフォルダへのパスは、'\
        '{} です。'.format(self._kgm_qp_coredata.kgmqp_folderpath))
    
    
    
    def prepare_sound_data(self) -> None:
        """
        【改訂：2024/03/21】
        QtMultimedia.QMediaPlayerで再生する音声ファイルを準備
        KGMデータフォルダへのパスは、KGMデータセット辞書から、
        pathlibオブジェクトとして取得
        これを含め、パス関係処理をpathlib使用に統一
        """
        
        active_kgm_data_path = \
            self._kgm_qp_coredata.get_fullpath_to_active_kgm_data_folder() 
        
        
        kgm_sound_filename = \
            self.get_sound_filename(active_kgm_data_path)
        
        ##### 2022/04/24: ここで実施
        # self.player = self.set_player()
        self.set_player()
        
        snd_content = self.get_sound_content( \
                        active_kgm_data_path, \
                        kgm_sound_filename \
                        )
        self.player.setMedia(snd_content)
        
        
        ##### 2023/02/21: QMesiaPlayerから１秒ごとにpositionを通知
        #                 そのシグナルで表示を更新
        self.player.setNotifyInterval(1000)
        self.player.positionChanged.connect(self.update_sound_position)
        ##### 2023/02/21: ↑ここまで
        
        
        '''
        【2023/11/08】get_start_datetime_of_soundによる処理を全面廃止
                      kgmindex_startdtによる処理に統一
        '''
        
        ##### 2023/11/07:【暫定】ss_datetimeは一応残す
        #                 将来のablieda端末使用の場合に備え？
        self._kgm_qp_coredata.ss_datetime = self._kgm_qp_coredata.kgmindex_startdt
        
        return
    
    
    
    def get_sound_filename(self, kgmqp_folder_path: object) -> str:
        """
        【wav・mp3形式に対応】KGMの音声ファイルのファイル名を返す。
        【改訂：2024/03/21】
        音声ファイルの検索は共通glob関数で実施。
        インスタンス変数は廃止し、都度引数で渡すよう統一。
        """
        
        root_criteria = ''
        ext_criteria = '(WAV|wav|MP3|mp3)'
        list_sound_files = \
            self._kgm_qp_coredata.get_list_of_files_using_glob( \
                                            kgmqp_folder_path, \
                                            root_criteria, \
                                            ext_criteria \
                                            )
            
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【get_sound_filename】list_sound_filesの値は、'\
            '{}です。'.format(list_sound_files))
        
        str_sound_filename = list_sound_files[0]
            # 当面サウンドファイルは１つと前提
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【get_sound_filename】str_sound_filename = '\
                  '{}'.format(str_sound_filename))
        
        return str_sound_filename
    
    
    def get_sound_content(self, \
                          kgmqp_folder_path: object, \
                          str_sound_filename: str \
                          ) -> object:
        """
        KGMの音声ファイルをQtMultimedia.QMediaPlayerで開く（2021/03/21）
        【改訂：2024/03/21】
        引数mqp_folder_pathをpathlibオブジェクトに変更。
        文字列str_sound_filenameを引数に追加。
        """
        
        
        str_sound_filepath = str(kgmqp_folder_path / Path(str_sound_filename))
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print("str_sound_filepath = ", str_sound_filepath)

        s_media = QtCore.QUrl.fromLocalFile(str_sound_filepath)
        # s_content = qgis.PyQt5.QtMultimedia.QMediaContent(s_media)
        s_content = QtMultimedia.QMediaContent(s_media)
        # self.sound_media = s_media
        # self.sound_content = s_content

        return(s_content)
    
    
    
    def get_elapsed_time_in_milisec(self, \
                            str_exifdt: str \
                            ):
        """
        写真のEXIFのDateTimeから音声の経過時間（ミリ秒）を産出（2021/03/21）
        追ってExifDateTimeからQDateTimeにする部分は独立の関数にしたい
        【2023/11/07】QDateTimeの使用自体を廃止、Python標準datetimeに統一
        【改訂取りやめ：2024/03/27】
        conv_exifdt_to_gpxdt_awareの改訂に伴い引数にexif_timeoffsetを追加
        しようと思ったが、あまりに使用頻度が高いため断念。
        """
        exif_year = int(str_exifdt[0:4])
        exif_month = int(str_exifdt[5:7])
        exif_day = int(str_exifdt[8:10])
        exif_hour = int(str_exifdt[11:13])
        exif_minute = int(str_exifdt[14:16])
        exif_second = int(str_exifdt[17:19])
    
    
        '''
        【2023/11/08】QDateTimeによる処理を全面廃止
                      Python標準datetimeによる処理に統一
        '''
        
        exifdt_utc_aware = \
            self._kgm_qp_coredata.kgm_exif_inst.conv_exifdt_to_gpxdt_aware( \
                                                            str_exifdt \
                                                            )
            
        timedelta_elapsed = exifdt_utc_aware - self._kgm_qp_coredata.kgmindex_startdt
        dt_elapsed_ms = timedelta_elapsed.seconds * 1000
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【get_elapsed_time_in_milisec】exifdt_utc_awareの値は、'\
                  '{}です。'.format(exifdt_utc_aware))
            print('【get_elapsed_time_in_milisec】timedelta_elapsedの値は、'\
                  '{}です。'.format(timedelta_elapsed))
            print('【get_elapsed_time_in_milisec】dt_elapsed_msの値は、'\
                  '{}です。'.format(dt_elapsed_ms))
        
        
        return dt_elapsed_ms

    def play_sound(self, ix: int):
        """
        音声を頭出しして再生
        【改訂取りやめ：2024/03/27】
        インスタンス変数参照回避のため、引数にexif_timeoffsetを追加
        しようと思ったが、あまりに使用頻度が高いため断念。
        
        """
        
        print('【play_sound】現時点のself._kgm_qp_coredata.exif_timeoffsetの値は' \
              '{}です。'.format(self._kgm_qp_coredata.exif_timeoffset))
        
        # 【要検討】写真画像のインデクスはKgmQpDataのインスタンス変数から取得
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmQpSound：play_sound】self._kgm_qp_coredata.current_photo_index'\
                  'の値は、{} です。'\
                  .format(self._kgm_qp_coredata.current_photo_index))

        attrlist = self._kgm_qp_coredata.current_photo_attributes(ix)
        str_exif_datetime = attrlist[3]    # フィールド[3]が撮影時刻

        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmQpSound：play_sound】KgmQpPhotopointsでshapefileから取得した'\
                  'EXIF時刻は、'\
                  '{} です。'.format(str_exif_datetime))

        # 調整係数を掛ける（2021/03/22）
        #####【改訂取りやめ：2024/03/27】exif_timeoffsetを引数に追加は断念。
        sound_cue_milisec = \
            self.get_elapsed_time_in_milisec( \
                            str_exif_datetime \
                            )
        adjusted_float = sound_cue_milisec * self.adjust_coeff
        adjusted_cue_milisec = int(adjusted_float)

        ### 録音開始時刻、Exif時刻、経過時間をログに書き出す（2021/03/22）
        
        
        ##### 2023/11/08: self._kgm_qp_coredata.kgmindex_startdtに統一
        # str_start_time = self.sound_start_datetime.toString('hh:mm:ss')
        str_start_time = datetime.datetime.strftime(self._kgm_qp_coredata.kgmindex_startdt, '%H:%M:%S')
        
        
        str_pic_filename = attrlist[2]     # フィールド[2]が写真ファイル名
        str_exif_time = str_exif_datetime[10:19]
        str_adjust_coeff = str(self.adjust_coeff)
        str_cue_milisec = str(adjusted_cue_milisec)

        print('【録音開始】' + str_start_time + '； ' + \
              '【写真：' + str_pic_filename + \
              'のExif時刻】' + str_exif_time + '； ' + \
              '【調整係数】' + str_adjust_coeff + '； ' + \
              '【経過ミリ秒】' + str_cue_milisec)


        # 調整後経過時間をインスタンス変数に保持
        # （2021/03/25：後日用見直し？）
        self.sound_elapsed_milisec_adjusted = adjusted_cue_milisec

        ##### 2023/02/26: SRTデータ表示用に調整後経過時間をKgmQpDataにも保持
        #####【暫定：2024/05/03】SRT関係処理を一時的に停止
        #####【暫定：2024/05/20】センター支援費報告書作成用にSRTを再開
        self._kgm_qp_coredata.sound_elapsed_milisec_adjusted_for_srt = adjusted_cue_milisec

        # 頭出しして再生
        self.player.setPosition(adjusted_cue_milisec)
        self.player.play()


    def play_sound_from_cue_milisec(self, cue: int):
        """
        【2023/03/07】音声を頭出しして再生
        SRTのstartから得た経過時間（milisecond）で再生位置を指定
        """


        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【play_sound_from_cue_milisec】cueの値は'\
                  '{} です。'.format(cue))


        # 頭出しして再生
        self.player.stop()
        self.player.setPosition(cue)
        self.player.play()


    def discard_current_sound_data(self):
        """
        【2022/05/12】self.playerの再生対象コンテンツをNullに設定
        """
        # self.player.setMedia(QMediaContent())

        # null_content = QtMultimedia.QMediaContent()

        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【discard_current_sound_data】null_contentの値は'\
                  '{} です。'.format(self.null_content))

        self.player.setMedia(self.null_content)

    def set_player(self):
        """
        【2022/04/24】
        QMediaPlayerのインスタンス変数をセット
        【2022/05/12】
        playerをdelするのでなく、null_contentをセット
        """
        ##### 2022/04/24: 複数データ時の音声重複再生への対策
        try:
            self.player.stop()
            # del self.player   # 既存のがあれば消す
            # self.player = QMediaPlayer()
            ### 2022/05/12: 既存のがあればnull_contentをセット
            self.discard_current_sound_data()
        except:
            print('【set_player】既存のself.playerはありません。')
            self.player = QMediaPlayer()
        else:
            # del self.player   # 既存のがあれば消す
            # self.player = QMediaPlayer()
            # print('【set_player】stopしてdelしました。')
            ### 2022/05/12:
            print('【set_player】stopしてnull_contentをセットしました。')
        finally:
            # del self.player   # 既存のがあれば消す
            # self.player = QMediaPlayer()
            # print('【set_player】player = QMediaPlayer()しました。')

            ### 2022/05/12: delして再インスタンス化ではなく
            ###             コンテンツをセットし直す
            ### 【NG】ここでやるとループする？
            # self.prepare_sound_data()
            pass

        # self.player = QMediaPlayer()


        ### 2022/05/12: Pythonコンソールにも書き出す
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【set_player】set_playerの処理を行いました。')

        # return my_player

    def update_sound_position(self, position):
        """
        【2023/02/21】
        QMediaPlayerからのpositionChangedシグナルにより、
        その時点のpositionを表示
        【☆要検討】インポートしたdatetimeと変数名とが紛らわしい

        """
        
        ##### 2023/11/08: self._kgm_qp_coredata.kgmindex_startdtに統一
        # sound_current_datetime = self.sound_start_datetime.addMSecs(position)
        # str_sound_current_datetime = sound_current_datetime.toString('yyyy:MM:dd hh:mm:ss')
        #####【修正：2024/05/20】KGMindexの日時はGPS由来だからexif_timeoffsetで要補正だった。
        # sound_current_datetime = self._kgm_qp_coredata.kgmindex_startdt + timedelta(seconds=position)
        # str_sound_current_datetime = datetime.datetime.strftime(sound_current_datetime, '%Y:%m:%d %H:%M:%S')
        
        #####【2024/05/20】exif_timeoffsetによる補正は録音開始日時に対してのみ実施
        sound_start_datetime = \
            self._kgm_qp_coredata.kgmindex_startdt + \
            self._kgm_qp_coredata.exif_timeoffset
        
        #####【2024/05/20】補正ずみ録音開始日時に経過時間を加算
        #    【2024/05/20：修正】もとはQDateTimeのaddMSecsだったのでミリ秒から秒に要変換だった
        position_in_seconds = int(position / 1000)
        sound_current_datetime = \
            sound_start_datetime + \
            timedelta(seconds=position_in_seconds)
        str_sound_current_datetime = \
            datetime.datetime.strftime(sound_current_datetime, '%Y:%m:%d %H:%M:%S')
        
        
        ##### 2023/02/21: 【要検討】ここでdockwidget上のオブジェクトをいじるのはNG？
        self._kgm_qp_coredata._current_mainwindow.label_ElapsedTime.setText(
                '【再生中の音声の現在日時】＝ ' +
                str_sound_current_datetime)
