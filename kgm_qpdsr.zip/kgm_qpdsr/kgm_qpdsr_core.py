# -*- coding: utf-8 -*-
"""
#############################################################################
KgmQpData

QGISプラグイン版『聞き書きマップ』のデータアクセス処理

【基本方針】（改訂：2021/12/01）
モジュール「kgm-qp」に、QtやQGISエンジンに依存しない部分を集約:

その中心となるクラス「KgmData」に、QtやQGISエンジンから参照されるプロパティや
メソッドを置く。

上記のプロパティは、KgmDataのインスタンス変数として定義し、QtやQGISエンジン
などからは、各プロパティへのアクセッサ経由でのみ扱えるようにする。

2021/11/08-09の方法でGUI窓同士を相互参照するためのポインタ(?)も、KgmQpDataの
インスタンス変数として定義する。

メイン窓の「読み込み」でKGMデータのフォルダが指定されたとき、そのデータフォル
ダに対応するKgmQpDataのインスタンスを作る。

KGMが扱う３つのデータ（＝GPSログ、写真画像・メモ欄テキスト、音声）それぞれに
対する処理も、GUIやGISに直接関わる部分を除き、モジュール「kgm-qp」の中で、３つ
のデータそれぞれに対応するクラスとして定義する。

（Qtによる）GUIやQGISによる地図画面は、KgmQpData（のインスタンス）の内容を表示
する、言わば「ビュー」のようなものとして扱う。
として扱う。

【例外】（2021/11/13）
音声の処理に使うQtMultimediaは（例外的に）ここに含める。
∵ KgmQpDialogのメイン窓・拡大窓で共用する必要がある。

【追記】（2021/12/13）
v.3.10のQgsVectorFileWriter.createにバグがあるため、v.3.16（以降）専用とする。

#############################################################################
"""

import os


##### 2022/06/23: 冒頭でWindowsかMacintoshかを判定、各OS用の処理を実施
#                 その処理自体をここでやるのはNGらしいので、
#                 ここではそれに必要なモジュールのimportだけを行い、
#                 実際の処理はKgmQpDataの__init__中で実施
import sys
import platform
from os.path import expanduser
from coverage import data


##### from OpenGL.EGL.KHR import stream


platform_system_result = platform.system()
print(platform_system_result)

path_to_user_home = expanduser("~")
print(path_to_user_home)

if 'Darwin' in platform_system_result:
    
    print('【KgmQpData】このコンピュータで稼働中のシステムは、' \
              '{} です。'.format(platform_system_result))
    
    ##### 2022/06/26: アップデートしたpillowへのパスを設定
    path_to_sitepackages = os.path.join(
        path_to_user_home,
        'library',
        'Python',
        '3.8',
        'lib',
        'python',
        'site-packages')
    print (path_to_sitepackages)
    
    sys.path.insert(0, path_to_sitepackages)
    
    '''
    ##### 2022/06/30: zshによるインストールは結局ギブアップ
    #     pipを使ったモジュールのインストールは手動でやることとし、
    #     その手順書を作った：
    #     「【Win・Mac】simplekmlをpipでインストールする手順_asof_20220630.pdf」
    ##### 2022/06/30: ここでsimplekmlインポートをtryし、
    #     エラーになったらzshでインストールする
    try:
        import simplekml
    except:
        commandline_list = []
        pass
    '''
    
elif 'Windows' in platform_system_result:
    
    print('【KgmQpData】このコンピュータで稼働中のシステムは、' \
              '{} です。'.format(platform_system_result))
    
    path_to_sitepackages = ''
    print (path_to_sitepackages)
    
else:
    print('【KgmQpData：要注意】システムが特定できません！')


##### globライブラリをインポート
import glob    # ディレクトリ内の画像ファイル一覧の取得に使用
import re      # 2021/12/03: globと組み合わせてJPGの大文字小文字問題に対処

##### 2021/12/16: 改行入り文字列リテラル使用のために必要
# https://qiita.com/tag1216/items/3447def88ed6b1d51d60
import textwrap

##### ifaceを使うために必要
#     --> see: PyGIS Developer Cookbook, 1.1
#     (2021/03/19)
from qgis.core import *
import qgis.utils
from qgis.utils import iface
from decorator import __init__

##### Pillow(PIL)ライブラリ読み込み(2021/03/07)
# Anacondaに同梱のPillowは「Python2のPILをフォークしたものらしい」とのこと
# --> see https://kapibara-sos.net/archives/658
from PIL import Image
from PIL.ExifTags import TAGS

##### 2022/03/11: 写真画像に文字を重ねるため追加
# https://www.codegrepper.com/code-examples/python/add+text+to+image+python
from PIL import ImageFont, ImageDraw

##### 2022/03/19: メッセージボックスを使うために追加
# https://webbibouroku.com/Blog/Article/qgis3-python-messagebox
from PyQt5.QtWidgets import QMessageBox

##### (2021/03/19)
#      2021/11/13: 音声再生用にQtCoreを追加
from qgis.PyQt import QtCore
from qgis.PyQt.QtCore import QDateTime
from numpy import ix_


##### 音声再生用にPyQt5.QtMultimediaを使う（2021/03/21）
#     2021/11/13: ここに移動＆
from PyQt5 import QtMultimedia
from PyQt5.QtMultimedia import QMediaPlayer
from networkx.classes.function import selfloop_edges

##### kgm_qpd_qgisioモジュールからKgmQpQgisIoクラスをインポート
#     2021/11/11：インポート対象をこれだけに限定
# from .kgm_qpd_qgisio import KgmQpQgisIo
##### 2023/02/21: kgm_qpdsr_qgisioに変更
from .kgm_qpdsr_qgisio import KgmQpQgisIo

from builtins import property
##### 2022/06/02: いつの間にか↓これが入っていてエラーになるので削除
# from OpenGL.raw.WGL._types import PLAYERPLANEDESCRIPTOR



##### 2023/02/24: SRT形式データの表示用
import srt


##### 2023/03/05: KgmQpData内でもPython標準のdatatimeを使用可にする
#     （いずれはQDateTimeでなくこっちに統一？）
##### 2023/02/26: Subtitleオブジェクトのtimedeltaの処理に必要？
#     see "Python & Qt5" p.312-314
import datetime
from datetime import datetime, timedelta


##### 2023/03/17: ProjectKikiGaki.pjのXMLを処理するため
#     xml.etree.ElementTreeを使用
#     ( -> see https://docs.python.org/ja/3/library/xml.etree.elementtree.html)
import xml.etree.ElementTree as ET




'''
##### SRT表示のテスト
with open("C:/gis_work/_namegawa/KGM20221208141347/test01.srt", mode='r', encoding="utf-8") as f: 
    subs = srt.parse(f.read()) 
    for sub in subs: 
        print(sub)
'''



class KgmQpData:
    """
    KGM-Opの各構成部分を橋渡しする基幹部分。以下のものをここで定義・管理：
    １．各構成部分から参照されるインスタンス変数（アクセッサ経由で処理）
    ２．KGM-Qpの各機能を司るメソッドを呼び出す関数「 [#文言再考?]
    """
    
    def __init__(self, mainwindow: object, folderpath: str):
        """ 
        コンストラクタ：
        メイン窓のスレッドから呼ばれるので、以下を引数とする。
        １．mainwindow: 呼び出し側のメイン窓のインスタンス
        ２．folderpath: 呼び出し時に指定された、KGMデータのフォルダへのフルパス
        """
        ##### デバッグモードのフラグをインスタンス変数として定義
        self._debug_mode = 'Y'   # 直接参照できるように隠蔽なしの名称にした
        
        
        ##### KGM-Opの中心的構成部品のインスタンスへの参照 #################
        #     自分自身（KgmQpData）への参照も含む
        #    （インスタンス化時点で参照先が未定のものの初期値は「object」）
        #    （☆「object」については、→ see 柴田2019、p,331）
        self.__my_instance = self               # 自分自身のインスタンス
        self._current_mainwindow = mainwindow  # メイン窓のインスタンス
        self._kgm_qp_mapio = object            # KgmQpQgisIoのインスタンス
        
        ### 2022/05/12: KgmQpSoundのインスタンスも定義し初期値をobjectに
        self.kgm_snd_inst = object             # KgmQpSoundのインスタンス
        self.kgm_snd_inst_exist = 'N'          # 地味に存否フラグで判定
        
        ##### ユーザには操作させないインスタンス変数
        self.__kgmqp_root_path = ''       # 本pluginを置くフォルダへのパス
        self.__kgmqp_folderpath = folderpath  # KGMデータのフォルダへのパス
        self.__kgmqp_tlgfile_path = ''    # KgmQpTracklogファイルへのパス
        self.__kgmqp_list_jpgpics = list  # KGMフォルダ内のjpg画像のリスト
        self.__kgmqp_ppsource_path = ''   # KgmQpPhotopointsソースへのパス
        self.__kgmqp_soundfile_path = ''  # 音声ファイルへのパス
        self.__kgmindex_exists = ''       # KGMindex.txtの存否を示すフラグ
        self.__kgmindex_str = ''          # KGMindex.txtの内容を保持
        
        ##### ユーザの操作などで値を変更可能なインスタンス変数
        self.__tlglyr_name = ''                # KgmQpTracklogのレイヤ名
        self.__pplyr_name = ''                 # KgmQpPhotopointsのレイヤ名
        self.__pplyr_fields = list             # 同上の属性フィールド
        self.__current_photo_index = 0         # 表示中のppのインデクス番号
        '''
        self.__current_photo_attributes = list # 表示中のppの属性リスト
        '''
        
        '''
        ##### 2023/03/01: GPXのtracksのレイヤ名を表示用に使用
        #     【要修正】これで確定ならアクセッサとして定義
        self.tracks_name = ''
        '''
        
        ##### 2023/03/02: tracks・track_points・photo_pointsを
        #     統一的に処理するために、現在アクティブな各レイヤの
        #     レイヤ名の共通部分とそのソースへのパスを保持する辞書を作成
        #     これへのアクセスを専用の関数で実施
        self.__active_kgm_layerdict = {
            'shared_layername': '',
            'gpx_source_path': '',
            'shape_source_path': ''
            }
        
        
        
        
        ##### 2023/03/05: datetime型で保存した録音開始時刻
        #     とりあえず初期値はtoday（timezone付き）に設定
        # 【要注意：これはNG？】self.__ss_datetime = datetime.today()
        self.__ss_datetime = datetime.now()
        
        ##### 2023/03/05: EXIF時刻からの写真番号検索用のリスト
        self.__exiftime_ppix_list = []
        
        
        ##### 2022/05/26: 新規KGMデータが追加されたことを示すフラグ
        self.__kgmdata_added = 'N'
        
        
        ##### 2023/02/26: SRTデータのスクロール用に経過時間も保持
        #     【要修正】これで確定ならアクセッサとして定義
        self.sound_elapsed_milisec_adjusted_for_srt = 0
        
        
        
        ##### 起動時に値が確定するインスタンス変数に値を設定
        '''
        self.__kgmqp_root_path = os.path.join(
                                 QgsApplication.qgisSettingsDirPath(),
                                 'python', 'plugins', 'kgm_qp'
                                 )
        '''
        '''
        ##### 2022/06/03: この参照先がkbm_qpのままだった！
        #                 kgm_qpdに変更（スタイルファイルもコピー）
        self.__kgmqp_root_path = os.path.join(
                                 QgsApplication.qgisSettingsDirPath(),
                                 'python', 'plugins', 'kgm_qpd'
                                 )
        '''
        
        ##### 2022/06/03: この参照先がkbm_qpdのままだった！!
        self.__kgmqp_root_path = os.path.join(
                                 QgsApplication.qgisSettingsDirPath(),
                                 'python', 'plugins', 'kgm_qpdsr'
                                 )
        
        
        
        ##### 2022/06/26: クラス定義前に判定したOSがらみの環境の情報を
        #                 グローバル変数から取得しインスタンス変数に記録
        #                 これによりgetter経由での参照に限定する
        
        # クラス定義前に定義された変数はグローバル変数として参照可
        # 参照だけならglobal宣言は不要、代入するときは必須
        # （参照：柴田 2019、p.280）
        global platform_system_result
        global path_to_user_home
        global path_to_sitepackages
        
        self.__platform_system_result = platform_system_result
        self.__path_to_user_home = path_to_user_home
        self.__path_to_sitepackages = path_to_sitepackages
        
        
        
    def amiok(self):
        """ 自分のインスタンスが正しく作られたかの確認 """
        
        ##### 2022/06/26: QGIS起動時の処理結果を確認
        '''
        # クラス定義前に定義された変数はグローバル変数として参照可
        # 参照だけならglobal宣言は不要、代入するときは必須
        # （参照：柴田 2019、p.280）
        global platform_system_result
        global path_to_user_home
        global path_to_sitepackages
        '''
        
        print('【KgmQpData: amiok】このコンピュータで稼働中のシステムは、' \
              '{} です。'.format(self.iv_platform_system_result))
        
        print('【KgmQpData: amiok】self.iv_path_to_user_homeの値は、' \
              '{} です。'.format(self.iv_path_to_user_home))
        
        print('【KgmQpData: amiok】self.iv_path_to_sitepackagesの値は、' \
              '{} です。'.format(self.iv_path_to_sitepackages))
        
        
        print('【KgmQpData: amiok】メイン窓への参照は、' \
              '{} です。'.format(self._current_mainwindow))
        print('【KgmQpData: amiok】KGMデータのあるフォルダへのパスは、' \
              '{} です。'.format(self.__kgmqp_folderpath))
        print('【KgmQpData: amiok】このpluginのあるフォルダへのパスは、'\
              '{} です。'.format(self.__kgmqp_root_path))
        
        self._current_mainwindow.textEdit.setText('Hello, '\
              'this is an instance of KgmData!')
        
        
        
        
        
        ##### 2023/03/02: tracks・track_points・photo_pointsを
        #     統一的に処理するために、現在アクティブな各レイヤの
        #     レイヤ名の共通部分とそのソースへのパスを保持する辞書
        #     ができたことを確認
        
        self.__active_kgm_layerdict.update(
            shared_layername ='レイヤ共通名',
            gpx_source_path ='dummy_gpx_path',
            shape_source_path = 'dummy_shape_path'
            )
        
        print('【KgmQpData: amiok】KGMデータのレイヤ共通名の辞書は、'\
              '{} です。'.format(list(self.__active_kgm_layerdict.items())))
        
        
        
        '''
        ##### 2023/02/25: SRT表示のテスト
        with open('D:\gis_work\_KgmQpdSR_tests\KGM20211030163840\【large】KGM20221208141347_first-10min.srt', mode='r', encoding="utf-8") as f: 
            subs = srt.parse(f.read()) 
            
            sub_temp = []
            
            for sub in subs: 
                print(sub)
                sub_temp.append([sub.index, str(sub.start), sub.content])
                
            self.subs_test01 = sub_temp
        '''
        
        
        
        
        
        ##### 2023/02/24: subsをインスタンス変数に入れてみる
        # ↓これだとエラーになる
        # self.subs_tewst01 = subs
        
        '''
        ##### 2023/02/25: 直にリストを入れたら成功
        self.subs_tewst01 = [
            [1,"00:00:00,000","Aフィールドワーク午後の分本番がスタートしたところで"],
            [2,"00:00:27,000","男子学生諸君はそれぞれに飯食べるところも含めてですね"],
            [3,"00:00:32,000","自分の足で見つけてくるというのを課題にしておりですね"],
            [4,"00:00:37,000","私は横着にもですね"],
            [5,"00:00:40,000","集合場所のところでお昼ご飯も食べちゃったこういう作戦です"],
            ]
        '''
        
        ##### 2023/02/25: subsからリストを作る
        # self.subs_tewst01 = list(subs)
        #            ↑誤記があった！！！
        # self.subs_test01 = list(subs)
        
        
        
        
    ##### KgmQpData内で管理するインスタンス変数のアクセッサ
    #     （柴田2019, p.320-321）
    
    # 2022/06/26: OS環境関連の情報をインスタンス変数にも記録
    @property
    def iv_platform_system_result(self) -> str:
        """
        【ReadOnly】稼働中のシステムのOS情報（platform.systemによる）
        """
        return self.__platform_system_result
    
    @property
    def iv_path_to_user_home(self) -> str:
        """
        【ReadOnly】使用中のユーザのルートフォルダへのパス
        """
        return self.__path_to_user_home
    
    @property
    def iv_path_to_sitepackages(self) -> str:
        """
        【ReadOnly】（Macintosh限定）
        （QGIS3.16以降で）PIL使用に必要となる、pillowをインストール
        したフォルダへのパス
        """
        return self.__path_to_sitepackages
    
    # 2022/06/26: ここまで
    
    
    @property
    def kgmqp_root_path(self) -> str:
        """ 
        【ReadOnly】KgmQp pluginを置くフォルダへのパス
        ここにtracklogやphotopointのスタイルファイルも置く
        """
        return self.__kgmqp_root_path
    
    @property
    def kgmqp_folderpath(self) -> str:
        """
        【2022/04/24：ReadOnlyだったのを変更】
        KGMデータのあるフォルダへのパス
        """
        return self.__kgmqp_folderpath
    
    @kgmqp_folderpath.setter
    def kgmqp_folderpath(self, name: str) -> None:
        """
        【2022/04/24: 複数データ対応のため追加】
        KGMデータのあるフォルダへのパスのsetter
        """
        self.__kgmqp_folderpath = name
    
    
    @property
    def kgmqp_tlgfile_path(self) -> str:
        """ 
        【ReadOnly】KgmQpTracklogファイルへのパス
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmqp_tlgfile_path
    
    @property
    def kgmqp_list_jpgpics(self) -> list:
        """
        【ReadOnly】KGMデータフォルダ内のjpg画像ファイルのリスト
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmqp_list_jpgpics
    
    @property
    def kgmqp_ppsource_path(self) -> str:
        """
        【ReadOnly】KgmQpPhotopointsソースへのパス
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmqp_ppsource_path
    
    @property
    def kgmqp_soundfile_path(self) -> str:
        """
        【ReadOnly】音声ファイルへのパス
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmqp_soundfile_path
    
    @property
    def kgmindex_exists(self) -> str:
        """
        【ReadOnly】KGMindex.txtの存否を示すフラグ
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmindex_exists
    
    @property
    def kgmindex_str(self):
        """
        【ReadOnly】KGMindex.txtの内容を保持
        　値のセットはprepare_datasets内でのみ実施
        """
        return self.__kgmindex_str
    
    
    @property
    def tlglyr_name(self) -> str:
        """ GPSトラックログレイヤのレイヤ名のgetter """
        return self.__tlglyr_name    
    
    @tlglyr_name.setter
    def tlglyr_name(self, name: str) -> None:
        """ GPSトラックログレイヤのレイヤ名のsetter """
        self.__tlglyr_name = name
    
    @property
    def pplyr_name(self) -> str:
        """ phoyopointレイヤのレイヤ名のgetter """
        return self.__pplyr_name    
    
    @pplyr_name.setter
    def pplyr_name(self, name: str) -> None:
        """ phoyopointレイヤのレイヤ名のsetter """
        self.__pplyr_name = name
    
    @property
    def pplyr_fields(self):
        """ photopointsレイヤの属性フィールド一覧のgetter """
        return self.__pplyr_fields
    
    @pplyr_fields.setter
    def pplyr_fields(self, flds: list) -> None:
        """ photopointsレイヤの属性フィールド一覧のsetter """
        self.__pplyr_fields = flds
    
    @property
    def current_photo_index(self) -> int:
        """ 写真画像窓に表示される写真のインデクス番号のgetter """
        return self.__current_photo_index
    
    @current_photo_index.setter
    def current_photo_index(self, ix: int) -> None:
        """ 写真画像窓に表示される写真のインデクス番号のsetter """
        self.__current_photo_index = ix
    
    @property
    def kgmdata_added(self):
        """ KGMデータが新規追加されたことを示すフラグ """
        return self.__kgmdata_added
    
    @kgmdata_added.setter
    def kgmdata_added(self, ynflag: str) -> str:
        """ KGMデータが新規追加されたことを示すフラグのsetter """
        self.__kgmdata_added = ynflag
    
    
    ##### 2023/03/02: tracks・track_points・photo_pointsを
    #     統一的に処理するために、現在アクティブな各レイヤの
    #     レイヤ名の共通部分とそのソースへのパスを保持する辞書
    #     へのアクセッサ
    
    '''
    @property
    def shared_layername(self) -> str:
        """  """
        shared_layername = self.__active_kgm_layerdict.get('shared_layername')
        return shared_layername
    
    @shared_layername.setter
    def shared_layername(self, shared_name: str) -> None:
        """  """
        self.__active_kgm_layerdict.update(shared_layername = shared_name)
    
    
    @property
    def gpx_source_path(self) -> str:
        """  """
        gpx_source_path = self.__active_kgm_layerdict.get('gpx_source_path')
        return gpx_source_path
    
    @gpx_source_path.setter
    def gpx_source_path(self, gpx_path: str) -> None:
        """  """
        self.__active_kgm_layerdict.update(gpx_source_path = gpx_path)
    
    
    @property
    def shape_source_path(self) -> str:
        """  """
        shape_source_path = self.__active_kgm_layerdict.get('shape_source_path')
        return shape_source_path
    
    @shape_source_path.setter
    def shape_source_path(self, shp_path: str) -> None:
        """  """
        self.__active_kgm_layerdict.update(shape_source_path = shp_path)
    '''
    
    @property
    def active_kgm_layerdict(self) -> dict:
        """  """
        return self.__active_kgm_layerdict
    
    @active_kgm_layerdict.setter
    def active_kgm_layerdict(self, kgm_layerdict: dict):
        """  """
        self.__active_kgm_layerdict = kgm_layerdict.copy()
    
    
    ##### 2023/03/05: 文字列検索でのKGM表示更新用の変数を追加
    # 【変更】当初はEXIF時刻・写真番号の２次元配列のつもりだったが、
    #         厄介だったのでEXIF時刻のみの１次元配列に変更
    @property
    def exiftime_ppix_list(self) -> list:
        """ EXIF時刻リストのgetter """
        return self.__exiftime_ppix_list
    
    @exiftime_ppix_list.setter
    def exiftime_ppix_list(self, ixpplist: list) -> None:
        """ EXIF時刻リストのsetter """
        self.__exiftime_ppix_list = ixpplist
        
    @property
    def ss_datetime(self) -> datetime:
        """  """
        return self.__ss_datetime
    
    @ss_datetime.setter
    def ss_datetime(self, recss: datetime) -> None:
        """  """
        self.__ss_datetime = recss
    
    
    
    
    def create_instances(self):
        """
        １．KgmQpQgisIoのインスタンスを作りself._kgm_qp_mapioに入れる
        ２．KGMの３種類のデータ各々を処理する４クラスのインスタンスを作成
          (1) KgmQpTracklog： GPSトラックログに関する処理を担当
          (2) KgmQpPhotopoints： 写真画像・メモテキストに関する処理を担当
          (3) KgmQpExif： 写真画像のEXIF情報に関する処理を担当
          (4) KgmQpSound： 音声に関する処理を担当
        """
        ##### １．KgmQpQgisIoのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        #    変数名は「_kgm_qp_mapio」と一般的な名称にする
        self._kgm_qp_mapio = KgmQpQgisIo(self.__my_instance)
        
        if self._debug_mode == 'Y':
            print('【KgmQpData】KgmQpQgisIoのインスタンスへの参照は、'\
                  '{} です。'.format(self._kgm_qp_mapio))
            self._kgm_qp_mapio.amiok()
        
        
        
        ##### 2022/05/26: 既存のtlgレイヤ（あれば）のリストを作成
        #     ∵ 保存ずみのqgzファイルを開いてから起動した場合に対処
        tlg_layer_names = self._kgm_qp_mapio.list_existing_tlgs()
        
        if self._debug_mode == 'Y':
            print('【create_instances】「tlg_layer_namesの値は'\
                  '{} 」です。'.format(tlg_layer_names))
        
        if len(tlg_layer_names) > 0:
            for lname in tlg_layer_names:
                """ メイン窓のcboxにtlogレイヤ名を追加 """
                self._current_mainwindow.insert_new_tracklog_into_cbx(lname)
                
                if self._debug_mode == 'Y':
                    print('【create_instances】Tracklog「'\
                          '{} 」をcboxに追加しました。'.format(lname))
            
        else:
            pass
        
        ##### ２-(1) KgmQpTracklogのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        self.kgm_tlg_inst = KgmQpTracklog(self.__my_instance,
                                          self._kgm_qp_mapio)
        
        if self._debug_mode == 'Y':
            self.kgm_tlg_inst.amiok()
        
        '''
        # 【2023/03/05】KgmQpExifへの参照追加のため順序を変更
        ##### ２-(2) KgmQpPhotopointsのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        
        self.kgm_pp_inst = KgmQpPhotopoints(self.__my_instance,
                                            self._kgm_qp_mapio)
        if self._debug_mode == 'Y':
            self.kgm_pp_inst.amiok()
        '''
        
        ##### ２-(3) KgmQpExifのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        self.kgm_exif_inst = KgmQpExif(self.__my_instance)  
        
        
        # 【2023/03/05】KgmQpExifへの参照を引数に追加したため、
        #  ２-(2) KgmQpPhotopointsのインスタンス作成をここへ移動
        
        self.kgm_pp_inst = KgmQpPhotopoints(self.__my_instance,
                                            self._kgm_qp_mapio,
                                            self.kgm_exif_inst)
        if self._debug_mode == 'Y':
            self.kgm_pp_inst.amiok()
        
        
        ##### ２-(4) KgmQpSoundのインスタンスを作り、
        #    自分自身のインスタンスへの参照を渡す
        self.kgm_snd_inst = KgmQpSound(self.__my_instance)
    
    
    def set_default_kgmdir(self):
        """
        【2022/05/26】
        既存のqdzにtlgレイヤがあった場合、その最上位のものがある
        ディレクトリを、KGMデータのデフォルトディレクトリとする
        """
        if self._current_mainwindow.comboBox_TrackLogName.count() > 0:
            """
            2022/05/26:
            comboBoxに既存のtlgレイヤ名がある
            ie. qgzから既存tlgレイヤを取り込んだ
             → その最上位のものをデフォルトのKGMデータとする
            """
            tlg_layername = self._current_mainwindow.comboBox_TrackLogName.itemText(0)
            
            if self._debug_mode == 'Y':
                print('comboBox_TrackLogNameの現在の最上位のtlg名は、'\
                      '{}です。'.format(tlg_layername))
            
            default_kgmdir = self._kgm_qp_mapio.find_dirname_of_layersourse(tlg_layername)
            if self._debug_mode == 'Y':
                print('【set_default_kgmdir】デフォルトのKGMdirは、'\
                      '{}です。'.format(default_kgmdir))
            
            self.kgmqp_folderpath = default_kgmdir
            
        else:
            default_kgmdir = ''
            
        return default_kgmdir
    
    
    def prepare_datasets(self):
        """
        ３．KGMデータフォルダ内を検索し、以下の値をセット
          (1)KgmQpTracklogファイルへのパス
          (2)写真画像のjpgファイル名リスト
          (3)KgmQpPhotopointsソースへのパス
          (4)KGMindex.txt（あれば）内の録音開始時刻文字列
          (5)音声ファイルへのパス
        ４．QGISに以下のレイヤを作成または既存のものに設定
        　(1)KgmQpTracklogレイヤ
        　(2)KgmQpPhotopointsレイヤ
        """
        
        ##### ３-(1) KgmQpTracklogファイルへのパスをセット
        self.__kgmqp_tlgfile_path = self.kgm_tlg_inst.set_kgmqp_tlgfile_path()
        if self._debug_mode == 'Y':
            print('【KgmQpData】Tracklogファイルへのパスは、'\
                  '{} です。'.format(self.kgmqp_tlgfile_path))
        
        ##### ３-(2) 写真画像のjpgファイル名リストをセット
        self.__kgmqp_list_jpgpics = self.kgm_pp_inst.set_kgmqp_list_jpgpics() 
        if self._debug_mode == 'Y':
            print('【KgmQpData】画像ファイル名のリストは、'\
                  '{} です。'.format(self.kgmqp_list_jpgpics))
        '''
        ##### ３-(3) KgmQpPhotopointsソースへのパスをセット
        self.__kgmqp_ppsource_path = self.kgm_pp_inst.set_kgmqp_ppsource_path()
        if self._debug_mode == 'Y':
            print('【KgmQpData】Photopointsソースへのパスは、'\
                  '{} です。'.format(self.kgmqp_ppsource_path))
        '''
        
        
        ##### ３-(3)【2023/03/17】ここでProjectKikiGaki.pjの有無をチェック
        #     これがあってKGMindex.txtがなければ（暫定のを）作成
        #     すでにKGMindex.txtがあれば、何もしない
        #     ( -> see https://docs.python.org/ja/3/library/xml.etree.elementtree.html)
        projkg_path = os.path.join(
                                self.kgmqp_folderpath,
                                'ProjectKikiGaki.pj')
        id_file_path = os.path.join(
                                self.kgmqp_folderpath,
                                'idFile')
        
        try:
            tree = ET.parse(projkg_path) 
        except:
            if self._debug_mode == 'Y':
                print('【prepare_datasets】「ProjectKikiGaki.pj」がありません。')
        else:
            root = tree.getroot()
            for child in root:
                # print(child.tag, child.text)
                if child.tag == 'HoseiPos':
                    str_hosei_pos = child.text
                elif child.tag == 'PictureFlag':
                    str_picture_flag = child.text
            
            if self._debug_mode == 'Y':
                print('【prepare_datasets】str_hosei_posの値は、'\
                      '{} です。'.format(str_hosei_pos))
                print('【prepare_datasets】str_picture_flagの値は、'\
                      '{} です。'.format(str_picture_flag))
        
        try:
            id_file_txtfile = open(id_file_path, 'r')
        except:
            if self._debug_mode == 'Y':
                print('【prepare_datasets】「idFile」がありません。')
        else:
            id_file_line1 = id_file_txtfile.readline()   # 最初の１行だけ読む
            id_file_line1_itemlist = id_file_line1.split(',')
            if self._debug_mode == 'Y':
                print('【prepare_datasets】id_file_line1_itemlistの値は、'\
                      '{} です。'.format(id_file_line1_itemlist))
            
            str_pic1_exifdt = id_file_line1_itemlist[5]
            if self._debug_mode == 'Y':
                print('【prepare_datasets】str_pic1_exifdtの値は、'\
                      '{} です。'.format(str_pic1_exifdt))
                
            dt_pic1_utc = datetime.strptime(str_pic1_exifdt, '%Y/%m/%d %H:%M:%S') + timedelta(hours=-9)
            flt_hosei_pos = float(str_hosei_pos)
            dt_sound_start = dt_pic1_utc - timedelta(seconds=flt_hosei_pos)
            
            if self._debug_mode == 'Y':
                print('【prepare_datasets】dt_sound_startの値は、'\
                      '{} です。'.format(dt_sound_start))
            
            str_sound_start = datetime.strftime(dt_sound_start, '%Y/%m/%d %H:%M:%S')
            
            if self._debug_mode == 'Y':
                print('【prepare_datasets】str_sound_startの値は、'\
                      '{} です。'.format(str_sound_start))
            
            str_kgmindex_dummypart = ',0000/00/00 00:00:00,000000_000,kgm-agx'
            derived_kgmindex_str = str_sound_start + str_kgmindex_dummypart
            
            if self._debug_mode == 'Y':
                print('【prepare_datasets】derived_kgmindex_strの値は、'\
                      '{} です。'.format(derived_kgmindex_str))
            
            kgmindex_path = os.path.join(
                                    self.kgmqp_folderpath,
                                    'KGMindex.txt')
            derived_kgmindex_file = open(kgmindex_path,
                                    'w',
                                    encoding='shift-jis')
            derived_kgmindex_file.write(derived_kgmindex_str)
            derived_kgmindex_file.close()
        
        
        
        
        ##### ３-(4) KGMindex.txt（あれば）内の録音開始時刻文字列をセット
        kgmindex_path = os.path.join(
                                self.kgmqp_folderpath,
                                'KGMindex.txt')
        # KGMindex.txtのオープンを試み、
        # 成功ならその内容をインスタンス変数にセットしフラグを'Y'に
        # エラーならインスタンス変数を''としフラグを'N'に
        try:
            '''
            ##### 2022/10/05: encodingを「utf_8」（アンダースコア）
            #                 にしていた！
            kgmindex_txtfile = open(kgmindex_path,
                                    "r",
                                    encoding="utf_8",
                                    errors="",
                                    newline="" )
            '''
            
            '''
            ##### 2022/10/05: encodingを「utf-8」に訂正
            kgmindex_txtfile = open(kgmindex_path,
                                    'r',
                                    encoding='utf-8')
            '''
            
            ##### 2022/10/05: encodingを「shift-jis」に訂正
            kgmindex_txtfile = open(kgmindex_path,
                                    'r',
                                    encoding='shift-jis')
            
            
        except:
            self.__kgmindex_str = ''
                # KGMindex.txtの内容を読み込む
            self.__kgmindex_exists = 'N'
                # 存否フラグを'Y'に
        
        else:
            if self._debug_mode == 'Y':
                 print('【prepare_datasets】KGMindex.txtへのパス = '\
                  '{}'.format(kgmindex_path))
            
            
            '''
            self.__kgmindex_str = kgmindex_txtfile.read()
                # KGMindex.txtの内容を読み込む
            '''
            
            self.__kgmindex_str = kgmindex_txtfile.readline()
            
            self.__kgmindex_exists = 'Y'
                # 存否フラグを'Y'に
        
        if self._debug_mode == 'Y':
            print('KGMindex.txtの存否 = '\
                  '{}'.format(self.kgmindex_exists))
            print('KGMindex.txtの内容 = '\
                  '{}'.format(self.kgmindex_str))
        
        '''
        ##### ３-(5) 音声ファイルへのパスをセット
        self.__kgmqp_soundfile_path = self.kgm_snd_inst.prepare_sound_data()
        '''
        
        ##### ４-(1) KgmQpTracklogレイヤを設定
        self.tlglyr_name = self.kgm_tlg_inst.set_kgmqp_tlglayer(
                                                self.kgmqp_tlgfile_path)
        
        if self._debug_mode == 'Y':
            print('self.kgmqp_tlgfile_pathの値 = '\
                  '{}'.format(self.kgmqp_tlgfile_path))
            print('self.tlglyr_nameの値 = '\
                  '{}'.format(self.tlglyr_name))
        
        
        ##### ３-(3) KgmQpPhotopointsソースへのパスをセット
        self.__kgmqp_ppsource_path = self.kgm_pp_inst.set_kgmqp_ppsource_path()
        if self._debug_mode == 'Y':
            print('【KgmQpData】Photopointsソースへのパスは、'\
                  '{} です。'.format(self.kgmqp_ppsource_path))
        
        ##### ４-(2) KgmQpPhotopointsレイヤを設定
        self.pplyr_name = self.kgm_pp_inst.set_kgmqp_pplayer(
                                                self.kgmqp_ppsource_path)
        
        ##### 2023/03/05: 【暫定】EXIF時刻・写真番号リストを作成・保存
        #                  この際にEXIF時刻を文字列からdatetimeに変換
        self.exiftime_ppix_list = self.kgm_pp_inst.set_exiftime_ppix_list() 
        
        
        
        
        
        ##### 2023/03/02: 【暫定】self.active_kgm_layerdictのセットのテスト
        self.set_active_kgm_layerdict(
            '暫定名',
            self.kgmqp_tlgfile_path,
            self.kgmqp_ppsource_path)
        
    
    def add_tlglyr_name_to_cbx(self):
        """
        2022/04/24: コンボボックスにトラックログレイヤ名を追加
        2022/05/26: KGMデータの新規追加を示すフラグを立てる
                    prepare_dataset()から分離
        2023/03/01: GPXのtracksのレイヤ名を表示用に使用
        """
        self.kgmdata_added = 'Y'
        
        
        ##### 2023/03/01: GPXのtracksのレイヤ名を表示用に使用
        # self._current_mainwindow.insert_new_tracklog_into_cbx(self.tlglyr_name)
        
        self._current_mainwindow.insert_new_tracklog_into_cbx(self.tracks_name)
        
    
    
    ##### 2021/11/15: メイン窓のボタン（など）の操作に対応する処理
    def button_sound_forward(self):
        """  音声を〇秒進める"""
        milisec = self.kgm_snd_inst.player.position() + \
                  self.kgm_snd_inst.foward_backward_seconds*1000
        # 頭出しして再生
        self.kgm_snd_inst.player.setPosition(milisec)
        self.kgm_snd_inst.player.play()
        
    def button_sound_backward(self):
        """  音声を〇秒戻す"""
        milisec = self.kgm_snd_inst.player.position() - \
                  self.kgm_snd_inst.foward_backward_seconds*1000
        # 頭出しして再生
        self.kgm_snd_inst.player.setPosition(milisec)
        self.kgm_snd_inst.player.play()
    
    def button_sound_stopresume(self) -> str:
        """
        音声再生を停止・再開 
        arg: None
        return: text to be shown in the button
        """
        
        if (self.kgm_snd_inst.player.state() == QMediaPlayer.PlayingState):
            self.kgm_snd_inst.player.pause()
            # labeltext = '再開'
            labeltext = self.labeltext_stopresume()
        elif (self.kgm_snd_inst.player.state() == QMediaPlayer.PausedState):
            self.kgm_snd_inst.player.play()
            # labeltext = '停止'
            labeltext = self.labeltext_stopresume()
        else:
            self.kgm_snd_inst.player.stop()
            # labeltext = '【終了】'
            labeltext = self.labeltext_stopresume()
        
        return labeltext
        
    def button_sound_listen_again(self):
        """ もう一度聞く """
        milisec = self.kgm_snd_inst.sound_elapsed_milisec_adjusted
        # 頭出しして再生
        self.kgm_snd_inst.player.setPosition(milisec)
        self.kgm_snd_inst.player.play()
    
    def button_pic_next(self) -> list:
        """ 「次の写真へ」 """
        
        int_max = len(self.kgmqp_list_jpgpics)
        # print(".jpgファイルの総数は、", int_max, "個です。")
        if self.current_photo_index >= int_max - 1:
            self.current_photo_index = int_max - 1
        else:
            self.current_photo_index += 1          # incliment
        
        self.kgm_pp_inst.zoom_to_selected_point()
        self.kgm_snd_inst.play_sound(self.current_photo_index)
        pp_attrlist = \
            self.current_photo_attributes(self.current_photo_index)
        
        return pp_attrlist
    
    def button_pic_previous(self) -> list:
        """ 「前の写真へ」 """
        
        int_max = len(self.kgmqp_list_jpgpics)
        # print(".jpgファイルの総数は、", int_max, "個です。")
        if self.current_photo_index >= int_max - 1:
            self.current_photo_index = int_max - 1
        elif self.current_photo_index <= 0:
            self.current_photo_index = 0           # 0が最小
        else:
            self.current_photo_index -= 1          # decliment
        
        self.kgm_pp_inst.zoom_to_selected_point()
        self.kgm_snd_inst.play_sound(self.current_photo_index)
        pp_attrlist = \
            self.current_photo_attributes(self.current_photo_index)
        
        return pp_attrlist
    
    def labeltext_stopresume(self) -> str:
        """
        音声再生の停止・再開・終了の表示を更新
        arg: None
        return: text to be shown on Stop/Resume button
        """
        
        if (self.kgm_snd_inst.player.state() == QMediaPlayer.PlayingState):
            labeltext = '停止'
        elif (self.kgm_snd_inst.player.state() == QMediaPlayer.PausedState):
            labeltext = '再開'
        else:
            labeltext = '【終了】'
        
        return labeltext
    
    def switch_current_dataset(self, crnt_cbx_ix: int, crnt_cbx_text: str) -> list:
        """
        【2022/04/24】
        comboBox_TrackLogNameで選択されたトラックログのインデクス値
        に基づいて、現在操作対象のKGMデータセットを切り替える
        【2022/05/26】
        prepare_dataset()と処理を切り分けて整理
        既存のqgzを開いてから起動した場合にも対応可にするよう改訂
        """
        # crnt_tp_layer = self._kgm_qp_mapio.select_tp_layer(crnt_cbx_text)
        
        if self.kgmqp_folderpath == '':
            """ 
            kgmqp_folderpathが未設定：
            ie. qgzの既存tlgレイヤをcboxに追加している段階
            その旨をconsoleに書き出すだけで何もしない
            """
            if self._debug_mode == 'Y':
                print('【switch_current_dataset】qgzの既存tlgレイヤ'\
                      '{} を追加しました。'.format(crnt_cbx_text))
            return
        
        ### elif self.kgmdata_added == 'Y':
            """
            【これはヤメ】KGMデータ新規追加フラグが立っている
            """
        
        elif crnt_cbx_text == '':
            """
            2022/05/26: 新規追加を以前と同じくcrnt_cbx_text = ''で判定
            """
            crnt_kgm_dirpath = self.kgmqp_folderpath
            if self._debug_mode == 'Y':
                print('【switch_current_dataset】追加データのcrnt_kgm_dirpathの値は、'\
                      '{} です。'.format(crnt_kgm_dirpath))
            ### self.kgmdata_added = 'N'     # 追加ずみ
        else:
            crnt_kgm_dirpath = self._kgm_qp_mapio.set_current_kgmqp_data_path(
                crnt_cbx_text)
            ### 2022/05/12: setterで値をセット
            self.kgmqp_folderpath = crnt_kgm_dirpath
            
        if self._debug_mode == 'Y':
            print('【KgmQpData】切替後のself.kgmqp_folderpathの値は、'\
                  '{} です。'.format(self.kgmqp_folderpath))
            
        ### 2022/05/26: prepare_datasets()と被っていた部分を整理
        self.prepare_datasets()
        
        ### 2022/05/12: self._kgm_qp_mapioの現在ppレイヤもここで変更
        current_pp_layer = self._kgm_qp_mapio.select_pp_layer(self.pplyr_name)
        self._kgm_qp_mapio.kgmpic_layer = current_pp_layer
        
        ##### 2022/05/12: コンボボックスにトラックログレイヤ名を追加
        #                 （すでに同名のものがないときのみ）
        self._current_mainwindow.insert_new_tracklog_into_cbx(self.tlglyr_name)
        self.current_photo_index = 0
        self.kgm_pp_inst.zoom_to_selected_point()
        self.kgm_snd_inst.play_sound(self.current_photo_index)
        pp_attrlist = \
            self.current_photo_attributes(self.current_photo_index)
        
        return pp_attrlist
    
    
    
    
    '''
    ##### 2023/02/26: 「拡張機能」ボタン化に伴いコメントアウト
    def button_kml_export(self, path: str) -> None:
        """ 「KML出力」ボタンクリック時の処理 """
        
        ##### 2021/12/16: Chromebook用のKML（いずれはKMZ）出力
        if self._debug_mode == 'Y':
            print('【KgmQpData】「KML出力」ボタンがクリックされました。')
        
        
        ##### kml_tracklog_str = self._kgm_qp_mapio.s2k_tracklog()
        kml_photopoint_str = self._kgm_qp_mapio.s2k_photopoints()
    '''
    
    
    
    def set_active_kgm_layerdict(self,
            shared_name: str,
            gpx_path: str,
            shape_path: str):
        """
        【2023/03/02】
        """
        
        kgm_layerdict = self.active_kgm_layerdict
        
        if len(shared_name) > 0 :
            kgm_layerdict.update(shared_layername = shared_name)
        
        if len(gpx_path) > 0 :
            kgm_layerdict.update(gpx_source_path = gpx_path)
            
        if len(shape_path) > 0 :
            kgm_layerdict.update(shape_source_path = shape_path)
            
        
        self.active_kgm_layerdict = kgm_layerdict
        
        if self._debug_mode == 'Y':
            print('【set_active_kgm_layerdic】self.active_kgm_layerdictの値は、'\
                  '{}です。'.format(list(self.active_kgm_layerdict.items())))
    
    
    
    
    
    
    
    def button_qtableview(self) -> None:
        """
        【暫定：2023/02/22】
        pushButton_KmlExportクリックからここへ飛ぶ
        QTableViewのテスト用
        """
        
        ##### 2023/02/22: 【暫定：QTableViewのテスト用】
        if self._debug_mode == 'Y':
            print('【button_qtableview】「拡張機能」ボタンがクリックされました。')
        
        
        ##### 2023/02/25: SRT表示のテスト
        #     based on: gpxファイルへのパス設定のルーチン
        
        str_glob_target = os.path.join(
                          self.kgmqp_folderpath,
                          '*.srt')
        try:
            list_srtfile_fullpath = glob.glob(str_glob_target)
        except:
            ##### 2022/02/19: 今後、ファイルなしなどのエラー処理を追記
            pass
        else:
            if len(list_srtfile_fullpath) > 1:
                ##### 2022/02/19: 今後、一覧から選ばせる処理を追記
                print('【button_qtableview】srtファイルが複数あります：'\
                      '{} '.format(list_srtfile_fullpath))
            else:
                srtfile_path = list_srtfile_fullpath[0]
        finally:
            print('【button_qtableview】srtファイルへのパスは、'\
                  '{} です。'.format(srtfile_path))
            
            # return srtfile_path
        
        
        
        
        '''
        with open('D:\gis_work\_KgmQpdSR_tests\KGM20211030163840\【large】KGM20221208141347_first-10min.srt', mode='r', encoding="utf-8") as f: 
        '''
        with open(srtfile_path, mode='r', encoding="utf-8") as f: 
            subs = srt.parse(f.read()) 
            
            
            '''
            ##### 2023/02/26: 2/25はここでリスト化して表示に成功
            #                 2/26はsubsをそのまま渡す方法を試す
            sub_temp = []
            
            for sub in subs: 
                print(sub)
                sub_temp.append([sub.index, str(sub.start), sub.content])
                
            self.subs_test01 = sub_temp
            '''
            
            
            ##### 2023/02/26: subs（＝generatorオブジェクト）をもとに、
            #     その各行（＝Subtitleオブジェクト）を要素とする配列に変換
            #     これをlf.subs_test01に入れる
            self.subs_test01 = list(subs)
            
            print(self.subs_test01)
            
    
    
    
    
    
    def button_jamboard_export(self, path: str) -> None:
        """
        「写真印刷」ボタンクリック時の処理
        ☆2022/02/26: 当面は、JamBoard用画像ファイルの書き出し
        
        """
        
        ##### 2022/20/06: 全写真か現表示写真かのフラグ
        flag_allpics = 'Y'
        
        if self._debug_mode == 'Y':
            print('【KgmQpData】「写真印刷」ボタンがクリックされました。')
        
        map_image_name = self.pplyr_name + \
                        '_撮影地点_' + \
                        str(self.current_photo_index) + \
                        '_地図.png'
        fullpath_map = os.path.join(path, map_image_name)
        self._kgm_qp_mapio.save_map_as_image(fullpath_map)
        
        if flag_allpics != 'Y':
            """ 現在表示中の写真だけを書き出す """
            jb_image = self.compose_jb_image(self.kgmqp_folderpath, self.current_photo_index)
            jb_image_name = self.pplyr_name + \
                            '_撮影地点_' + \
                            str(self.current_photo_index) + \
                            '_写真.jpg'
            fullpath_jb_image = os.path.join(path, jb_image_name)
            jb_image.save(fullpath_jb_image)
        else:
            """ すべての写真を書き出す """
            for ix, jpg_filename in enumerate(self.kgmqp_list_jpgpics):
                jb_image = self.compose_jb_image(self.kgmqp_folderpath, ix)
                jb_image_name = self.pplyr_name + \
                        '_撮影地点_' + \
                        str(ix) + \
                        '_写真.jpg'
                fullpath_jb_image = os.path.join(path, jb_image_name)
                jb_image.save(fullpath_jb_image)
        
        QMessageBox.information(None,
                                "通知",
                                "写真・地図の画像を書き出しました。",
                                QMessageBox.Yes)
    
    def compose_jb_image(self, pp_pic_folder: str, ix: int) -> object:
        """
        現在表示中の写真にID番号を付しリサイズした画像を作成
        arg1: 写真画像のあるフォルダのフルパス
        return: リサイズしてID番号を付した画像
        """
        cpa = self.current_photo_attributes(ix)
        pp_pic_filename = cpa[1]
        pp_pic_fullpath = os.path.join(pp_pic_folder, pp_pic_filename)
        
        ##### 2022/03/23: Pillowで読み込んだ後にEXIF により写真画像を回転
        original_image = Image.open(pp_pic_fullpath)
        my_image = self.rotate_image_using_exif(original_image)
        
        resized_image = self.resize_image_by_longside(my_image, 640)
        
        ##### 2022/03/18:
        # title_font = ImageFont.load_default()
        ##### 2022/06/26: Macではフォント名の頭を大文字にする要あり
        #     ∴インスタンス変数に保存したOS種別により処理を選択
        if 'Windows' in self.iv_platform_system_result:
            ##### 2022/06/30: フォントが見つからないエラーの回避
            try:
                title_font = ImageFont.truetype("arial.ttf", 40)
            except:
                title_font = ImageFont.load_default()
        elif 'Darwin' in self.iv_platform_system_result:
            ##### 2022/06/30: フォントが見つからないエラーの回避
            try:
                title_font = ImageFont.truetype("Arial.ttf", 40)
            except:
                title_font = ImageFont.load_default()
        else:
            print('【KgmQpData：要注意】システムが特定できません！')
        
        
        image_editable = ImageDraw.Draw(resized_image)
        
        ##### 2022/03/18:
        # image_editable.text((20,20), str(ix), (0, 0, 0), title_font, None, None,"center")
        image_editable.rectangle([(0, 0), (70, 70)], (255, 255, 255), (0, 0, 0), 3)
        image_editable.text((35,35), str(ix), fill="black", anchor="mm", font=title_font)
        
        return  resized_image
    
    def rotate_image_using_exif(self,
                                image_original: object) -> object:
        """
        画像をEXIF情報（もしあれば）にしたがって回転
        aug1:  original image
        return: rotated image
        """
        
        exif_table = self.kgm_exif_inst.get_exif_of_image2(image_original)
        exif_orientation_code = exif_table.get("Orientation")
        
        if (exif_orientation_code == 1):
            degree = 0
        elif (exif_orientation_code == 3):
            degree = 180
        elif (exif_orientation_code == 6):
            degree = 270
        elif (exif_orientation_code == 8):
            degree = 90
        else:
            degree = 0
        
        # original_image = Image.open(pic_fullpath)
        rotated_image = image_original.rotate(degree, expand = 1)
        
        return rotated_image
    
    def resize_image_by_longside(self, 
                               image_original: object,
                               longside_pixel: int) -> object:
        """
        画像の長辺のピクセル数を指定してリサイズ
        aug1: original image
        aug2: longside size (in pixels)
        return: resized image
        """
        size_width = image_original.width
        size_height = image_original.height
        
        if size_width >= size_height:
            resized_width = longside_pixel
            resized_height = int(longside_pixel*size_height/size_width)
        else:
            resized_width = int(longside_pixel*size_width/size_height)
            resized_height = longside_pixel
        
        resized_image =  image_original.resize((resized_width, resized_height))
        
        return resized_image
    
    def current_photo_attributes(self, ix: int) -> list:
        """ 表示中のphotopointの属性リストを返す """
        pp_attrlist = self._kgm_qp_mapio.sp_feature_attributes(ix)
        return pp_attrlist
    
    
    def photopoint_to_be_shown_update(self):
        """
        【2022/02/15】地図上のphotopointクリックによる表示の更新
        （当座）メイン窓のshow_kgm_pic_attrで実施
        （当座）メイン窓の写真ID番号表示欄（lineEdit）の更新で
                拡大窓にも反映
        　☆事前にself.current_photo_indexを更新しておく！
        """
        
        cpa = self.current_photo_attributes(self.current_photo_index)
        self._current_mainwindow.show_kgm_pic_attr(cpa)
        
        ##### 2022/03/04:【要修正】ここで直接lineEdit_PicIDに書き込む是非
        self._current_mainwindow.lineEdit_PicID.setText(
                                           str(self.current_photo_index)
                                           )
        self.kgm_pp_inst.zoom_to_selected_point()
        self.kgm_snd_inst.play_sound(self.current_photo_index)
        
    
    def show_data_by_hittext(self, pic_ix: int, cue_milisec: int) -> None:
        """
        【2023/03/05】文字列検索結果から写真・地図・音声を更新
        
        """
        self.current_photo_index = pic_ix
        cpa = self.current_photo_attributes(pic_ix)
        self._current_mainwindow.show_kgm_pic_attr(cpa) 
        self.kgm_pp_inst.zoom_to_selected_point()
        
        ##### 2023/03/07: 音声をSRTのstart時刻から再生するよう変更
        # self.kgm_snd_inst.play_sound(self.current_photo_index)
        self.kgm_snd_inst.play_sound_from_cue_milisec(cue_milisec)
        



class KgmQpTracklog:
    """ KGMのトラックログ処理クラス """
    
    def __init__(self, coredata:object, mapio: object):
        """ 
        コンストラクタ：
        
        """
        
        self._kgm_qp_coredata = coredata
        self._kgm_qp_mapio = mapio     # KgmQpQgisIoのインスタンスへの参照
        
        
    def amiok(self):
        print('【KgmQpTracklog】KgmQpQgisIoのインスタンス参照は、'\
              '{} です。'.format(self._kgm_qp_mapio))
        
    
    def set_kgmqp_tlgfile_path(self) -> str:
        str_glob_target = os.path.join(
                          self._kgm_qp_coredata.kgmqp_folderpath,
                          '*.gpx')
        try:
            list_gpxfile_fullpath = glob.glob(str_glob_target)
        except:
            ##### 2022/02/19: 今後、ファイルなしなどのエラー処理を追記
            pass
        else:
            if len(list_gpxfile_fullpath) > 1:
                ##### 2022/02/19: 今後、一覧から選ばせる処理を追記
                print('【KgmQpTracklog】gpxファイルが複数あります：'\
                      '{} '.format(list_gpxfile_fullpath))
            else:
                tlgfile_path = list_gpxfile_fullpath[0]
        finally:
            print('【KgmQpTracklog】gpxファイルへのパスは、'\
                  '{} です。'.format(tlgfile_path))
            return tlgfile_path
    
    def set_kgmqp_tlglayer(self, tlgfile_path: str) -> str:
        """ KgmQpTracklogレイヤを作成・設定してレイヤ名を返す """
        tlgfile_name = os.path.basename(tlgfile_path)
        
        
        ##### 2023/03/01: GPXのtracksのレイヤ名を表示用に使用
        #     【要修正】KgmQpDataのインスタンス変数を直にいじっている
        tlglayer_name = self._kgm_qp_mapio.set_tracklog_layer(tlgfile_name)
        # tlg_point_layer_name = self._kgm_qp_mapio.set_tracklog_layer(tlgfile_name)
        self._kgm_qp_coredata.tracks_name = self._kgm_qp_mapio.tracks_layer.name()
        
        return tlglayer_name
    
    
class KgmQpPhotopoints:
    """ KGMの写真画像＋メモ文字列処理クラス """    
    
    def __init__(self, coredata: object, mapio: object, exifio: object):
        """ 
        コンストラクタ：
        【2023/03/05】KgmQpExifのインスタンスへの参照を追加
        
        """
        
        self._kgm_qp_coredata = coredata
        self._kgm_qp_mapio = mapio     # KgmQpQgisIoのインスタンスへの参照
        
        ##### 2023/03/05: KgmQpExifのインスタンスへの参照を追加
        self._kgm_qp_exifio = exifio
    
    def amiok(self):
        print('【KgmQpPhotopoints】KGMデータのあるフォルダへのパスは、'\
              '{} です。'.format(self._kgm_qp_coredata.kgmqp_folderpath))
        
    
    def set_kgmqp_list_jpgpics(self) -> list:
        """ 写真画像のjpgファイル名リストを返す """
        
        list_jpgpics = []
        
        
        # 2021/12/03: Macでは大文字・小文字を区別してエラーになるので書き換えた
        #     まずstr_kgmq_dir_pathフォルダ内の全ファイルをglobでリストし、
        #     ついでリスト内包表記でextが'.jpg'または'.JPG'のものを抽出、
        #     その後（当面）地味にループでパスなしファイル名の空リストに追加。
        #     ☆【要注意！】'.*\.(jpg|JPG)'のアスタリスク前のピリオドは必須！
        str_glob_target = os.path.join(self._kgm_qp_coredata.kgmqp_folderpath,
                                       '*.*')
        list_jpgpics_fullpath = \
                [fp for fp in glob.glob(str_glob_target) \
                 if re.search('.*\.(jpg|JPG)', str(fp))]
        for file in sorted(list_jpgpics_fullpath):
                # ファイル名（ソートずみ）のリストを作成
            filanameonly = os.path.basename(file)
            list_jpgpics.append(filanameonly)
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('抽出した写真のリストは、{} です。'.format(list_jpgpics))
        
        return list_jpgpics
    
    def set_kgmqp_ppsource_path(self) -> str:
        """ KgmQpPhotopointsソースへのパスをセット """
        str_glob_target = os.path.join(self._kgm_qp_coredata.kgmqp_folderpath,
                                       '*.shp')
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmQpPhotopoints】str_glob_targetの値は、'\
                  '{}です。'.format(str_glob_target))
            
        try:
            list_shpfile_fullpath = glob.glob(str_glob_target)
            if self._kgm_qp_coredata._debug_mode == 'Y':
                print('【KgmQpPhotopoints】list_shpfile_fullpathの値は、'\
                      '{}です。'.format(list_shpfile_fullpath))
        except:
            ##### 2022/02/24: globはtargetが見つからないと[]を返す
            #                 ie.エラーにはならない
            # pass
            
            QMessageBox.information(None,
                "【注意：要調査】",
                "globのtargetが見つからない",
                QMessageBox.Yes)
            
        else:
            
            ##### 2022/10/05: 空リスト判定法を訂正
            # if not list_shpfile_fullpath:
            # if len(list_shpfile_fullpath) < 1:
            if not list_shpfile_fullpath:
                
                '''
                QMessageBox.information(None,
                    "【注意：要調査】",
                    "list_shpfile_fullpathが空リストです！",
                    QMessageBox.Yes)
                '''
                
                list_pics = self._kgm_qp_coredata.kgmqp_list_jpgpics
                
                if self._kgm_qp_coredata._debug_mode == 'Y':
                    print('【確認用】抽出した写真のリストは、{} です。'.format(list_pics))
                
                ##### 2022/10/05: 写真がない・あってもEXIF情報がない場合
                if not list_pics:
                    QMessageBox.information(None,
                        "【注意：要調査】",
                        "写真画像のファイルがありません！",
                        QMessageBox.Yes)
                    ppsource_path = ''
                    ##### return ppsource_path
                
                else:
                    ##### 2022/10/06: とりあえずリスト中の[0]番写真で判定
                    
                    if self._kgm_qp_coredata._debug_mode == 'Y':
                        print('【確認用】リスト[0]の写真は、{} です。'.format(list_pics[0]))
                    
                    
                    '''
                    QMessageBox.information(None,
                        "【確認用】",
                        "写真[0]のEXIF情報を調査します。",
                        QMessageBox.Yes)
                    '''
                    
                    pic_fullpath = os.path.join(self._kgm_qp_coredata.kgmqp_folderpath, list_pics[0])
                    
                    if self._kgm_qp_coredata._debug_mode == 'Y':
                        print('【確認用】リスト[0]の写真のフルパスは、{} です。'.format(pic_fullpath))
                    
                    list_exif = self._kgm_qp_coredata.kgm_exif_inst.get_exif_of_image(pic_fullpath)
                    
                    if self._kgm_qp_coredata._debug_mode == 'Y':
                        print('【確認用】list_exifの値は、{} です。'.format(list_exif))
                    
                    
                    
                    '''
                    QMessageBox.information(None,
                                "【確認用】",
                                "get_exif_of_imageの結果は" + list_exif + "です。",
                                QMessageBox.Yes)
                    '''
                    
                    
                    
                    if not list_exif:
                        """ EXIF情報なし """
                        
                        if self._kgm_qp_coredata._debug_mode == 'Y':
                            print('【確認用】「if not list_exif:」を実行中：')
                        
                        
                        QMessageBox.information(None,
                        "【注意：要調査】",
                        "写真の撮影時刻情報が見つかりません！",
                        QMessageBox.Yes)
                        ppsource_path = ''
                        ##### return ppsource_path
                    
                    else:
                        """ EXIF情報あり """
                        '''    
                        else:
                            QMessageBox.information(None,
                                "【注意：要調査】",
                                "何でやねん？",
                                QMessageBox.Yes)
                            ppsource_path = ''
                            ##### return ppsource_path
                        '''
                        
                        if self._kgm_qp_coredata._debug_mode == 'Y':
                            print('【新規作成前】list_shpfile_fullpathの値が、'\
                                  '{}なので新規作成します。'.format(list_shpfile_fullpath))
                        
                        #### 2022/02/24: shpファイル・ppレイヤを新規作成
                        layer_name = self._kgm_qp_mapio.create_point_shape_layer()
                        list_shpfile_fullpath = glob.glob(str_glob_target)
                        if self._kgm_qp_coredata._debug_mode == 'Y':
                            print('【新規作成後】list_shpfile_fullpathの値は、'\
                                  '{}です。'.format(list_shpfile_fullpath))
                        ppsource_path = list_shpfile_fullpath[0]
                        
            elif len(list_shpfile_fullpath) > 1:
                ##### 2022/02/19: 今後、一覧から選ばせる処理を追記
                print('【KgmQpPhotopoints】shpファイルが複数あります：'\
                      '{} '.format(list_shpfile_fullpath))
            else:
                
                '''
                QMessageBox.information(None,
                    "【注意：要調査】",
                    "list_shpfile_fullpathの要素数は、" + str(len(list_shpfile_fullpath)) + "です。",
                    QMessageBox.Yes)
                '''
                
                ppsource_path = list_shpfile_fullpath[0]
            
        
        finally:
            
            '''
            print('【KgmQpPhotopoints】shpファイルへのパスは、'\
                  '{} です。'.format(ppsource_path))
            '''
            
            '''
            QMessageBox.information(None,
                "【注意：要調査（本来はここに来ないはず）】",
                "list_shpfile_fullpathの要素数は、" + str(len(list_shpfile_fullpath)) + "です。",
                QMessageBox.Yes)
            '''
            
        return ppsource_path
        
    
    
    def set_kgmqp_pplayer(self, ppsource_path: str) -> str:
        """ Photopointのレイヤを作成・設定してレイヤ名を返す """
        
        ##### 2022/10/06: ppsource_pathが''の場合に対処
        #                （↑）写真データがない・EXIF情報が開けないなど
        if len(ppsource_path) < 1:
            pplayer_name = ''
        else:
            ppsource_name = os.path.basename(ppsource_path)
            pplayer_name = self._kgm_qp_mapio.set_pp_layer(ppsource_name)
            
        return pplayer_name
    
    def get_pplyr_fields(self):
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmQpPhotopoints】photopointのレイヤ名は、'\
                  '{}です。'.format(self._kgm_qp_coredata.pplyr_name))
            
        pplyr_fields = \
            self._kgm_qp_mapio.get_fields(self._kgm_qp_coredata.pplyr_name)
        
        return pplyr_fields
    
    def zoom_to_selected_point(self):
        """ 2021/11/15: 表示中のphotopointの地点にズーム """
        
        layer_name = self._kgm_qp_coredata.pplyr_name
        ix = self._kgm_qp_coredata.current_photo_index
        attrlist = self._kgm_qp_coredata.current_photo_attributes(ix)
        picid = attrlist[0]
        layer = self._kgm_qp_mapio.select_pp_layer(layer_name)
        layer.selectByExpression('"pic_id" = ' + str(picid))
        
        box = layer.boundingBoxOfSelected()
        iface.mapCanvas().setExtent(box)
        # 【2022/02/15: 一時的にコメントアウト】iface.mapCanvas().refresh()
    
    def get_memotext_of_photopoint(self, ix: int) -> str:
        """ 
        現在参照中のphotopointレイヤの属性テーブルを読んで、
        current_photo_attributesを更新し、
        そのフィールド[2]にあるテキストを返す
        """
        
        attrlist = self._kgm_qp_mapio.sp_feature_attributes(ix)
        txt = attrlist[2]              # メモテキストはフィールド[2]
        return txt
    
    def set_memotext_of_photopoint(self, ix: int,  txt: str) -> None:
        """ 
        引数のテキストを、photopointの、引数ixのフィーチャの、
        属性テーブル（の該当フィールド）に書き込む
        
        """
        self._kgm_qp_mapio.set_photopoint_memotext(ix, txt)
        
        return
    
    
    def set_exiftime_ppix_list(self) -> list:
        """
        【2023/03/05】
        【変更前】EXIF時刻・写真番号リストを作成・保存
        【変更後】写真のEXIF時刻のみの１次元配列に変更
        その際、EXIR時刻を文字列からdatetimeに変換
        """
        
        str_xtp_list = self._kgm_qp_mapio.create_xtime_ppix_list()
        
        xtime_ppix_list = []
        # datetime_xtp = []
        
        for ix, str_xtp in enumerate(str_xtp_list):
            
            # converted_xtp = self._kgm_qp_exifio.conv_exifdt_string_to_datetime(str_xtp[1])
            # datetime_xtp =[str_xtp[0], converted_xtp]
            # datetime_xtp =[str_xtp[0], converted_xtp]
            converted_xtp = self._kgm_qp_exifio.conv_exifdt_string_to_datetime(str_xtp)
            
            datetime_xtp = converted_xtp        # これだけの１次元配列に変更
            
            
            if self._kgm_qp_coredata._debug_mode == 'Y':
                print('【set_exiftime_ppix_list】datetime_xtpの値は、'\
                      '{}です。'.format(datetime_xtp))
            
            xtime_ppix_list.append(datetime_xtp)
        
        '''
        xtime_ppix_list = self._kgm_qp_mapio.create_xtime_ppix_list()
        '''
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【set_exiftime_ppix_list】xtime_ppix_listの値は、'\
                  '{}です。'.format(xtime_ppix_list))
        
        return xtime_ppix_list


class KgmQpExif:
    """ 寫眞のEXIF情報を処理するクラス"""
    def __init__(self, coredata: object):
        """
        コンストラクタ
        """
        self._kgm_qp_coredata = coredata
        
        
    def get_exif_of_image(self, jpgpic_path: str) -> list:
        """
        写真のEXIF情報をテーブルとして取得
        Get ESIF of an image if exists.
        指定した画像のEXIFデータを取り出す関数
        @return exif table Exif --- データを格納した辞書
        """
        ##### 2022/10/05: そもそも写真ファイルが開けない場合に対処
        #                 im = Image.open(jpgpic_path)
        try:
            im = Image.open(jpgpic_path)
        except:
            QMessageBox.information(None,
                    "【注意：要調査】",
                    "写真画像ファイルを開くことができません！",
                    QMessageBox.Yes)
            return {}
        
        # Exifデータを取得
        # 存在しなければそのまま終了、空の辞書を返す。
        try:
            exif = im._getexif()
        except AttributeError:
            
            ##### 2022/10/05：EXIF情報の異常を通知
            QMessageBox.information(None,
                    "【注意：要調査】",
                    "写真の撮影時刻の情報が見つかりません！",
                    QMessageBox.Yes)
            
            return {}
            
        # タグIDそのままでは人が読めないのででコードして
        # テーブルに格納する。
        exif_table = {}
        for tag_id, value in exif.items():
            tag = TAGS.get(tag_id, tag_id)
            exif_table[tag] = value
            
        return exif_table
    
    def get_exif_of_image2(self, image_original: object) -> list:
        """
        2022/03/23:
        pillowで読み込んだ写真画像のEXIF情報をテーブルとして取得
        Get ESIF of an image if exists.
        指定した画像のEXIFデータを取り出す関数
        @return exif table Exif --- データを格納した辞書
        """
        # im = Image.open(jpgpic_path)
        
        # Exifデータを取得
        # 存在しなければそのまま終了、空の辞書を返す。
        try:
            exif = image_original._getexif()
        except AttributeError:
            return {}
            
        # タグIDそのままでは人が読めないのででコードして
        # テーブルに格納する。
        exif_table = {}
        for tag_id, value in exif.items():
            tag = TAGS.get(tag_id, tag_id)
            exif_table[tag] = value
            
        return exif_table
    
    
    def get_datetime_of_image(self, jpgpic_path: str) -> str:
        """ 取得したEXIfテーブルから撮影日時を取り出す
            Get date-time of an image if exists
            指定した画像のEXIFデータのうち撮影日時データを取り出す
            @return yyyy:mm:dd HH:MM:SS 形式の文字列
            """
        
        # get_esif_of_imageの戻り値のうち
        # 日付時刻データのみを取得して返す
        exif_table = self.get_exif_of_image(jpgpic_path)
        datetime_original = exif_table.get("DateTimeOriginal")
        return datetime_original
    
    
    def conv_exifdt_to_gpxdt(self, str_exifdt: str) -> str:
        """EXIFのDateTimeをGPXのDateTime(UTC)に変換 """
        exif_year = int(str_exifdt[0:4])
        exif_month = int(str_exifdt[5:7])
        exif_day = int(str_exifdt[8:10])
        exif_hour = int(str_exifdt[11:13])
        exif_minute = int(str_exifdt[14:16])
        exif_second = int(str_exifdt[17:19])
                
        qdt = QDateTime(exif_year,
                        exif_month,
                        exif_day, exif_hour,
                        exif_minute,
                        exif_second,
                        timeSpec=0)
        qdt_utc = QDateTime(qdt.toUTC())
        str_qdt_utc = qdt_utc.toString('yyyy-MM-ddThh:mm:ss.000')
        
        return str_qdt_utc
    
    
    def conv_exifdt_string_to_datetime(self, str_exifdt: str) -> datetime:
        """
        【2023/03/05】
        kgmpic_layerから取ったEXIF時刻（＝文字列）をdatetimeに変換
        """
        
        xdt = datetime.strptime(str_exifdt, '%Y:%m:%d %H:%M:%S')
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【conv_exifdt_string_to_datetime】xdtの値は、'\
                  '{}です。'.format(xdt))
        
        '''
        xdt_datetime = datetime(xdt)
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【conv_exifdt_string_to_datetime】xdt_datetimeの値は、'\
                  '{}です。'.format(xdt_datetime))
        '''
        
        
        return xdt
        
    
    
    


class KgmQpSound:
    """ KGMの音声データ処理クラス """    
    
    def __init__(self, coredata: object):
        """ 
        コンストラクタ：
        
        """
        
        self._kgm_qp_coredata = coredata
        
        ##### 2022'04/24: これを入れるとデータ切り替え時に前の音声が止まらず残るが
        #                 入れないと「playerがない」エラーになる・・・
        self.player = QMediaPlayer()
        
        ### 2022/05/12: null_contentをインスタンス変数として定義
        self.null_content = QtMultimedia.QMediaContent()
        
        
        # 音声のファイル名と開始時点の日時をインスタンス変数に保持
        # 初期値は無名・システムの現在時刻
        self.str_kgm_sound_filename = ''     # 音声ファイルのファイル名
        self.sound_start_datetime = QDateTime.currentDateTime()
        
        # 音声データの伸縮を調整するの係数をインスタンス変数に保持
        # （2021/03/22）
        # self.adjust_coeff = 0.885        
        self.adjust_coeff = 1.000   # KGM-i用に1.000に戻した (2021/05/29)
        
        # 音声を「進める」「戻す」ボタンの秒数をインスタンス変数に保持
        self.foward_backward_seconds = 3
        
        # 撮影時刻までの（調整後）経過時間もインスタンス変数に保持
        # （2021/03/25）
        self.sound_elapsed_milisec_adjusted = 0
        
        
        
        
        
    def amiok(self):
        print('【KgmQpSound】KGMデータのあるフォルダへのパスは、'\
        '{} です。'.format(self._kgm_qp_coredata.kgmqp_folderpath))
        
    def prepare_sound_data(self):
        """  """
        # QtMultimedia.QMediaPlayerで再生する音声ファイルを準備（2021/03/21）
        # 2021/11/13: KgmQpSound内への配置に伴いリライト
        self.str_kgm_sound_filename = \
            self.get_sound_filename(self._kgm_qp_coredata.kgmqp_folderpath)
        
        ##### 2022/04/24: ここで実施
        # self.player = self.set_player()
        self.set_player()
        
        snd_content = self.get_sound_content(self.str_kgm_sound_filename)
        self.player.setMedia(snd_content)
        
        
        ##### 2023/02/21: QMesiaPlayerから１秒ごとにpositionを通知
        #                 そのシグナルで表示を更新
        self.player.setNotifyInterval(1000)
        self.player.positionChanged.connect(self.update_sound_position)
        ##### 2023/02/21: ↑ここまで
        
        self.sound_start_datetime = self.get_start_datetime_of_sound(
                        self._kgm_qp_coredata.kgmqp_folderpath,
                        self.str_kgm_sound_filename
                        )
        
        
        
        ##### 2023/03/05: 【暫定】録音の開始時刻をKgmQpDataのインスタンス変数に保存
        #     この際にGPS型の文字列datetimeに変換
        #     【暫定】self.sound_start_datetimeはQDateTime型だったので、
        #     これを一旦GPS型文字列に変換してからconv_ssdt_string_to_datetimeを呼ぶ
        ssdt_qdatetime = self.sound_start_datetime
        ssdt_gpsstr = ssdt_qdatetime.toString('yyyy/MM/dd hh:mm:ss')
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【prepare_sound_data】ssdt_gpsstrの値 = '\
              '{}'.format(ssdt_gpsstr))
        
        
        self._kgm_qp_coredata.ss_datetime = self.conv_ssdt_string_to_datetime(ssdt_gpsstr)
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【prepare_sound_data】KgmQpDataに保存した録音開始時刻 = '\
              '{}'.format(self._kgm_qp_coredata.ss_datetime))
        
        
    def get_sound_filename(self, str_kgmq_dir_path):
        """ 
        【wav・mp3形式に対応】KGMの音声ファイルのファイル名を返す
        """
        list_sound_files = []
        
        # 2021/12/26: iPhone(WAV)・Android(MP3)の両方に対応するように修正
        #     まずstr_kgmq_dir_pathフォルダ内の全ファイルをglobでリストし、
        #     ついでリスト内包表記でextが'.WAV''.wav'.MP3''.mp3'のものを抽出。
        #     ☆【要注意！】'.*\.(WAV|wav|MP3|mp3)'の「＊」前のピリオドは必須！
        #     ☆【要注意！】区切り記号は「|」であり「/」ではない！
        #                 （イタリックだと見分けにくい）
        str_glob_target = os.path.join(str_kgmq_dir_path, '*.*')
        list_sound_files_fullpath = [fp for fp in \
                                     glob.glob(str_glob_target) \
                                     if re.search('.*\.(WAV|wav|MP3|mp3)',
                                                  str(fp))]
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【get_sound_filename】list_sound_files_fullpathの値は、'\
            '{}です。'.format(list_sound_files_fullpath))  
        
        str_sound_filename = os.path.basename(list_sound_files_fullpath[0])
            # 当面サウンドファイルは１つと前提
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【get_sound_filename】str_sound_filename = '\
                  '{}'.format(str_sound_filename))      
        
        return str_sound_filename
    
    def get_sound_content(self, str_sound_filename):
        """ 
        KGMの音声ファイルをQtMultimedia.QMediaPlayerで開く（2021/03/21）
        """
        
        str_sound_filepath = os.path.join(
                                self._kgm_qp_coredata.kgmqp_folderpath,
                                self.str_kgm_sound_filename)
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print("str_sound_filepath = ", str_sound_filepath)
            
        s_media = QtCore.QUrl.fromLocalFile(str_sound_filepath)
        # s_content = qgis.PyQt5.QtMultimedia.QMediaContent(s_media)
        s_content = QtMultimedia.QMediaContent(s_media)
        # self.sound_media = s_media
        # self.sound_content = s_content
        
        return(s_content)
    
    def get_start_datetime_of_sound(self,
                                    str_folder_path,
                                    str_sound_filename):
        """
        音声ファイルのフォルダ名・ファイル名から録音開始時刻情報を取得、
        self.sound_start_datetimeに入れる
        """        
        str_soundfile_basename = os.path.basename(str_sound_filename)
        
        if self._kgm_qp_coredata.kgmindex_exists == 'N':
            ##### 【要修正！】KGMindex.txtがなければ、
            # Abliedaのファイル名などから腰だめで情報を取得 (2021/05/29)
            # snd_year = int(str_folder_path[0:0])
            # snd_month = int(str_folder_path[0:0])
            snd_year = 2021     # とりあえず2021年
            # snd_month = 2      # とりあえず2月
            snd_month = 3      # とりあえず3月に変更（2021/03/22）
            snd_day = int(str_soundfile_basename[0:2])
            snd_hour = int(str_soundfile_basename[2:4])
            snd_minute = int(str_soundfile_basename[4:6])
            snd_second = int(str_soundfile_basename[6:8])
            ssdt = QDateTime(snd_year,
                             snd_month,
                             snd_day,
                             snd_hour,
                             snd_minute,
                             snd_second,
                             timeSpec=0)            
        elif self._kgm_qp_coredata.kgmindex_exists == 'Y':
            ##### 2021/11/27：
            # 【今後要修正】当面はKGMindex.txtから「"」を除去して処理
            #  Android版とiOSバントのKGMindex.txtの仕様の不統一に対処
            str_temp = self._kgm_qp_coredata.kgmindex_str
            kgmindex_str_temporary = str_temp.strip('"')
            
            ##### 録音開始日時を「YYYY/MM/DD hh:mm:ss」から切り出す
            #     部分文字列のインデクスは、終了文字「の次」まで！
            snd_year = int(kgmindex_str_temporary[0:4])
            snd_month = int(kgmindex_str_temporary[5:7])
            snd_day = int(kgmindex_str_temporary[8:10])
            snd_hour = int(kgmindex_str_temporary[11:13])
            snd_minute = int(kgmindex_str_temporary[14:16])
            snd_second = int(kgmindex_str_temporary[17:19])
            qdt_utc = QDateTime(snd_year,
                                snd_month,
                                snd_day,
                                snd_hour,
                                snd_minute,
                                snd_second,
                                timeSpec=1)
            # KGMindex.txtに記録された時刻はGPSから取得したものなので、
            # timeSpecが「1」(=UTC) (2021/05/29)
            # ちなみに、「timeSpec」が正しい大小文字遣いらしい。
            # 「TimeSpec」ではエラーになった(!) (2021/05/29)
            if self._kgm_qp_coredata._debug_mode == 'Y':
                print('KGMindex.txtから取得した録音開始時刻（UTC） = '\
                  '{}'.format(qdt_utc.toString('yyyy/MM/dd hh:mm:ss')))
            
            ssdt = QDateTime(qdt_utc.toLocalTime())
            
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('Local Timeに変換後の録音開始時刻 = '\
                  '{}'.format(ssdt.toString('yyyy/MM/dd hh:mm:ss')))
        
        return ssdt
    
    
    def conv_ssdt_string_to_datetime(self, ssdt: str) -> datetime:
        """
        【2023/03/05】
        get_start_datetime_of_soundが返す録音開始日時（＝文字列）を
        datetimeに変換
        """
        
        ssdt_datetime = datetime.strptime(ssdt, '%Y/%m/%d %H:%M:%S')
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【conv_ssdt_string_to_datetime】変換後の録音開始時刻 = '\
                  '{}'.format(ssdt_datetime))
        
        return ssdt_datetime
    
    

    def get_elapsed_time_in_milisec(self, str_exifdt):
        """ 
        写真のEXIFのDateTimeから音声の経過時間（ミリ秒）を産出（2021/03/21）
        追ってExifDateTimeからQDateTimeにする部分は独立の関数にしたい
        """
        exif_year = int(str_exifdt[0:4])
        exif_month = int(str_exifdt[5:7])
        exif_day = int(str_exifdt[8:10])
        exif_hour = int(str_exifdt[11:13])
        exif_minute = int(str_exifdt[14:16])
        exif_second = int(str_exifdt[17:19])
        
        dt_exif = QDateTime(exif_year,
                            exif_month,
                            exif_day,
                            exif_hour,
                            exif_minute,
                            exif_second,
                            timeSpec=0)
        
        dt_elapsed_ms = (self.sound_start_datetime.secsTo(dt_exif))*1000
        
        return dt_elapsed_ms
        
    def play_sound(self, ix: int):
        """
        音声を頭出しして再生
        """
        
        # 【要検討】写真画像のインデクスはKgmQpDataのインスタンス変数から取得
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmQpSound】self._kgm_qp_coredata.current_photo_index'\
                  'の値は、{} です。'\
                  .format(self._kgm_qp_coredata.current_photo_index))
        
        attrlist = self._kgm_qp_coredata.current_photo_attributes(ix)   
        str_exif_datetime = attrlist[3]    # フィールド[3]が撮影時刻
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【KgmQpSound】KgmQpPhotopointsでshapefileから取得した'\
                  'EXIF時刻は、'\
                  '{} です。'.format(str_exif_datetime))
        
        # 調整係数を掛ける（2021/03/22）
        sound_cue_milisec = self.get_elapsed_time_in_milisec(str_exif_datetime)
        adjusted_float = sound_cue_milisec * self.adjust_coeff
        adjusted_cue_milisec = int(adjusted_float)
        
        ### 録音開始時刻、Exif時刻、経過時間をログに書き出す（2021/03/22）
        str_start_time = self.sound_start_datetime.toString('hh:mm:ss')
        str_pic_filename = attrlist[2]     # フィールド[2]が写真ファイル名
        str_exif_time = str_exif_datetime[10:19]
        str_adjust_coeff = str(self.adjust_coeff)
        str_cue_milisec = str(adjusted_cue_milisec)
        
        print('【録音開始】' + str_start_time + '； ' + \
              '【写真：' + str_pic_filename + \
              'のExif時刻】' + str_exif_time + '； ' + \
              '【調整係数】' + str_adjust_coeff + '； ' + \
              '【経過ミリ秒】' + str_cue_milisec)
        
        
        
        
        
        '''
        ##### 2022/03/04: 【要修正】ここでdockwidget上のオブジェクトをいじるのはNG！
        # v010のGUIに（調整後）経過ミリ秒を表示（2021/03/25）
        self._kgm_qp_coredata._current_mainwindow.label_ElapsedTime.setText(
                '【撮影時刻までの経過時間（調整後：ミリ秒）】＝ ' + 
                str_cue_milisec)
        '''
        
        
        
        # 調整後経過時間をインスタンス変数に保持
        # （2021/03/25：後日用見直し？）
        self.sound_elapsed_milisec_adjusted = adjusted_cue_milisec
        
        
        
        ##### 2023/02/26: SRTデータ表示用に調整後経過時間をKgmQpDataにも保持
        self._kgm_qp_coredata.sound_elapsed_milisec_adjusted_for_srt = adjusted_cue_milisec
        
        
            
        # 頭出しして再生
        self.player.setPosition(adjusted_cue_milisec)
        self.player.play()
    
    
    def play_sound_from_cue_milisec(self, cue: int):
        """
        【2023/03/07】音声を頭出しして再生
        SRTのstartから得た経過時間（milisecond）で再生位置を指定
        """
        
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【play_sound_from_cue_milisec】cueの値は'\
                  '{} です。'.format(cue))
        
        
        # 頭出しして再生
        self.player.stop()
        self.player.setPosition(cue)
        self.player.play()
    
    
    def discard_current_sound_data(self):
        """
        【2022/05/12】self.playerの再生対象コンテンツをNullに設定
        """
        # self.player.setMedia(QMediaContent())
        
        # null_content = QtMultimedia.QMediaContent()
        
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【discard_current_sound_data】null_contentの値は'\
                  '{} です。'.format(self.null_content))
        
        self.player.setMedia(self.null_content)
        
    def set_player(self):
        """
        【2022/04/24】
        QMediaPlayerのインスタンス変数をセット
        【2022/05/12】
        playerをdelするのでなく、null_contentをセット
        """
        ##### 2022/04/24: 複数データ時の音声重複再生への対策
        try:
            self.player.stop()
            # del self.player   # 既存のがあれば消す
            # self.player = QMediaPlayer()
            ### 2022/05/12: 既存のがあればnull_contentをセット
            self.discard_current_sound_data()
        except:
            print('【set_player】既存のself.playerはありません。')
            self.player = QMediaPlayer()
        else:
            # del self.player   # 既存のがあれば消す
            # self.player = QMediaPlayer()
            # print('【set_player】stopしてdelしました。')
            ### 2022/05/12:
            print('【set_player】stopしてnull_contentをセットしました。')
        finally:
            # del self.player   # 既存のがあれば消す
            # self.player = QMediaPlayer()
            # print('【set_player】player = QMediaPlayer()しました。')
            
            ### 2022/05/12: delして再インスタンス化ではなく
            ###             コンテンツをセットし直す
            ### 【NG】ここでやるとループする？
            # self.prepare_sound_data()
            pass
            
        # self.player = QMediaPlayer()
        
        
        ### 2022/05/12: Pythonコンソールにも書き出す
        if self._kgm_qp_coredata._debug_mode == 'Y':
            print('【set_player】set_playerの処理を行いました。')
        
        '''
        QMessageBox.information(
            None,
            "通知",
            "set_playerの処理を行いました。",
            QMessageBox.Yes)
        '''
            
        # return my_player
    
    def update_sound_position(self, position):
        """
        【2023/02/21】
        QMediaPlayerからのpositionChangedシグナルにより、
        その時点のpositionを表示
        【☆要検討】インポートしたdatetimeと変数名とが紛らわしい
        
        """
        
        sound_current_datetime = self.sound_start_datetime.addMSecs(position)
        str_sound_current_datetime = sound_current_datetime.toString('yyyy:MM:dd hh:mm:ss')
        
        ##### 2023/02/21: 【要検討】ここでdockwidget上のオブジェクトをいじるのはNG？
        self._kgm_qp_coredata._current_mainwindow.label_ElapsedTime.setText(
                '【再生中の音声の現在日時】＝ ' + 
                str_sound_current_datetime)
    
'''
class TableModel(QtCore.QAbstractTableModel):
    """
    【2023/02/22】QTableViewで表示するテーブルのモデル試作
    see "Python & Qt5" p.310
    """
    def __init__(self, data):
        super().__init__()
        self._data = data
    
    def data(selfself, index, role):
        """
        
        """
        if role == Qt.DisplayRole:
            return self._data[index.row()][index.column()]
        
    def rowCount(self, index):
        """
        
        """
        return len(self._data)
    
    def columnCount(self, index):
        """
        
        """
        return len(self._data[0] )
'''


