<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ko_KR" sourcelanguage="ja_JP">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../KgmQpd_enlarged_test03.ui" line="32"/>
        <source>拡大表示</source>
        <translation>확대보기</translation>
    </message>
    <message>
        <location filename="../KgmQpd_enlarged_test03.ui" line="79"/>
        <source>TextLabel</source>
        <translation>TextLabel</translation>
    </message>
    <message>
        <location filename="../KgmQpd_enlarged_test03.ui" line="128"/>
        <source>【メモ欄】</source>
        <translation>【메모란】</translation>
    </message>
    <message>
        <location filename="../KgmQpd_enlarged_test03.ui" line="149"/>
        <source>文字の大きさ：</source>
        <translation>글자크기:</translation>
    </message>
</context>
<context>
    <name>KgmQpDocDockWidgetBase</name>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="14"/>
        <source>『聞き書きマップ』（DocSR版）</source>
        <translation>『듣고 쓰는 지도』(DocSR版)</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="31"/>
        <source>読み込み</source>
        <translation>읽기</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="51"/>
        <source>＜前の写真へ</source>
        <translation>&lt;이전 사진으로 가기</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="79"/>
        <source>【写真番号】</source>
        <translation>【사진 번호】</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="112"/>
        <source>【経路】</source>
        <translation>【경로】</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="122"/>
        <source>次の写真へ＞</source>
        <translation>다음 사진으로 이동&gt;</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="134"/>
        <source>書き出し</source>
        <translation>내보내기</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="156"/>
        <source>拡張機能</source>
        <translation>확장 기능</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="163"/>
        <source>拡大</source>
        <translation>확대</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="177"/>
        <source>３秒進める＞</source>
        <translation>초 단위로 진행&gt;</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="184"/>
        <source>停止</source>
        <translation>정지</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="210"/>
        <source>＜３秒戻す</source>
        <translation>&lt;초 뒤로 가기</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="217"/>
        <source>もう一度聞く</source>
        <translation>다시 듣기</translation>
    </message>
</context>
<context>
    <name>KgmQpDocSR</name>
    <message>
        <location filename="../kgm_qpdsr.py" line="202"/>
        <source>&amp;&quot;Kiki-Gaki Map&quot; Dockable SR Plugin</source>
        <translation>&amp;&quot;Kiki-Gaki Map&quot; Dockable SR Plugin</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr.py" line="171"/>
        <source>QGIS-plugin (dockable-SR) version of the &quot;Kiki-Gaki Map&quot;</source>
        <translation>QGIS-plugin (dockable-SR) version of the &quot;Kiki-Gaki Map&quot;</translation>
    </message>
</context>
<context>
    <name>dialog</name>
    <message>
        <location filename="../kgm_qpdsr_qtableview_test03.ui" line="20"/>
        <source>自動聞き書き</source>
        <translation>텍스트 검색</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_qtableview_test03.ui" line="36"/>
        <source>テキスト検索</source>
        <translation>텍스트 검색</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_qtableview_test03.ui" line="46"/>
        <source>＜前に戻る</source>
        <translation>&lt;이전으로 돌아가기</translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr_qtableview_test03.ui" line="56"/>
        <source>次に進む＞</source>
        <translation>다음으로 가기&gt;</translation>
    </message>
</context>
</TS>
