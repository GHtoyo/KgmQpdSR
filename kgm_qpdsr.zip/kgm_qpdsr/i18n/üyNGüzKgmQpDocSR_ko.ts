<?xml version="1.0" encoding="utf-8"? >
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>Dialog</name>
    <message encoding="UTF-8"> <!
        <location filename=".. /KgmQpd_enlarged_test03.ui" line="32"/> <font size=".../KgmQpd_enlarged_test03.ui
        <source>확대보기</source>.
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="... /KgmQpd_enlarged_test03.ui" line="79"/> <font color="red">
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /KgmQpd_enlarged_test03.ui" line="128"/> <font size=".../KgmQpd_enlarged_test03.ui
        <source>【메모란】</source></source
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /KgmQpd_enlarged_test03.ui" line="149"/> <font size=".../font size="...
        <source>글자크기: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8"></context
    <name>KgmQpDocDockWidgetBase</name>
    <message encoding="UTF-8"> <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="14"/> <font size=".../kgm_qpdsr_dockwidget_base_test01.ui
        <source>『듣고 쓰는 지도』(DocSR版)</source></source>.
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="31"/>
        <source>읽기</source
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="51"/> <location filename=".../kgm_qpdsr_dockwidget_base_test01.ui
        <source><이전 사진으로 가기</source> <source
        <translation type="unfinished"></translation></translation
    </message>
    <message encoding="UTF-8"> <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="79"/> <location filename=".../kgm_qpdsr_dockwidget_base_test01.ui
        <source>【사진 번호】</source></source
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="112"/>
        <source>【경로】</source><source><source>경로
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="122"/> <location filename=".../kgm_qpdsr_dockwidget_base_test01.ui
        <source>다음 사진으로 이동</source></source
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="134"/> <location filename=".../kgm_qpdsr_dockwidget_base_test01.ui
        <source>내보내기</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="156"/> <font size=".../kgm_qpdsr_dockwidget_base_test01.ui
        <source>확장 기능</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="163"/> <font size=".../kgm_qpdsr_dockwidget_base_test01.ui
        <source>확대</source
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="177"/> <font size=".../kgm_qpdsr_dockwidget_base_test01.ui
        <source>초 단위로 진행></source>.
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="184"/>
        <source>정지</source
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="210"/> <font size=".../kgm_qpdsr_dockwidget_base_test01.ui
        <source><source><second back</source
        <translation type="unfinished"></translation></translation>
    </message>
    <message encoding="UTF-8"> <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_dockwidget_base_test01.ui" line="217"/>
        <source>다시 듣기</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KgmQpDocSR</name>
    <message>
        <location filename=".. /kgm_qpdsr.py" line="202"/> <font size="...
        <source>&quot;&quot;키키가키 맵(Kiki-Gaki Map) 도킹 가능 SR 플러그인</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename=".. /kgm_qpdsr.py" line="171"/> <font size="...
        <source>QGIS-plugin(dockable-SR) 버전의 <quot;키키가키 지도&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>dialog</name>
    <message encoding="UTF-8"> <name>dialog</name> <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_qtableview_test03.ui" line="20"/> <location filename="...
        <source>자동 듣기</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_qtableview_test03.ui" line="36"/> <location filename=".../kgm_qpdsr_qtableview_test03.ui
        <source>텍스트 검색</source
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_qtableview_test03.ui" line="46"/> <location filename=".../kgm_qpdsr_qtableview_test03.ui
        <source><이전으로 돌아가기</source> <source
        <translation type="unfinished"></translation> </message> </message> </message>
    </message>
    <message encoding="UTF-8"> <message encoding="UTF-8">
        <location filename=".. /kgm_qpdsr_qtableview_test03.ui" line="56"/>
        <source>다음으로 가기</source> </source
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
