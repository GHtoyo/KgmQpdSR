<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>Dialog</name>
    <message encoding="UTF-8">
        <location filename="../KgmQpd_enlarged_test03.ui" line="32"/>
        <source>拡大表示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../KgmQpd_enlarged_test03.ui" line="79"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../KgmQpd_enlarged_test03.ui" line="128"/>
        <source>【メモ欄】</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../KgmQpd_enlarged_test03.ui" line="149"/>
        <source>文字の大きさ：</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>KgmQpDocDockWidgetBase</name>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="14"/>
        <source>『聞き書きマップ』（DocSR版）</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="31"/>
        <source>読み込み</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="51"/>
        <source>＜前の写真へ</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="79"/>
        <source>【写真番号】</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="112"/>
        <source>【経路】</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="122"/>
        <source>次の写真へ＞</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="134"/>
        <source>書き出し</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="156"/>
        <source>拡張機能</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="163"/>
        <source>拡大</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="177"/>
        <source>３秒進める＞</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="184"/>
        <source>停止</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="210"/>
        <source>＜３秒戻す</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_dockwidget_base_test01.ui" line="217"/>
        <source>もう一度聞く</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KgmQpDocSR</name>
    <message>
        <location filename="../kgm_qpdsr.py" line="202"/>
        <source>&amp;&quot;Kiki-Gaki Map&quot; Dockable SR Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../kgm_qpdsr.py" line="171"/>
        <source>QGIS-plugin (dockable-SR) version of the &quot;Kiki-Gaki Map&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>dialog</name>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_qtableview_test03.ui" line="20"/>
        <source>自動聞き書き</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_qtableview_test03.ui" line="36"/>
        <source>テキスト検索</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_qtableview_test03.ui" line="46"/>
        <source>＜前に戻る</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../kgm_qpdsr_qtableview_test03.ui" line="56"/>
        <source>次に進む＞</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
